# CHANGELOG — MB SYSTEM 4D - Canais Dark Globais

## [0.8.0] — 2026-02-14

### Adicionado (F8 — Polish)
- Página /config: configurações do sistema com 5 seções
  - Chaves de API: referência visual para Google TTS, ElevenLabs, YouTube API
  - Aparência: seletor de cor de destaque (6 cores), densidade da interface
  - Notificações: toggles para overdue, niche viral, quota TTS
  - Dados & Backup: exportação completa em JSON (8 tabelas), zona de perigo
  - Sobre: versão, stack, autor, selo ACPC-IA
- Toast de confirmação ao salvar configurações

## [0.7.0] — 2026-02-14

### Adicionado (F7 — Nichos)
- Queries: niche-queries.ts (CRUD para nichos monitorados e canais removidos)
- Migration SQL: 00002_niches_ideas.sql (monitored_niches, removed_channels, idea_board)
- Página /nichos com 2 tabs:
  - Nichos Monitorados: keywords, região, botão Scan (chama YouTube API), score médio viral
  - Canais Removidos: registro de canais dark que caíram, motivo, inscritos, notas

## [0.6.0] — 2026-02-14

### Adicionado (F6 — Inteligência)
- YouTube Data API service: search, trending, video details, channel insight
- Viral Score Calculator: composição ponderada (velocidade 50% + engagement 30% + recência 20%)
- Channel Insight Builder: média views, frequência upload, top vídeos, growth score, nicho estimado
- API route GET /api/youtube com actions: trending, search, channel
- Página /virais com 3 tabs:
  - Trending: vídeos em alta por região (8 países), thumbnails, score viral
  - Buscar Virais: busca livre com filtros (período, ordem, região)
  - Análise de Canal: perfil completo com métricas, top 5 vídeos, growth score

## [0.5.0] — 2026-02-14

### Adicionado (F5 — Organização)
- Queries: org-queries.ts (CRUD para prompts, referências, ideias)
- Página /prompts: biblioteca de prompts com tags, busca, expand/collapse, copy-to-clipboard
- Página /referencias: cards de referências com nicho, URL, notas, grid responsivo
- Página /ideias: quadro de sticky notes coloridos com drag-to-reorder, edição in-place
- Página /ferramentas: 4 utilitários de texto
  - Contador: chars, palavras, frases, parágrafos, narração (3 velocidades), limites YouTube
  - Formatador: MAIÚSCULAS, minúsculas, Capitalizar, Frase
  - Gerador de Hashtags: extrai palavras-chave por frequência
  - Limpador: remover espaços extras, quebras múltiplas, linhas vazias

## [0.5.0] — 2026-02-14

### Adicionado (F5 — Organização e Ferramentas)
- Migration SQL: tabelas prompts, references, ideas (com RLS e índices GIN)
- Queries: organization-queries.ts com CRUD para prompts, referências e ideias
- Página /prompts: biblioteca com busca, filtro por tags, expand/collapse, copy
- Página /referencias: CRUD com nicho, link, canal associado, grid de cards
- Página /ferramentas/ideias: quadro de sticky notes coloridos (6 cores), pin/unpin
- Página /ferramentas/srt: gerador de SRT estimado client-side (modo por palavras ou View/tempo)
- Página /ferramentas/divisor: divisor de texto (por chars/palavras/frases/parágrafos) com copy
- Página /ferramentas/editor: editor de texto com transformações (maiúsculas, capitalizar, remover espaços, deduplicar linhas), undo, stats detalhados (chars, palavras, frases, parágrafos, tempo leitura/narração), download .txt

## [0.4.0] — 2026-02-14

### Adicionado (F4 — Dashboard com Dados Reais)
- Dashboard queries: getDashboardData() com agregação completa via Supabase
- Stats dinâmicos: canais, vídeos por status, roteiros, áudios gerados
- Detecção automática de vídeos atrasados (scheduled_at no passado)
- Painel de alertas: vídeos atrasados com destaque vermelho e link direto
- Notificações com marcar como lida (individual e em massa)
- Próximas publicações agrupadas por dia (Hoje, Amanhã, dia da semana)
- Resumo dos canais com badges dinâmicos por status
- Saudação contextual com mensagem baseada no estado atual
- Botão de refresh manual para atualizar dados
- Mini-stats: total de roteiros e áudios gerados
- Loading skeletons durante carregamento
- Navegação: click em qualquer item leva à página correta

### Alterado
- Dashboard substituído de mock data para dados reais do Supabase
- Nome do projeto atualizado: MB SYSTEM 4D - Canais Dark Globais

## [0.3.0] — 2026-02-14

### Adicionado (F3 — Gerador de Áudio)
- Adapter pattern multi-provider TTS: GoogleTTSProvider + ElevenLabsProvider
- Interface comum ITTSProvider com listVoices(), generateAudio(), getQuota()
- Google Cloud TTS: SSML marks para timestamps por palavra, voice cloning ready
- ElevenLabs TTS: timestamps via alignment API, multilingual v2
- Geração de SRT sincronizado (por palavras do provider)
- Geração de SRT View (segmentos fixos de 8s)
- Fallback: SRT estimado quando provider não retorna timestamps
- API route POST /api/audio/generate (cria job → gera áudio → upload MP3/SRT → atualiza job)
- API route GET /api/audio/voices (com filtros por provider, idioma, gênero)
- Componente VoiceSelector com busca e filtros
- Componente AudioGenerator com controles de velocidade, volume, palavras/legenda
- Página /audio com tabs Gerar Áudio e Histórico de jobs
- Importação de roteiro direto no gerador

## [0.2.0] — 2026-02-14

### Adicionado (F2 — Canais + Pipeline)
- Camada de queries Supabase: CRUD completo para channels, shortcuts, videos, scripts
- API routes: channels, channels/[id], videos, videos/[id], scripts, scripts/[id]
- Componentes UI: Modal, EmptyState, StatusBadge
- ChannelForm: criação/edição de canal com atalhos personalizáveis
- VideoForm: criação/edição de vídeo com vínculo a roteiro e agendamento
- ScriptEditor: editor de roteiro com contagem chars/palavras/tempo de narração
- PipelineBoard: board visual com 6 colunas de status e drag & drop
- Página /canais: grid de cards com mini-stats por status
- Página /canais/[id]: detalhe do canal com tabs Pipeline/Roteiros + atalhos

## [0.1.0] — 2026-02-14

### Adicionado
- Setup inicial do projeto Next.js 14+ com TypeScript
- Configuração Tailwind CSS com tema dark personalizado (paleta Dark Planner)
- Layout base: sidebar com navegação completa + header com quota e notificações
- Dashboard com métricas, alertas, próximas publicações e resumo de canais
- Páginas placeholder para todos os 11+ módulos
- Modelo de dados completo (17 tabelas) em SQL para Supabase
- Configuração Supabase (client browser + server, types, RLS)
- Multi-provider TTS: Google Cloud TTS (principal) + ElevenLabs (complementar)
- Documentação ACPC-IA: Identidade do projeto, Contexto, Changelog
- Sistema de componentes: StatCard, badges, botões, inputs
- Animações: fade-in, slide-in, pulse-soft
- Custom scrollbar estilizada
