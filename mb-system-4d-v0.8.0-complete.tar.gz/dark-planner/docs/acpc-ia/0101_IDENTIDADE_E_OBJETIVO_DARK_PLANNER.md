# 0101_IDENTIDADE_E_OBJETIVO_DARK_PLANNER.md

## Projeto: DARK PLANNER (Clone Pessoal)

### 1. Identidade do Projeto

**Nome oficial:** Dark Planner  
**Tipo:** Ferramenta pessoal de gestão e produção de conteúdo para canais Dark/Faceless  
**Plataforma:** Aplicação Web (SaaS-like, single-user)  
**Framework de governança:** ACPC-IA v1.0  
**Versão do projeto:** 0.1.0 (pré-desenvolvimento)  
**Data de início:** 2026-02-14  
**Responsável:** Marcelo Brasil

---

### 2. Objetivo Geral

> Construir uma ferramenta web pessoal que centralize a gestão de canais
> Dark/Faceless no YouTube, integrando pipeline de produção de vídeos,
> geração de áudio por IA (TTS com voz clonada + vozes sintéticas),
> legendas sincronizadas e inteligência de mercado (nichos virais,
> análise de canais), eliminando dependência de múltiplas ferramentas
> dispersas.

---

### 3. Objetivos Específicos

1. Gerenciar múltiplos canais YouTube com pipeline visual (planejamento → produção → pronto → agendado → publicado)
2. Gerar áudio de alta qualidade usando voz própria clonada e vozes sintéticas para estudo
3. Gerar legendas SRT sincronizadas automaticamente a partir do áudio
4. Buscar vídeos virais e nichos em crescimento para decisão de conteúdo
5. Analisar qualquer canal YouTube e exportar dados para análise com IA
6. Manter biblioteca organizada de prompts, referências e ideias
7. Operar com custo mínimo (free tiers sempre que possível)

---

### 4. Decisões Técnicas Consolidadas

#### 4.1 Stack Tecnológica

| Camada | Tecnologia | Justificativa |
|--------|-----------|---------------|
| Frontend + Backend | **Next.js 14+ (App Router)** | Projeto único (mono-repo), SSR, API routes integradas |
| Banco + Auth + Storage | **Supabase** | PostgreSQL gerenciado, auth pronto, storage para MP3/SRT, free tier generoso |
| Estilização | **Tailwind CSS + shadcn/ui** | Dark theme nativo, componentes prontos, produtividade |
| TTS Principal | **Google Cloud TTS** | Free tier: 4M chars Standard / 1M WaveNet por mês. Voice cloning com 10s de áudio |
| TTS Complementar | **ElevenLabs (Free)** | 20 min/mês grátis para vozes ultra-realistas pontuais |
| YouTube Data | **YouTube Data API v3** | 10.000 unidades/dia grátis |
| Deploy | **Vercel (hobby)** | Deploy automático, grátis, zero config |
| Jobs assíncronos | **Vercel Cron + Supabase Edge Functions** | Scanner de nichos e cleanup de assets |

#### 4.2 Estratégia de TTS (Multi-Provider)

```
AudioService (adapter pattern)
├── GoogleTTSProvider    ← principal (grátis, 1M+ chars/mês)
│   ├── Vozes Standard (4M chars grátis)
│   ├── Vozes WaveNet (1M chars grátis)
│   ├── Vozes Studio (qualidade premium)
│   └── Voice Clone (voz do Marcelo, 10s de áudio)
├── ElevenLabsProvider   ← complementar (20 min grátis/mês)
│   ├── Vozes premium ultra-realistas
│   └── Voice Clone (alternativa)
└── Interface comum
    ├── listVoices() → Voice[]
    ├── generateAudio(text, voiceId, params) → MP3
    ├── generateSRT(audio, params) → SRT
    └── getUsage() → QuotaInfo
```

**Regra de decisão:** Google como default para produção em volume. ElevenLabs para vozes específicas que exijam máxima naturalidade.

#### 4.3 Custos Projetados (Mensal)

| Serviço | Custo |
|---------|-------|
| Vercel (hobby) | R$ 0 |
| Supabase (free tier) | R$ 0 |
| Google Cloud TTS (free tier) | R$ 0 |
| ElevenLabs (free tier) | R$ 0 |
| YouTube Data API (grátis) | R$ 0 |
| Domínio (opcional) | ~R$ 3/mês |
| **Total** | **R$ 0 a R$ 3/mês** |

---

### 5. Escopo do Projeto

#### 5.1 Dentro do escopo (MVP)

- Dashboard com visão consolidada de todos os canais
- CRUD de canais com atalhos, notas, descrição padrão
- Pipeline de vídeos (6 status) com transições automáticas
- Roteiros vinculados ao pipeline
- Gerador de Áudio multi-provider (Google TTS + ElevenLabs)
- Gerador de SRT sincronizado
- Gerador de Legenda View (segmentos de 8s)
- Busca de vídeos virais (YouTube API)
- Scanner de nichos virais
- Análise de canal (export TXT)
- Biblioteca de prompts
- Referências organizadas por nicho
- Quadro de ideias
- Ferramentas de texto (divisor, editor)
- Notificações internas
- Tema dark (padrão)

#### 5.2 Fora do escopo (por enquanto)

- Multi-usuário / autenticação social
- Planos e cobrança (é ferramenta pessoal)
- Mobile nativo
- Integrações com CapCut/Premiere API
- Upload direto para YouTube
- Sistema de comunidade/chat

---

### 6. Estrutura de Pastas do Projeto

```
/dark-planner
├── app/                          ← Next.js App Router
│   ├── (auth)/                   ← Login (simplificado, single-user)
│   ├── dashboard/                ← Home
│   ├── canais/                   ← Gestão de canais
│   │   └── [id]/                 ← Detalhe do canal + pipeline
│   ├── audio/                    ← Gerador de áudio
│   ├── tendencias/               ← Virais, Nichos
│   │   ├── videos-virais/
│   │   ├── nichos-virais/
│   │   └── canais-removidos/
│   ├── insights/                 ← Análise de canal
│   ├── prompts/                  ← Biblioteca
│   ├── referencias/              ← Referências
│   ├── ideias/                   ← Quadro de ideias
│   ├── ferramentas/              ← SRT, divisor, editor
│   └── api/                      ← API routes (server-side)
│       ├── audio/
│       │   ├── generate/
│       │   └── voices/
│       ├── youtube/
│       ├── channels/
│       ├── videos/
│       ├── scripts/
│       ├── trends/
│       ├── insights/
│       ├── prompts/
│       ├── references/
│       └── notifications/
├── components/                   ← UI reutilizáveis
│   ├── ui/                       ← shadcn/ui components
│   ├── dashboard/
│   ├── audio/
│   ├── pipeline/
│   └── layout/
├── lib/                          ← Lógica compartilhada
│   ├── supabase/                 ← Client, types, queries
│   ├── providers/                ← TTS adapters
│   │   ├── google-tts.ts
│   │   ├── elevenlabs.ts
│   │   └── audio-service.ts     ← Interface comum
│   ├── youtube/                  ← YouTube API client
│   └── utils/                    ← Helpers gerais
├── supabase/
│   └── migrations/               ← SQL migrations
├── docs/                         ← Documentação ACPC-IA
│   ├── 0101_IDENTIDADE_E_OBJETIVO_DARK_PLANNER.md
│   ├── CONTEXTO_DO_PROJETO.md
│   ├── ROADMAP.md
│   └── CHANGELOG.md
├── backups/                      ← Snapshots de contexto
├── public/                       ← Assets estáticos
├── .env.local                    ← API keys (local only)
├── package.json
├── tailwind.config.ts
├── tsconfig.json
└── next.config.ts
```

---

### 7. Roadmap de Implementação

| Fase | Entregas | Estimativa |
|------|----------|-----------|
| **F1 — Fundação** | Setup Next.js + Supabase + Auth + Tailwind + dark theme + layout base | 1 semana |
| **F2 — Canais + Pipeline** | CRUD canais, atalhos, pipeline de vídeos (6 status), roteiros | 2 semanas |
| **F3 — Gerador de Áudio** | Multi-provider (Google TTS + ElevenLabs), voice clone, SRT, Legenda View | 2-3 semanas |
| **F4 — Dashboard** | Métricas agregadas, alertas, próximas publicações, resumo de canais | 1 semana |
| **F5 — Organização** | Prompts, referências, quadro de ideias, ferramentas de texto | 1 semana |
| **F6 — Inteligência** | Vídeos virais, insights de canal (YouTube API + TXT) | 2 semanas |
| **F7 — Nichos** | Scanner de nichos virais, canais removidos, notificações | 2 semanas |
| **F8 — Polish** | Refinamentos de UI, performance, edge cases, testes | 1-2 semanas |
| **Total** | MVP completo | **10-14 semanas** |

---

### 8. Resultado Esperado

Quando finalizado, o Dark Planner pessoal deve permitir:

- Gerenciar todos os canais Dark em um único painel
- Produzir áudio narrado com voz própria clonada ou vozes sintéticas sem custo mensal
- Gerar legendas sincronizadas prontas para CapCut/Premiere
- Descobrir nichos promissores antes da concorrência
- Analisar canais concorrentes com profundidade
- Manter toda a operação organizada sem depender de ferramentas externas
- Operar com custo mensal próximo de zero

---

**Construído com ACPC-IA Framework v1.0**  
**Conforme arquivos 0101–0901 do framework**
