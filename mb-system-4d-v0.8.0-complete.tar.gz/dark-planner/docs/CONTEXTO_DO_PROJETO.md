# CONTEXTO_DO_PROJETO.md — Dark Planner

## PROJETO: Dark Planner (Clone Pessoal)
## VERSÃO: 0.1.0
## DATA: 2026-02-14
## STATUS: Pré-desenvolvimento — Arquitetura definida, setup pendente

---

## DESCRIÇÃO
Ferramenta web pessoal para gestão e produção de conteúdo para canais Dark/Faceless no YouTube. Centraliza pipeline de vídeos, geração de áudio TTS (voz clonada + sintéticas), legendas SRT, inteligência de mercado (nichos virais, análise de canais), prompts e referências.

## STACK
- **Frontend + Backend:** Next.js 14+ (App Router)
- **Banco + Auth + Storage:** Supabase (PostgreSQL)
- **Estilização:** Tailwind CSS + shadcn/ui (dark theme)
- **TTS Principal:** Google Cloud TTS (free tier: 4M chars Standard / 1M WaveNet por mês)
- **TTS Complementar:** ElevenLabs (free tier: 20 min/mês)
- **YouTube:** YouTube Data API v3 (10k unidades/dia grátis)
- **Deploy:** Vercel (hobby, grátis)
- **Jobs:** Vercel Cron + Supabase Edge Functions

## MÓDULOS PLANEJADOS
1. Dashboard (visão consolidada)
2. Gestão de Canais (CRUD + atalhos + notas)
3. Pipeline de Vídeos (6 status com transições automáticas)
4. Roteiros (vinculados ao pipeline)
5. Gerador de Áudio (multi-provider: Google TTS + ElevenLabs)
6. Gerador de SRT + Legenda View (8s)
7. Vídeos Virais (busca YouTube)
8. Nichos Virais (scanner 24h)
9. Canais Removidos (anti-modelo)
10. Insights de Canal (export TXT)
11. Biblioteca de Prompts
12. Referências (por nicho)
13. Quadro de Ideias
14. Ferramentas de Texto (divisor, editor)
15. Notificações

## MÓDULOS IMPLEMENTADOS
- Nenhum (projeto em fase de setup)

## PROBLEMAS CONHECIDOS
- Nenhum (projeto ainda não iniciado)

## DECISÕES ARQUITETURAIS
1. Multi-provider TTS com adapter pattern (Google principal, ElevenLabs complementar)
2. Single-user (sem sistema de planos/billing)
3. Mono-repo Next.js (frontend + API routes no mesmo projeto)
4. Supabase RLS para segurança mesmo sendo single-user (boa prática)
5. Transições automáticas de status via trigger PostgreSQL

## PRÓXIMOS PASSOS
1. [ ] Criar projeto Next.js com TypeScript
2. [ ] Configurar Supabase (projeto + database)
3. [ ] Rodar migration inicial (00001_initial_schema.sql)
4. [ ] Configurar Tailwind + shadcn/ui + dark theme
5. [ ] Criar layout base (sidebar + header + content area)
6. [ ] Implementar auth simplificado (Supabase Auth)
7. [ ] Iniciar Fase F2: CRUD de Canais

## DOCUMENTOS DO PROJETO
- 0101_IDENTIDADE_E_OBJETIVO_DARK_PLANNER.md — identidade e decisões
- 00001_initial_schema.sql — modelo de dados completo
- DARK_PLANNER_RE_SPEC_ACPC_IA.md — especificação técnica completa (RE)
- ROADMAP.md — (a criar)
- CHANGELOG.md — (a criar)
