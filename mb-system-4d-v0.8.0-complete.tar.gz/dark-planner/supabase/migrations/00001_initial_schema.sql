-- ============================================================
-- DARK PLANNER — Migration Inicial (Supabase / PostgreSQL)
-- Versão: 0.1.0
-- Framework: ACPC-IA v1.0
-- Data: 2026-02-14
-- ============================================================

-- ============================================================
-- EXTENSÕES
-- ============================================================
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- TIPOS ENUM
-- ============================================================

CREATE TYPE video_status AS ENUM (
  'planning',
  'production',
  'ready',
  'scheduled',
  'published',
  'overdue'
);

CREATE TYPE script_source AS ENUM (
  'manual',
  'upload',
  'import'
);

CREATE TYPE audio_job_status AS ENUM (
  'queued',
  'processing',
  'succeeded',
  'failed'
);

CREATE TYPE insight_job_status AS ENUM (
  'queued',
  'processing',
  'succeeded',
  'failed'
);

CREATE TYPE asset_type AS ENUM (
  'audio_mp3',
  'srt',
  'view_srt',
  'insight_txt',
  'thumbnail',
  'other'
);

CREATE TYPE voice_gender AS ENUM (
  'male',
  'female',
  'neutral'
);

CREATE TYPE tts_provider AS ENUM (
  'google',
  'elevenlabs'
);

CREATE TYPE caption_font_size AS ENUM (
  'small',
  'medium',
  'large'
);

CREATE TYPE viral_channel_category AS ENUM (
  'exploding',
  'high',
  'growing',
  'new',
  'other'
);

-- ============================================================
-- TABELA: profiles (extensão do auth.users do Supabase)
-- ============================================================
CREATE TABLE profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name VARCHAR(255),
  avatar_url VARCHAR(500),
  youtube_api_key_encrypted TEXT,  -- AES-256 encrypted
  timezone VARCHAR(50) DEFAULT 'America/Sao_Paulo',
  theme VARCHAR(10) DEFAULT 'dark',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- TABELA: project_channels (Canais/Projetos)
-- ============================================================
CREATE TABLE project_channels (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  language VARCHAR(10) DEFAULT 'pt-BR',
  posting_time TIME,
  frequency VARCHAR(50),
  already_posted_count INTEGER DEFAULT 0,
  default_description TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_channels_user ON project_channels(user_id);

-- ============================================================
-- TABELA: channel_shortcuts (Atalhos por canal)
-- ============================================================
CREATE TABLE channel_shortcuts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  channel_id UUID NOT NULL REFERENCES project_channels(id) ON DELETE CASCADE,
  label VARCHAR(100) NOT NULL,
  url VARCHAR(500) NOT NULL,
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_shortcuts_channel ON channel_shortcuts(channel_id);

-- ============================================================
-- TABELA: scripts (Roteiros)
-- ============================================================
CREATE TABLE scripts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  channel_id UUID REFERENCES project_channels(id) ON DELETE SET NULL,
  title VARCHAR(500) NOT NULL,
  body_text TEXT NOT NULL DEFAULT '',
  source script_source DEFAULT 'manual',
  char_count INTEGER GENERATED ALWAYS AS (LENGTH(body_text)) STORED,
  word_count INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_scripts_channel ON scripts(channel_id);
CREATE INDEX idx_scripts_user ON scripts(user_id);

-- ============================================================
-- TABELA: video_items (Pipeline de vídeos)
-- ============================================================
CREATE TABLE video_items (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  channel_id UUID NOT NULL REFERENCES project_channels(id) ON DELETE CASCADE,
  title VARCHAR(500) NOT NULL,
  description TEXT,
  thumbnail_url VARCHAR(500),
  script_id UUID REFERENCES scripts(id) ON DELETE SET NULL,
  status video_status DEFAULT 'planning',
  scheduled_at TIMESTAMPTZ,
  published_at TIMESTAMPTZ,
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_videos_channel_status ON video_items(channel_id, status);
CREATE INDEX idx_videos_scheduled ON video_items(scheduled_at) WHERE status = 'scheduled';

-- ============================================================
-- TABELA: voices (Catálogo de vozes TTS)
-- ============================================================
CREATE TABLE voices (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  provider tts_provider NOT NULL,
  provider_voice_id VARCHAR(255) NOT NULL,
  name VARCHAR(255) NOT NULL,
  gender voice_gender DEFAULT 'neutral',
  language_tags TEXT[] DEFAULT '{}',
  preview_url VARCHAR(500),
  is_clone BOOLEAN DEFAULT FALSE,
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT NOW(),

  UNIQUE(provider, provider_voice_id)
);

CREATE INDEX idx_voices_provider ON voices(provider, is_active);
CREATE INDEX idx_voices_gender ON voices(gender) WHERE is_active = TRUE;

-- ============================================================
-- TABELA: voice_favorites (Vozes favoritas do usuário)
-- ============================================================
CREATE TABLE voice_favorites (
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  voice_id UUID NOT NULL REFERENCES voices(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT NOW(),

  PRIMARY KEY (user_id, voice_id)
);

-- ============================================================
-- TABELA: assets (Arquivos gerados: MP3, SRT, TXT)
-- ============================================================
CREATE TABLE assets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  type asset_type NOT NULL,
  storage_path VARCHAR(500) NOT NULL,
  content_type VARCHAR(100) NOT NULL,
  size_bytes BIGINT,
  expires_at TIMESTAMPTZ,  -- NULL = sem expiração
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_assets_expires ON assets(expires_at) WHERE expires_at IS NOT NULL;
CREATE INDEX idx_assets_user ON assets(user_id);

-- ============================================================
-- TABELA: audio_jobs (Jobs de geração de áudio)
-- ============================================================
CREATE TABLE audio_jobs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  channel_id UUID REFERENCES project_channels(id) ON DELETE SET NULL,
  script_id UUID REFERENCES scripts(id) ON DELETE SET NULL,
  voice_id UUID NOT NULL REFERENCES voices(id),
  input_text TEXT NOT NULL,
  name VARCHAR(255),
  provider tts_provider NOT NULL,
  params_speed DECIMAL(3,2) DEFAULT 1.00,
  params_volume DECIMAL(3,2) DEFAULT 1.00,
  params_words_per_caption INTEGER DEFAULT 5,
  params_caption_font_size caption_font_size DEFAULT 'medium',
  status audio_job_status DEFAULT 'queued',
  provider_request_id VARCHAR(255),
  output_audio_asset_id UUID REFERENCES assets(id) ON DELETE SET NULL,
  output_srt_asset_id UUID REFERENCES assets(id) ON DELETE SET NULL,
  output_view_srt_asset_id UUID REFERENCES assets(id) ON DELETE SET NULL,
  error_message TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  finished_at TIMESTAMPTZ
);

CREATE INDEX idx_audio_jobs_user ON audio_jobs(user_id, created_at DESC);
CREATE INDEX idx_audio_jobs_status ON audio_jobs(status) WHERE status IN ('queued', 'processing');

-- ============================================================
-- TABELA: prompts (Biblioteca de prompts)
-- ============================================================
CREATE TABLE prompts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  title VARCHAR(255) NOT NULL,
  body TEXT NOT NULL,
  tags TEXT[] DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_prompts_user ON prompts(user_id);
CREATE INDEX idx_prompts_tags ON prompts USING GIN(tags);

-- ============================================================
-- TABELA: references (Canais/ideias de referência)
-- ============================================================
CREATE TABLE "references" (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  channel_id UUID REFERENCES project_channels(id) ON DELETE SET NULL,
  title VARCHAR(255) NOT NULL,
  url VARCHAR(500),
  niche VARCHAR(100),
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_references_user ON "references"(user_id);
CREATE INDEX idx_references_niche ON "references"(niche) WHERE niche IS NOT NULL;

-- ============================================================
-- TABELA: idea_board (Quadro de ideias)
-- ============================================================
CREATE TABLE idea_board (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  channel_id UUID REFERENCES project_channels(id) ON DELETE SET NULL,
  content TEXT NOT NULL,
  color VARCHAR(20) DEFAULT 'default',
  sort_order INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_ideas_user ON idea_board(user_id);

-- ============================================================
-- TABELA: trend_viral_videos (Cache de vídeos virais)
-- ============================================================
CREATE TABLE trend_viral_videos (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  query_term VARCHAR(255) NOT NULL,
  language VARCHAR(10) NOT NULL DEFAULT 'pt',
  time_window VARCHAR(20) NOT NULL DEFAULT '24h',
  video_external_id VARCHAR(50) NOT NULL,
  title VARCHAR(500) NOT NULL,
  channel_name VARCHAR(255),
  channel_external_id VARCHAR(50),
  views BIGINT DEFAULT 0,
  likes BIGINT DEFAULT 0,
  published_at TIMESTAMPTZ,
  thumbnail_url VARCHAR(500),
  captured_at TIMESTAMPTZ DEFAULT NOW(),

  UNIQUE(video_external_id, query_term, time_window)
);

CREATE INDEX idx_viral_videos_query ON trend_viral_videos(query_term, language, time_window, captured_at DESC);

-- ============================================================
-- TABELA: viral_channel_candidates (Nichos Virais - Scanner)
-- ============================================================
CREATE TABLE viral_channel_candidates (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  youtube_channel_id VARCHAR(50) NOT NULL UNIQUE,
  title VARCHAR(255) NOT NULL,
  first_seen_at TIMESTAMPTZ DEFAULT NOW(),
  last_seen_at TIMESTAMPTZ DEFAULT NOW(),
  days_posting INTEGER DEFAULT 0,
  total_views BIGINT DEFAULT 0,
  subscribers BIGINT DEFAULT 0,
  videos_count INTEGER DEFAULT 0,
  is_monetized BOOLEAN DEFAULT FALSE,
  category viral_channel_category DEFAULT 'other',
  is_removed BOOLEAN DEFAULT FALSE,
  removed_at TIMESTAMPTZ,
  thumbnail_url VARCHAR(500),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_viral_channels_category ON viral_channel_candidates(category, is_removed);
CREATE INDEX idx_viral_channels_removed ON viral_channel_candidates(is_removed, removed_at DESC) WHERE is_removed = TRUE;

-- ============================================================
-- TABELA: insight_jobs (Jobs de análise de canal)
-- ============================================================
CREATE TABLE insight_jobs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  youtube_channel_url VARCHAR(500) NOT NULL,
  max_videos INTEGER DEFAULT 100,
  order_by VARCHAR(20) DEFAULT 'recent',
  status insight_job_status DEFAULT 'queued',
  output_txt_asset_id UUID REFERENCES assets(id) ON DELETE SET NULL,
  error_message TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  finished_at TIMESTAMPTZ
);

CREATE INDEX idx_insight_jobs_user ON insight_jobs(user_id, created_at DESC);

-- ============================================================
-- TABELA: notifications
-- ============================================================
CREATE TABLE notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  type VARCHAR(50) NOT NULL,
  title VARCHAR(255) NOT NULL,
  payload JSONB DEFAULT '{}',
  action_url VARCHAR(500),
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_notifications_user_unread ON notifications(user_id, created_at DESC) WHERE read_at IS NULL;

-- ============================================================
-- TABELA: usage_counters (Controle de quota diária)
-- ============================================================
CREATE TABLE usage_counters (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  date DATE NOT NULL DEFAULT CURRENT_DATE,
  audios_generated INTEGER DEFAULT 0,
  chars_processed BIGINT DEFAULT 0,

  UNIQUE(user_id, date)
);

-- ============================================================
-- FUNCTIONS: Helpers
-- ============================================================

-- Função para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Triggers de updated_at
CREATE TRIGGER trg_profiles_updated BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_channels_updated BEFORE UPDATE ON project_channels
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_scripts_updated BEFORE UPDATE ON scripts
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_videos_updated BEFORE UPDATE ON video_items
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_prompts_updated BEFORE UPDATE ON prompts
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_ideas_updated BEFORE UPDATE ON idea_board
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER trg_viral_channels_updated BEFORE UPDATE ON viral_channel_candidates
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ============================================================
-- FUNCTION: Transição automática de status do vídeo
-- Quando um roteiro é vinculado, muda para 'production'
-- ============================================================
CREATE OR REPLACE FUNCTION auto_transition_video_status()
RETURNS TRIGGER AS $$
BEGIN
  -- Se script_id mudou de NULL para um valor, mover para production
  IF OLD.script_id IS NULL AND NEW.script_id IS NOT NULL AND OLD.status = 'planning' THEN
    NEW.status = 'production';
  END IF;

  -- Se scheduled_at foi definido e status era ready, mover para scheduled
  IF OLD.scheduled_at IS NULL AND NEW.scheduled_at IS NOT NULL AND OLD.status = 'ready' THEN
    NEW.status = 'scheduled';
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_video_auto_status BEFORE UPDATE ON video_items
  FOR EACH ROW EXECUTE FUNCTION auto_transition_video_status();

-- ============================================================
-- RLS (Row Level Security) - Supabase
-- Todas as tabelas protegidas por user_id
-- ============================================================

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_channels ENABLE ROW LEVEL SECURITY;
ALTER TABLE channel_shortcuts ENABLE ROW LEVEL SECURITY;
ALTER TABLE scripts ENABLE ROW LEVEL SECURITY;
ALTER TABLE video_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE voice_favorites ENABLE ROW LEVEL SECURITY;
ALTER TABLE assets ENABLE ROW LEVEL SECURITY;
ALTER TABLE audio_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE prompts ENABLE ROW LEVEL SECURITY;
ALTER TABLE "references" ENABLE ROW LEVEL SECURITY;
ALTER TABLE idea_board ENABLE ROW LEVEL SECURITY;
ALTER TABLE insight_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE usage_counters ENABLE ROW LEVEL SECURITY;

-- Policies: cada usuário só vê seus próprios dados
CREATE POLICY "Users see own profile" ON profiles
  FOR ALL USING (id = auth.uid());

CREATE POLICY "Users manage own channels" ON project_channels
  FOR ALL USING (user_id = auth.uid());

CREATE POLICY "Users manage own shortcuts" ON channel_shortcuts
  FOR ALL USING (channel_id IN (
    SELECT id FROM project_channels WHERE user_id = auth.uid()
  ));

CREATE POLICY "Users manage own scripts" ON scripts
  FOR ALL USING (user_id = auth.uid());

CREATE POLICY "Users manage own videos" ON video_items
  FOR ALL USING (channel_id IN (
    SELECT id FROM project_channels WHERE user_id = auth.uid()
  ));

CREATE POLICY "Users manage own voice favorites" ON voice_favorites
  FOR ALL USING (user_id = auth.uid());

CREATE POLICY "Users manage own assets" ON assets
  FOR ALL USING (user_id = auth.uid());

CREATE POLICY "Users manage own audio jobs" ON audio_jobs
  FOR ALL USING (user_id = auth.uid());

CREATE POLICY "Users manage own prompts" ON prompts
  FOR ALL USING (user_id = auth.uid());

CREATE POLICY "Users manage own references" ON "references"
  FOR ALL USING (user_id = auth.uid());

CREATE POLICY "Users manage own ideas" ON idea_board
  FOR ALL USING (user_id = auth.uid());

CREATE POLICY "Users manage own insight jobs" ON insight_jobs
  FOR ALL USING (user_id = auth.uid());

CREATE POLICY "Users manage own notifications" ON notifications
  FOR ALL USING (user_id = auth.uid());

CREATE POLICY "Users manage own usage" ON usage_counters
  FOR ALL USING (user_id = auth.uid());

-- Vozes e tendências são públicas (read-only para todos)
ALTER TABLE voices ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Voices are readable by all" ON voices
  FOR SELECT USING (TRUE);

ALTER TABLE trend_viral_videos ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Trends are readable by all" ON trend_viral_videos
  FOR SELECT USING (TRUE);

ALTER TABLE viral_channel_candidates ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Viral channels are readable by all" ON viral_channel_candidates
  FOR SELECT USING (TRUE);

-- ============================================================
-- SEED: Vozes iniciais (exemplos)
-- ============================================================

-- Google TTS voices (amostras)
INSERT INTO voices (provider, provider_voice_id, name, gender, language_tags, is_active) VALUES
  ('google', 'pt-BR-Standard-A', 'Google Ana (Standard)', 'female', '{pt-BR}', TRUE),
  ('google', 'pt-BR-Standard-B', 'Google Bruno (Standard)', 'male', '{pt-BR}', TRUE),
  ('google', 'pt-BR-Wavenet-A', 'Google Ana (WaveNet)', 'female', '{pt-BR}', TRUE),
  ('google', 'pt-BR-Wavenet-B', 'Google Bruno (WaveNet)', 'male', '{pt-BR}', TRUE),
  ('google', 'pt-BR-Studio-B', 'Google Studio Masculino', 'male', '{pt-BR}', TRUE),
  ('google', 'en-US-Wavenet-D', 'Google David (WaveNet EN)', 'male', '{en-US}', TRUE),
  ('google', 'en-US-Wavenet-F', 'Google Fiona (WaveNet EN)', 'female', '{en-US}', TRUE),
  ('google', 'es-ES-Wavenet-B', 'Google Carlos (WaveNet ES)', 'male', '{es-ES}', TRUE);

-- ============================================================
-- FIM DA MIGRATION
-- ============================================================
