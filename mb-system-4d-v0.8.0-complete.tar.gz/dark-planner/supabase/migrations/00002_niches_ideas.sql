-- ============================================================
-- Migration: Monitored Niches + Removed Channels
-- ============================================================

CREATE TABLE IF NOT EXISTS monitored_niches (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  name TEXT NOT NULL,
  keywords TEXT[] DEFAULT '{}',
  region TEXT DEFAULT 'BR',
  last_scanned_at TIMESTAMPTZ,
  scan_count INT DEFAULT 0,
  avg_viral_score NUMERIC(5,2),
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE monitored_niches ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage own niches" ON monitored_niches FOR ALL USING (auth.uid() = user_id);

CREATE TABLE IF NOT EXISTS removed_channels (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  channel_name TEXT NOT NULL,
  channel_url TEXT,
  niche TEXT,
  reason TEXT NOT NULL DEFAULT 'unknown',
  subscribers_at_removal INT,
  detected_at TIMESTAMPTZ DEFAULT now(),
  notes TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE removed_channels ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage own removed channels" ON removed_channels FOR ALL USING (auth.uid() = user_id);

-- Idea board table (F5)
CREATE TABLE IF NOT EXISTS idea_board (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  channel_id UUID REFERENCES project_channels(id) ON DELETE SET NULL,
  content TEXT NOT NULL,
  color TEXT DEFAULT 'cyan',
  sort_order INT DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

ALTER TABLE idea_board ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage own ideas" ON idea_board FOR ALL USING (auth.uid() = user_id);
