-- ============================================================
-- Migration F5: Prompts, Referências e Quadro de Ideias
-- MB SYSTEM 4D - Canais Dark Globais
-- ============================================================

-- Prompts
CREATE TABLE IF NOT EXISTS prompts (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title       TEXT NOT NULL,
  body        TEXT NOT NULL DEFAULT '',
  tags        TEXT[] NOT NULL DEFAULT '{}',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE prompts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage own prompts" ON prompts FOR ALL USING (auth.uid() = user_id);
CREATE INDEX idx_prompts_user ON prompts(user_id);
CREATE INDEX idx_prompts_tags ON prompts USING GIN(tags);

-- References
CREATE TABLE IF NOT EXISTS references (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  channel_id  UUID REFERENCES project_channels(id) ON DELETE SET NULL,
  title       TEXT NOT NULL,
  url         TEXT NOT NULL DEFAULT '',
  niche       TEXT NOT NULL DEFAULT '',
  notes       TEXT NOT NULL DEFAULT '',
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE references ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage own references" ON references FOR ALL USING (auth.uid() = user_id);
CREATE INDEX idx_references_user ON references(user_id);
CREATE INDEX idx_references_channel ON references(channel_id);

-- Ideas (Quadro de Ideias)
CREATE TABLE IF NOT EXISTS ideas (
  id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  channel_id  UUID REFERENCES project_channels(id) ON DELETE SET NULL,
  title       TEXT NOT NULL,
  body        TEXT NOT NULL DEFAULT '',
  color       TEXT NOT NULL DEFAULT 'cyan',
  pinned      BOOLEAN NOT NULL DEFAULT false,
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE ideas ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users manage own ideas" ON ideas FOR ALL USING (auth.uid() = user_id);
CREATE INDEX idx_ideas_user ON ideas(user_id);
CREATE INDEX idx_ideas_channel ON ideas(channel_id);
