'use client';

import { VIDEO_STATUS_CONFIG, type VideoStatus } from '@/lib/supabase/types';

interface StatusBadgeProps {
  status: VideoStatus;
  size?: 'sm' | 'md';
}

export function StatusBadge({ status, size = 'sm' }: StatusBadgeProps) {
  const config = VIDEO_STATUS_CONFIG[status];
  const cls = size === 'sm' ? 'text-[10px] px-2 py-0.5' : 'text-xs px-2.5 py-1';

  return (
    <span className={`dp-badge-${config.color} ${cls}`}>
      {config.label}
    </span>
  );
}
