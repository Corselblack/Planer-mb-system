'use client';

import { LucideIcon } from 'lucide-react';

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  description: string;
  action?: {
    label: string;
    onClick: () => void;
  };
}

export function EmptyState({ icon: Icon, title, description, action }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-center">
      <div className="p-4 rounded-2xl bg-dp-accent-cyan/10 mb-4">
        <Icon size={32} className="text-dp-accent-cyan" />
      </div>
      <h3 className="text-base font-semibold text-dp-text-primary mb-1">{title}</h3>
      <p className="text-sm text-dp-text-secondary max-w-sm mb-4">{description}</p>
      {action && (
        <button onClick={action.onClick} className="dp-btn-primary text-sm">
          {action.label}
        </button>
      )}
    </div>
  );
}
