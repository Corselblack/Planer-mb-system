'use client';

import { Bell, Search, Mic } from 'lucide-react';
import { cn } from '@/lib/utils';

interface HeaderProps {
  title: string;
  subtitle?: string;
}

export function Header({ title, subtitle }: HeaderProps) {
  return (
    <header className="sticky top-0 z-30 h-16 border-b border-dp-border-primary bg-dp-bg-primary/80 backdrop-blur-md">
      <div className="flex items-center justify-between h-full px-6">
        {/* Left: Title */}
        <div>
          <h2 className="text-lg font-semibold text-dp-text-primary">{title}</h2>
          {subtitle && (
            <p className="text-xs text-dp-text-tertiary">{subtitle}</p>
          )}
        </div>

        {/* Right: Actions */}
        <div className="flex items-center gap-3">
          {/* Audio quota badge */}
          <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-dp-bg-tertiary border border-dp-border-primary">
            <Mic size={14} className="text-dp-accent-cyan" />
            <span className="text-xs font-medium text-dp-text-secondary">
              <span className="text-dp-accent-cyan">0</span>/∞ hoje
            </span>
          </div>

          {/* Search */}
          <button className="p-2 rounded-lg hover:bg-dp-bg-hover text-dp-text-secondary hover:text-dp-text-primary transition-colors">
            <Search size={18} />
          </button>

          {/* Notifications */}
          <button className="relative p-2 rounded-lg hover:bg-dp-bg-hover text-dp-text-secondary hover:text-dp-text-primary transition-colors">
            <Bell size={18} />
            <span className="absolute top-1 right-1 w-2 h-2 rounded-full bg-dp-accent-red animate-pulse-soft" />
          </button>

          {/* Avatar */}
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-dp-accent-cyan to-dp-accent-blue flex items-center justify-center">
            <span className="text-xs font-bold text-white">M</span>
          </div>
        </div>
      </div>
    </header>
  );
}
