'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import {
  Home, Tv, FileText, Heart, Wand2, Scissors, Type, Lightbulb,
  Mic, TrendingUp, Flame, List, BarChart3, BookOpen, Users,
  Settings, Moon, Sun, Eye, ChevronLeft, ChevronRight, LogOut,
} from 'lucide-react';

interface NavItem {
  label: string;
  href: string;
  icon: React.ElementType;
}

interface NavGroup {
  title: string;
  items: NavItem[];
}

const navigation: NavGroup[] = [
  {
    title: 'GESTÃO DE CANAIS',
    items: [
      { label: 'Home', href: '/dashboard', icon: Home },
      { label: 'Canais', href: '/canais', icon: Tv },
      { label: 'Prompts', href: '/prompts', icon: FileText },
      { label: 'Referências', href: '/referencias', icon: Heart },
    ],
  },
  {
    title: 'FERRAMENTAS',
    items: [
      { label: 'Gerador de SRT', href: '/ferramentas/srt', icon: Wand2 },
      { label: 'Divisores de Texto', href: '/ferramentas/divisor', icon: Scissors },
      { label: 'Editor de Texto', href: '/ferramentas/editor', icon: Type },
      { label: 'Quadro de Ideias', href: '/ideias', icon: Lightbulb },
      { label: 'Gerador de Áudio', href: '/audio', icon: Mic },
    ],
  },
  {
    title: 'TENDÊNCIAS',
    items: [
      { label: 'Vídeos Virais', href: '/tendencias/videos-virais', icon: TrendingUp },
      { label: 'Nichos Virais', href: '/tendencias/nichos-virais', icon: Flame },
      { label: 'Lista de Nichos', href: '/tendencias/lista-nichos', icon: List },
      { label: 'Insights de Canal', href: '/insights', icon: BarChart3 },
    ],
  },
];

const bottomNav: NavItem[] = [
  { label: 'Tutoriais', href: '/tutoriais', icon: BookOpen },
  { label: 'Comunidade & Suporte', href: '/comunidade', icon: Users },
];

export function Sidebar() {
  const pathname = usePathname();
  const [collapsed, setCollapsed] = useState(false);

  return (
    <aside
      className={cn(
        'fixed left-0 top-0 h-screen flex flex-col border-r border-dp-border-primary',
        'bg-dp-bg-secondary transition-all duration-300 z-40',
        collapsed ? 'w-[68px]' : 'w-[240px]'
      )}
    >
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 h-16 border-b border-dp-border-primary">
        <div className="w-8 h-8 rounded-lg bg-dp-accent-cyan flex items-center justify-center flex-shrink-0">
          <span className="text-dp-bg-primary font-bold text-[10px]">4D</span>
        </div>
        {!collapsed && (
          <div className="overflow-hidden">
            <h1 className="text-sm font-bold text-dp-text-primary truncate">MB SYSTEM 4D</h1>
            <p className="text-[10px] text-dp-text-tertiary truncate">Canais Dark Globais</p>
          </div>
        )}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="ml-auto p-1 rounded-md hover:bg-dp-bg-hover text-dp-text-tertiary hover:text-dp-text-primary transition-colors"
        >
          {collapsed ? <ChevronRight size={16} /> : <ChevronLeft size={16} />}
        </button>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-3 px-2">
        {navigation.map((group) => (
          <div key={group.title} className="mb-4">
            {!collapsed && (
              <p className="px-3 mb-1 text-[10px] font-semibold tracking-wider text-dp-text-tertiary uppercase">
                {group.title}
              </p>
            )}
            {group.items.map((item) => {
              const isActive = pathname === item.href || pathname?.startsWith(item.href + '/');
              const Icon = item.icon;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={cn(
                    'flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition-all duration-150 mb-0.5',
                    isActive
                      ? 'bg-dp-accent-cyan/10 text-dp-accent-cyan font-medium'
                      : 'text-dp-text-secondary hover:text-dp-text-primary hover:bg-dp-bg-hover'
                  )}
                  title={collapsed ? item.label : undefined}
                >
                  <Icon size={18} className="flex-shrink-0" />
                  {!collapsed && <span className="truncate">{item.label}</span>}
                </Link>
              );
            })}
          </div>
        ))}
      </nav>

      {/* Bottom section */}
      <div className="border-t border-dp-border-primary px-2 py-3">
        {/* Theme toggles */}
        <div className={cn('flex items-center gap-1 mb-2', collapsed ? 'justify-center' : 'px-1')}>
          <button className="p-1.5 rounded-md hover:bg-dp-bg-hover text-dp-text-tertiary hover:text-dp-text-primary transition-colors">
            <Eye size={16} />
          </button>
          {!collapsed && (
            <>
              <button className="p-1.5 rounded-md hover:bg-dp-bg-hover text-dp-text-tertiary hover:text-dp-text-primary transition-colors">
                <Moon size={16} />
              </button>
              <button className="p-1.5 rounded-md hover:bg-dp-bg-hover text-dp-text-tertiary hover:text-dp-text-primary transition-colors">
                <Settings size={16} />
              </button>
            </>
          )}
        </div>

        {bottomNav.map((item) => {
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-dp-text-secondary hover:text-dp-text-primary hover:bg-dp-bg-hover transition-all duration-150 mb-0.5"
              title={collapsed ? item.label : undefined}
            >
              <Icon size={18} className="flex-shrink-0" />
              {!collapsed && <span className="truncate">{item.label}</span>}
            </Link>
          );
        })}

        {/* Logout */}
        <button className="flex items-center gap-3 px-3 py-2 rounded-lg text-sm text-dp-accent-red/80 hover:text-dp-accent-red hover:bg-dp-accent-red/10 transition-all duration-150 w-full mt-1">
          <LogOut size={18} className="flex-shrink-0" />
          {!collapsed && <span>Sair</span>}
        </button>
      </div>
    </aside>
  );
}
