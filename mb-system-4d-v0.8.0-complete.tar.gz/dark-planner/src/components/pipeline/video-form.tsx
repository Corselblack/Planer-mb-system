'use client';

import { useState } from 'react';
import { Modal } from '@/components/ui';
import type { VideoItem, VideoStatus, Script } from '@/lib/supabase/types';

interface VideoFormProps {
  open: boolean;
  onClose: () => void;
  onSave: (data: VideoFormData) => Promise<void>;
  video?: VideoItem;
  scripts?: Script[];
  channelId: string;
}

export interface VideoFormData {
  title: string;
  description: string | null;
  script_id: string | null;
  status: VideoStatus;
  scheduled_at: string | null;
  notes: string | null;
}

export function VideoForm({ open, onClose, onSave, video, scripts = [], channelId }: VideoFormProps) {
  const isEdit = !!video;
  const [saving, setSaving] = useState(false);

  const [title, setTitle] = useState(video?.title || '');
  const [description, setDescription] = useState(video?.description || '');
  const [scriptId, setScriptId] = useState(video?.script_id || '');
  const [status, setStatus] = useState<VideoStatus>(video?.status || 'planning');
  const [scheduledAt, setScheduledAt] = useState(video?.scheduled_at?.slice(0, 16) || '');
  const [notes, setNotes] = useState(video?.notes || '');

  const handleSubmit = async () => {
    if (!title.trim()) return;
    setSaving(true);
    try {
      await onSave({
        title: title.trim(),
        description: description || null,
        script_id: scriptId || null,
        status,
        scheduled_at: scheduledAt ? new Date(scheduledAt).toISOString() : null,
        notes: notes || null,
      });
      onClose();
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={isEdit ? `Editar Vídeo` : 'Novo Vídeo'}
      size="lg"
      footer={
        <>
          <button onClick={onClose} className="dp-btn-secondary text-sm px-4 py-2">Cancelar</button>
          <button
            onClick={handleSubmit}
            disabled={!title.trim() || saving}
            className="dp-btn-primary text-sm px-4 py-2 disabled:opacity-50"
          >
            {saving ? 'Salvando...' : isEdit ? 'Salvar' : 'Criar Vídeo'}
          </button>
        </>
      }
    >
      <div className="space-y-4">
        {/* Título */}
        <div>
          <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Título do Vídeo *</label>
          <input
            type="text"
            value={title}
            onChange={e => setTitle(e.target.value)}
            placeholder="Ex: 5 Segredos do Universo que Ninguém Conta"
            className="dp-input w-full"
          />
        </div>

        {/* Descrição */}
        <div>
          <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Descrição</label>
          <textarea
            value={description}
            onChange={e => setDescription(e.target.value)}
            rows={3}
            placeholder="Descrição do vídeo para o YouTube..."
            className="dp-input w-full resize-none"
          />
        </div>

        {/* Status + Roteiro */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Status</label>
            <select value={status} onChange={e => setStatus(e.target.value as VideoStatus)} className="dp-input w-full">
              <option value="planning">Planejamento</option>
              <option value="production">Em Produção</option>
              <option value="ready">Pronto</option>
              <option value="scheduled">Agendado</option>
              <option value="published">Publicado</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Roteiro Vinculado</label>
            <select value={scriptId} onChange={e => setScriptId(e.target.value)} className="dp-input w-full">
              <option value="">Nenhum</option>
              {scripts.map(s => (
                <option key={s.id} value={s.id}>{s.title} ({s.char_count} chars)</option>
              ))}
            </select>
          </div>
        </div>

        {/* Agendar */}
        <div>
          <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Agendar Publicação</label>
          <input
            type="datetime-local"
            value={scheduledAt}
            onChange={e => setScheduledAt(e.target.value)}
            className="dp-input w-64"
          />
        </div>

        {/* Notas */}
        <div>
          <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Notas</label>
          <textarea
            value={notes}
            onChange={e => setNotes(e.target.value)}
            rows={2}
            placeholder="Anotações internas sobre este vídeo..."
            className="dp-input w-full resize-none"
          />
        </div>
      </div>
    </Modal>
  );
}
