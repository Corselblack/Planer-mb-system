'use client';

import { useState } from 'react';
import { FileText, Cog, CheckCircle, Calendar, Globe, AlertTriangle, Plus, MoreHorizontal, GripVertical, ArrowRight, Pencil, Trash2, Link2 } from 'lucide-react';
import { VIDEO_STATUS_CONFIG, type VideoStatus, type VideoItem, type Script } from '@/lib/supabase/types';
import { StatusBadge } from '@/components/ui';
import { cn } from '@/lib/utils';

type VideoWithScript = VideoItem & { scripts: Pick<Script, 'id' | 'title' | 'char_count'> | null };

interface PipelineBoardProps {
  videos: VideoWithScript[];
  onCreateVideo: (status: VideoStatus) => void;
  onEditVideo: (video: VideoItem) => void;
  onDeleteVideo: (id: string) => void;
  onMoveVideo: (id: string, newStatus: VideoStatus) => void;
}

const COLUMNS: { status: VideoStatus; icon: typeof FileText; color: string }[] = [
  { status: 'planning', icon: FileText, color: 'dp-accent-blue' },
  { status: 'production', icon: Cog, color: 'dp-accent-orange' },
  { status: 'ready', icon: CheckCircle, color: 'dp-accent-purple' },
  { status: 'scheduled', icon: Calendar, color: 'dp-accent-yellow' },
  { status: 'published', icon: Globe, color: 'dp-accent-green' },
  { status: 'overdue', icon: AlertTriangle, color: 'dp-accent-red' },
];

const STATUS_ORDER: VideoStatus[] = ['planning', 'production', 'ready', 'scheduled', 'published'];

export function PipelineBoard({ videos, onCreateVideo, onEditVideo, onDeleteVideo, onMoveVideo }: PipelineBoardProps) {
  const [dragging, setDragging] = useState<string | null>(null);
  const [dragOver, setDragOver] = useState<VideoStatus | null>(null);

  const handleDragStart = (e: React.DragEvent, videoId: string) => {
    e.dataTransfer.setData('text/plain', videoId);
    setDragging(videoId);
  };

  const handleDragOver = (e: React.DragEvent, status: VideoStatus) => {
    e.preventDefault();
    setDragOver(status);
  };

  const handleDrop = (e: React.DragEvent, status: VideoStatus) => {
    e.preventDefault();
    const videoId = e.dataTransfer.getData('text/plain');
    if (videoId) onMoveVideo(videoId, status);
    setDragging(null);
    setDragOver(null);
  };

  const handleDragEnd = () => {
    setDragging(null);
    setDragOver(null);
  };

  return (
    <div className="flex gap-3 overflow-x-auto pb-4 min-h-[60vh]">
      {COLUMNS.map(({ status, icon: Icon, color }) => {
        const config = VIDEO_STATUS_CONFIG[status];
        const columnVideos = videos.filter(v => v.status === status);
        const isDragTarget = dragOver === status;

        return (
          <div
            key={status}
            className={cn(
              'flex-shrink-0 w-[260px] flex flex-col rounded-xl border transition-colors',
              isDragTarget
                ? 'border-dp-accent-cyan bg-dp-accent-cyan/5'
                : 'border-dp-border-primary bg-dp-bg-secondary/50',
            )}
            onDragOver={e => handleDragOver(e, status)}
            onDragLeave={() => setDragOver(null)}
            onDrop={e => handleDrop(e, status)}
          >
            {/* Column Header */}
            <div className="flex items-center justify-between px-3 py-2.5 border-b border-dp-border-primary">
              <div className="flex items-center gap-2">
                <Icon size={14} className={`text-${color}`} />
                <span className="text-xs font-semibold text-dp-text-primary">{config.label}</span>
                <span className="text-[10px] text-dp-text-tertiary bg-dp-bg-tertiary px-1.5 py-0.5 rounded-full">
                  {columnVideos.length}
                </span>
              </div>
              <button
                onClick={() => onCreateVideo(status)}
                className="p-1 rounded hover:bg-dp-bg-hover text-dp-text-tertiary hover:text-dp-accent-cyan transition-colors"
                title="Adicionar vídeo"
              >
                <Plus size={14} />
              </button>
            </div>

            {/* Cards */}
            <div className="flex-1 p-2 space-y-2 overflow-y-auto max-h-[calc(60vh-48px)]">
              {columnVideos.map(video => (
                <VideoCard
                  key={video.id}
                  video={video}
                  isDragging={dragging === video.id}
                  onEdit={() => onEditVideo(video)}
                  onDelete={() => onDeleteVideo(video.id)}
                  onMove={(newStatus) => onMoveVideo(video.id, newStatus)}
                  currentStatus={status}
                  onDragStart={e => handleDragStart(e, video.id)}
                  onDragEnd={handleDragEnd}
                />
              ))}

              {columnVideos.length === 0 && (
                <div className="flex flex-col items-center justify-center py-8 text-center">
                  <p className="text-[10px] text-dp-text-tertiary mb-2">Sem vídeos</p>
                  <button
                    onClick={() => onCreateVideo(status)}
                    className="text-[10px] text-dp-accent-cyan hover:underline"
                  >
                    + Adicionar
                  </button>
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ============================================================
// VideoCard
// ============================================================

interface VideoCardProps {
  video: VideoWithScript;
  isDragging: boolean;
  onEdit: () => void;
  onDelete: () => void;
  onMove: (status: VideoStatus) => void;
  currentStatus: VideoStatus;
  onDragStart: (e: React.DragEvent) => void;
  onDragEnd: () => void;
}

function VideoCard({ video, isDragging, onEdit, onDelete, onMove, currentStatus, onDragStart, onDragEnd }: VideoCardProps) {
  const [showMenu, setShowMenu] = useState(false);
  const currentIdx = STATUS_ORDER.indexOf(currentStatus);
  const nextStatus = currentIdx >= 0 && currentIdx < STATUS_ORDER.length - 1 ? STATUS_ORDER[currentIdx + 1] : null;

  return (
    <div
      draggable
      onDragStart={onDragStart}
      onDragEnd={onDragEnd}
      className={cn(
        'group relative rounded-lg border border-dp-border-primary bg-dp-bg-tertiary p-3 cursor-grab active:cursor-grabbing transition-all hover:border-dp-accent-cyan/30',
        isDragging && 'opacity-40 scale-95',
      )}
    >
      {/* Drag handle */}
      <div className="absolute left-1 top-3 opacity-0 group-hover:opacity-100 transition-opacity">
        <GripVertical size={12} className="text-dp-text-tertiary" />
      </div>

      {/* Title */}
      <p className="text-xs font-medium text-dp-text-primary mb-1.5 pl-3 line-clamp-2">{video.title}</p>

      {/* Script badge */}
      {video.scripts ? (
        <div className="flex items-center gap-1 mb-2 pl-3">
          <Link2 size={10} className="text-dp-accent-cyan" />
          <span className="text-[10px] text-dp-text-secondary truncate">{video.scripts.title}</span>
        </div>
      ) : (
        <div className="flex items-center gap-1 mb-2 pl-3">
          <span className="text-[10px] text-dp-text-tertiary italic">Sem roteiro</span>
        </div>
      )}

      {/* Scheduled date */}
      {video.scheduled_at && (
        <div className="flex items-center gap-1 mb-2 pl-3">
          <Calendar size={10} className="text-dp-accent-yellow" />
          <span className="text-[10px] text-dp-text-secondary">
            {new Date(video.scheduled_at).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}
          </span>
        </div>
      )}

      {/* Actions */}
      <div className="flex items-center justify-between pl-3 pt-1 opacity-0 group-hover:opacity-100 transition-opacity">
        <div className="flex gap-1">
          <button onClick={onEdit} className="p-1 rounded hover:bg-dp-bg-hover text-dp-text-tertiary hover:text-dp-accent-cyan" title="Editar">
            <Pencil size={11} />
          </button>
          <button onClick={onDelete} className="p-1 rounded hover:bg-dp-bg-hover text-dp-text-tertiary hover:text-dp-accent-red" title="Excluir">
            <Trash2 size={11} />
          </button>
        </div>

        {nextStatus && (
          <button
            onClick={() => onMove(nextStatus)}
            className="flex items-center gap-0.5 text-[9px] text-dp-accent-cyan hover:underline"
            title={`Mover para ${VIDEO_STATUS_CONFIG[nextStatus].label}`}
          >
            <ArrowRight size={10} />
            {VIDEO_STATUS_CONFIG[nextStatus].label}
          </button>
        )}
      </div>
    </div>
  );
}
