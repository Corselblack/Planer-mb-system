'use client';

import { useState } from 'react';
import { Modal } from '@/components/ui';
import { Plus, Trash2, GripVertical } from 'lucide-react';
import type { ProjectChannel, ChannelShortcut } from '@/lib/supabase/types';

interface ChannelFormProps {
  open: boolean;
  onClose: () => void;
  onSave: (data: ChannelFormData) => Promise<void>;
  channel?: ProjectChannel;
  shortcuts?: ChannelShortcut[];
}

export interface ChannelFormData {
  name: string;
  language: string;
  posting_time: string | null;
  frequency: string | null;
  default_description: string | null;
  notes: string | null;
  shortcuts: { label: string; url: string }[];
}

const LANGUAGES = [
  { value: 'pt-BR', label: 'Português (BR)' },
  { value: 'en-US', label: 'English (US)' },
  { value: 'es-ES', label: 'Español' },
  { value: 'fr-FR', label: 'Français' },
  { value: 'de-DE', label: 'Deutsch' },
];

const FREQUENCIES = ['Diário', '3x/semana', '2x/semana', 'Semanal', 'Quinzenal'];

export function ChannelForm({ open, onClose, onSave, channel, shortcuts = [] }: ChannelFormProps) {
  const isEdit = !!channel;
  const [saving, setSaving] = useState(false);

  const [name, setName] = useState(channel?.name || '');
  const [language, setLanguage] = useState(channel?.language || 'pt-BR');
  const [postingTime, setPostingTime] = useState(channel?.posting_time || '');
  const [frequency, setFrequency] = useState(channel?.frequency || '');
  const [description, setDescription] = useState(channel?.default_description || '');
  const [notes, setNotes] = useState(channel?.notes || '');
  const [localShortcuts, setLocalShortcuts] = useState<{ label: string; url: string }[]>(
    shortcuts.map(s => ({ label: s.label, url: s.url }))
  );

  const addShortcut = () => setLocalShortcuts([...localShortcuts, { label: '', url: '' }]);
  const removeShortcut = (i: number) => setLocalShortcuts(localShortcuts.filter((_, idx) => idx !== i));
  const updateShortcut = (i: number, field: 'label' | 'url', value: string) => {
    const updated = [...localShortcuts];
    updated[i][field] = value;
    setLocalShortcuts(updated);
  };

  const handleSubmit = async () => {
    if (!name.trim()) return;
    setSaving(true);
    try {
      await onSave({
        name: name.trim(),
        language,
        posting_time: postingTime || null,
        frequency: frequency || null,
        default_description: description || null,
        notes: notes || null,
        shortcuts: localShortcuts.filter(s => s.label.trim() && s.url.trim()),
      });
      onClose();
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={isEdit ? `Editar Canal: ${channel.name}` : 'Novo Canal'}
      size="lg"
      footer={
        <>
          <button onClick={onClose} className="dp-btn-secondary text-sm px-4 py-2">
            Cancelar
          </button>
          <button
            onClick={handleSubmit}
            disabled={!name.trim() || saving}
            className="dp-btn-primary text-sm px-4 py-2 disabled:opacity-50"
          >
            {saving ? 'Salvando...' : isEdit ? 'Salvar Alterações' : 'Criar Canal'}
          </button>
        </>
      }
    >
      <div className="space-y-4">
        {/* Nome */}
        <div>
          <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Nome do Canal *</label>
          <input
            type="text"
            value={name}
            onChange={e => setName(e.target.value)}
            placeholder="Ex: Curiosidades BR"
            className="dp-input w-full"
          />
        </div>

        {/* Idioma + Frequência */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Idioma</label>
            <select value={language} onChange={e => setLanguage(e.target.value)} className="dp-input w-full">
              {LANGUAGES.map(l => <option key={l.value} value={l.value}>{l.label}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Frequência</label>
            <select value={frequency} onChange={e => setFrequency(e.target.value)} className="dp-input w-full">
              <option value="">Selecionar...</option>
              {FREQUENCIES.map(f => <option key={f} value={f}>{f}</option>)}
            </select>
          </div>
        </div>

        {/* Horário */}
        <div>
          <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Horário de Postagem</label>
          <input
            type="time"
            value={postingTime}
            onChange={e => setPostingTime(e.target.value)}
            className="dp-input w-48"
          />
        </div>

        {/* Descrição Padrão */}
        <div>
          <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Descrição Padrão do Vídeo</label>
          <textarea
            value={description}
            onChange={e => setDescription(e.target.value)}
            rows={3}
            placeholder="Texto padrão que vai na descrição dos vídeos deste canal..."
            className="dp-input w-full resize-none"
          />
        </div>

        {/* Notas */}
        <div>
          <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Notas Internas</label>
          <textarea
            value={notes}
            onChange={e => setNotes(e.target.value)}
            rows={2}
            placeholder="Anotações sobre o canal, nicho, estratégia..."
            className="dp-input w-full resize-none"
          />
        </div>

        {/* Atalhos */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <label className="text-xs font-medium text-dp-text-secondary">Atalhos Rápidos</label>
            <button onClick={addShortcut} className="flex items-center gap-1 text-xs text-dp-accent-cyan hover:underline">
              <Plus size={12} /> Adicionar
            </button>
          </div>
          <div className="space-y-2">
            {localShortcuts.map((s, i) => (
              <div key={i} className="flex items-center gap-2">
                <GripVertical size={14} className="text-dp-text-tertiary flex-shrink-0" />
                <input
                  type="text"
                  value={s.label}
                  onChange={e => updateShortcut(i, 'label', e.target.value)}
                  placeholder="Label (ex: YouTube Studio)"
                  className="dp-input flex-1 text-xs py-1.5"
                />
                <input
                  type="url"
                  value={s.url}
                  onChange={e => updateShortcut(i, 'url', e.target.value)}
                  placeholder="https://..."
                  className="dp-input flex-[2] text-xs py-1.5"
                />
                <button onClick={() => removeShortcut(i)} className="p-1.5 text-dp-accent-red/60 hover:text-dp-accent-red">
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
            {localShortcuts.length === 0 && (
              <p className="text-xs text-dp-text-tertiary italic py-2">Nenhum atalho configurado</p>
            )}
          </div>
        </div>
      </div>
    </Modal>
  );
}
