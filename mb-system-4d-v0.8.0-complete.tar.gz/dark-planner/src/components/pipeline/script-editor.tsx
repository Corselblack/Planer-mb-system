'use client';

import { useState, useMemo } from 'react';
import { Modal } from '@/components/ui';
import { FileText, Copy, Check } from 'lucide-react';
import type { Script } from '@/lib/supabase/types';

interface ScriptEditorProps {
  open: boolean;
  onClose: () => void;
  onSave: (data: { title: string; body_text: string }) => Promise<void>;
  script?: Script;
}

export function ScriptEditor({ open, onClose, onSave, script }: ScriptEditorProps) {
  const isEdit = !!script;
  const [saving, setSaving] = useState(false);
  const [copied, setCopied] = useState(false);

  const [title, setTitle] = useState(script?.title || '');
  const [body, setBody] = useState(script?.body_text || '');

  const stats = useMemo(() => {
    const chars = body.length;
    const words = body.split(/\s+/).filter(Boolean).length;
    const estimatedMinutes = Math.ceil(words / 150); // ~150 palavras por minuto
    return { chars, words, estimatedMinutes };
  }, [body]);

  const handleCopy = async () => {
    await navigator.clipboard.writeText(body);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleSubmit = async () => {
    if (!title.trim()) return;
    setSaving(true);
    try {
      await onSave({ title: title.trim(), body_text: body });
      onClose();
    } finally {
      setSaving(false);
    }
  };

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={isEdit ? `Editar Roteiro` : 'Novo Roteiro'}
      size="xl"
      footer={
        <>
          <div className="flex-1 flex items-center gap-4 text-[10px] text-dp-text-tertiary">
            <span>{stats.chars.toLocaleString('pt-BR')} caracteres</span>
            <span>{stats.words.toLocaleString('pt-BR')} palavras</span>
            <span>~{stats.estimatedMinutes} min narração</span>
          </div>
          <button onClick={onClose} className="dp-btn-secondary text-sm px-4 py-2">Cancelar</button>
          <button
            onClick={handleSubmit}
            disabled={!title.trim() || saving}
            className="dp-btn-primary text-sm px-4 py-2 disabled:opacity-50"
          >
            {saving ? 'Salvando...' : isEdit ? 'Salvar' : 'Criar Roteiro'}
          </button>
        </>
      }
    >
      <div className="space-y-4">
        {/* Título */}
        <div>
          <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Título do Roteiro *</label>
          <input
            type="text"
            value={title}
            onChange={e => setTitle(e.target.value)}
            placeholder="Ex: Roteiro - 5 Segredos do Universo"
            className="dp-input w-full"
          />
        </div>

        {/* Body */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-medium text-dp-text-secondary flex items-center gap-1.5">
              <FileText size={12} />
              Texto do Roteiro
            </label>
            <button
              onClick={handleCopy}
              className="flex items-center gap-1 text-[10px] text-dp-accent-cyan hover:underline"
            >
              {copied ? <Check size={10} /> : <Copy size={10} />}
              {copied ? 'Copiado!' : 'Copiar'}
            </button>
          </div>
          <textarea
            value={body}
            onChange={e => setBody(e.target.value)}
            rows={16}
            placeholder="Cole ou escreva o roteiro aqui. Este texto será usado para gerar áudio via TTS..."
            className="dp-input w-full resize-y font-mono text-sm leading-relaxed"
          />
        </div>
      </div>
    </Modal>
  );
}
