'use client';

import { cn } from '@/lib/utils';
import { LucideIcon } from 'lucide-react';

interface StatCardProps {
  label: string;
  value: number | string;
  icon: LucideIcon;
  color: 'cyan' | 'blue' | 'green' | 'yellow' | 'orange' | 'red' | 'purple';
  trend?: string;
}

const colorMap = {
  cyan:   { bg: 'bg-dp-accent-cyan/10',   text: 'text-dp-accent-cyan',   border: 'border-dp-accent-cyan/20' },
  blue:   { bg: 'bg-dp-accent-blue/10',   text: 'text-dp-accent-blue',   border: 'border-dp-accent-blue/20' },
  green:  { bg: 'bg-dp-accent-green/10',  text: 'text-dp-accent-green',  border: 'border-dp-accent-green/20' },
  yellow: { bg: 'bg-dp-accent-yellow/10', text: 'text-dp-accent-yellow', border: 'border-dp-accent-yellow/20' },
  orange: { bg: 'bg-dp-accent-orange/10', text: 'text-dp-accent-orange', border: 'border-dp-accent-orange/20' },
  red:    { bg: 'bg-dp-accent-red/10',    text: 'text-dp-accent-red',    border: 'border-dp-accent-red/20' },
  purple: { bg: 'bg-dp-accent-purple/10', text: 'text-dp-accent-purple', border: 'border-dp-accent-purple/20' },
};

export function StatCard({ label, value, icon: Icon, color, trend }: StatCardProps) {
  const c = colorMap[color];

  return (
    <div className={cn(
      'dp-card flex items-start gap-4 group',
      c.border,
    )}>
      <div className={cn('p-2.5 rounded-lg', c.bg)}>
        <Icon size={20} className={c.text} />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-xs text-dp-text-secondary mb-1">{label}</p>
        <div className="flex items-baseline gap-2">
          <p className={cn('text-2xl font-bold', c.text)}>{value}</p>
          {trend && (
            <span className="text-[10px] text-dp-accent-green font-medium">{trend}</span>
          )}
        </div>
      </div>
    </div>
  );
}
