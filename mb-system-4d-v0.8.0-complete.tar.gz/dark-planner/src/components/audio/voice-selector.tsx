'use client';

import { useState, useMemo } from 'react';
import { Mic, Play, Star, Search, Filter } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { Voice, TTSProvider, VoiceGender } from '@/lib/supabase/types';

interface VoiceSelectorProps {
  voices: Voice[];
  selectedId: string | null;
  onSelect: (voice: Voice) => void;
}

export function VoiceSelector({ voices, selectedId, onSelect }: VoiceSelectorProps) {
  const [search, setSearch] = useState('');
  const [filterProvider, setFilterProvider] = useState<TTSProvider | 'all'>('all');
  const [filterGender, setFilterGender] = useState<VoiceGender | 'all'>('all');
  const [filterLang, setFilterLang] = useState<string>('all');

  const languages = useMemo(() => {
    const tags = new Set<string>();
    voices.forEach(v => v.language_tags.forEach(t => tags.add(t)));
    return Array.from(tags).sort();
  }, [voices]);

  const filtered = useMemo(() => {
    return voices.filter(v => {
      if (search && !v.name.toLowerCase().includes(search.toLowerCase())) return false;
      if (filterProvider !== 'all' && v.provider !== filterProvider) return false;
      if (filterGender !== 'all' && v.gender !== filterGender) return false;
      if (filterLang !== 'all' && !v.language_tags.includes(filterLang)) return false;
      return true;
    });
  }, [voices, search, filterProvider, filterGender, filterLang]);

  return (
    <div className="space-y-3">
      {/* Search */}
      <div className="relative">
        <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-dp-text-tertiary" />
        <input
          type="text"
          value={search}
          onChange={e => setSearch(e.target.value)}
          placeholder="Buscar voz..."
          className="dp-input w-full pl-8 text-xs py-2"
        />
      </div>

      {/* Filters */}
      <div className="flex items-center gap-2 flex-wrap">
        <Filter size={12} className="text-dp-text-tertiary" />
        <select value={filterProvider} onChange={e => setFilterProvider(e.target.value as any)} className="dp-input text-[10px] py-1 px-2">
          <option value="all">Todos providers</option>
          <option value="google">Google TTS</option>
          <option value="elevenlabs">ElevenLabs</option>
        </select>
        <select value={filterGender} onChange={e => setFilterGender(e.target.value as any)} className="dp-input text-[10px] py-1 px-2">
          <option value="all">Todos gêneros</option>
          <option value="male">Masculino</option>
          <option value="female">Feminino</option>
          <option value="neutral">Neutro</option>
        </select>
        <select value={filterLang} onChange={e => setFilterLang(e.target.value)} className="dp-input text-[10px] py-1 px-2">
          <option value="all">Todos idiomas</option>
          {languages.map(l => <option key={l} value={l}>{l}</option>)}
        </select>
      </div>

      {/* Voice list */}
      <div className="space-y-1 max-h-64 overflow-y-auto">
        {filtered.map(voice => (
          <div
            key={voice.id || voice.provider_voice_id}
            onClick={() => onSelect(voice)}
            className={cn(
              'flex items-center gap-3 px-3 py-2.5 rounded-lg cursor-pointer transition-colors',
              selectedId === voice.id
                ? 'bg-dp-accent-cyan/10 border border-dp-accent-cyan/30'
                : 'hover:bg-dp-bg-hover border border-transparent',
            )}
          >
            <div className={cn(
              'w-8 h-8 rounded-lg flex items-center justify-center',
              voice.provider === 'google' ? 'bg-dp-accent-blue/10' : 'bg-dp-accent-purple/10',
            )}>
              <Mic size={14} className={voice.provider === 'google' ? 'text-dp-accent-blue' : 'text-dp-accent-purple'} />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-dp-text-primary truncate">{voice.name}</p>
              <div className="flex items-center gap-2 mt-0.5">
                <span className={`dp-badge-${voice.provider === 'google' ? 'blue' : 'purple'}`} style={{ fontSize: 8, padding: '1px 5px' }}>
                  {voice.provider === 'google' ? 'Google' : 'ElevenLabs'}
                </span>
                <span className="text-[9px] text-dp-text-tertiary">{voice.gender}</span>
                <span className="text-[9px] text-dp-text-tertiary">{voice.language_tags.join(', ')}</span>
                {voice.is_clone && <span className="dp-badge-cyan" style={{ fontSize: 8, padding: '1px 5px' }}>Clone</span>}
              </div>
            </div>
            {voice.preview_url && (
              <button className="p-1.5 rounded hover:bg-dp-bg-tertiary" onClick={e => { e.stopPropagation(); /* TODO: play preview */ }}>
                <Play size={12} className="text-dp-text-tertiary" />
              </button>
            )}
          </div>
        ))}
        {filtered.length === 0 && (
          <p className="text-center text-xs text-dp-text-tertiary py-6">Nenhuma voz encontrada</p>
        )}
      </div>
    </div>
  );
}
