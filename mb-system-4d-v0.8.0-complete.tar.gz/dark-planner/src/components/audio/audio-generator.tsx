'use client';

import { useState, useMemo } from 'react';
import { Mic, Play, Download, FileText, Volume2, Gauge, AlignLeft, Loader2, CheckCircle, AlertCircle } from 'lucide-react';
import { VoiceSelector } from './voice-selector';
import { cn } from '@/lib/utils';
import type { Voice, Script } from '@/lib/supabase/types';

interface AudioGeneratorProps {
  voices: Voice[];
  scripts?: Script[];
  channelId?: string;
  onGenerate?: (result: GenerateResult) => void;
}

interface GenerateResult {
  audio_url: string;
  srt_url: string;
  view_srt_url: string;
}

type GenerateStatus = 'idle' | 'generating' | 'success' | 'error';

export function AudioGenerator({ voices, scripts = [], channelId, onGenerate }: AudioGeneratorProps) {
  // Input
  const [text, setText] = useState('');
  const [selectedVoice, setSelectedVoice] = useState<Voice | null>(null);
  const [selectedScript, setSelectedScript] = useState<string>('');

  // Params
  const [speed, setSpeed] = useState(1.0);
  const [volume, setVolume] = useState(1.0);
  const [wordsPerCaption, setWordsPerCaption] = useState(5);
  const [name, setName] = useState('');

  // State
  const [status, setStatus] = useState<GenerateStatus>('idle');
  const [result, setResult] = useState<GenerateResult | null>(null);
  const [error, setError] = useState('');

  const stats = useMemo(() => {
    const chars = text.length;
    const words = text.split(/\s+/).filter(Boolean).length;
    const minutes = Math.ceil(words / (150 * speed));
    return { chars, words, minutes };
  }, [text, speed]);

  const handleScriptSelect = (scriptId: string) => {
    setSelectedScript(scriptId);
    const script = scripts.find(s => s.id === scriptId);
    if (script) {
      setText(script.body_text);
      if (!name) setName(script.title);
    }
  };

  const handleGenerate = async () => {
    if (!text.trim() || !selectedVoice) return;
    setStatus('generating');
    setError('');
    setResult(null);

    try {
      const res = await fetch('/api/audio/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text,
          voice_id: selectedVoice.id,
          provider: selectedVoice.provider,
          provider_voice_id: selectedVoice.provider_voice_id,
          name: name || `Audio_${Date.now()}`,
          channel_id: channelId || null,
          script_id: selectedScript || null,
          speed,
          volume,
          words_per_caption: wordsPerCaption,
        }),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error || 'Erro na geração');
      }

      const data = await res.json();
      setResult(data);
      setStatus('success');
      onGenerate?.(data);
    } catch (err: any) {
      setError(err.message);
      setStatus('error');
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      {/* Left: Text input */}
      <div className="lg:col-span-2 space-y-4">
        {/* Script selector */}
        {scripts.length > 0 && (
          <div>
            <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Importar de Roteiro</label>
            <select
              value={selectedScript}
              onChange={e => handleScriptSelect(e.target.value)}
              className="dp-input w-full text-xs"
            >
              <option value="">Selecionar roteiro...</option>
              {scripts.map(s => (
                <option key={s.id} value={s.id}>{s.title} ({s.char_count} chars)</option>
              ))}
            </select>
          </div>
        )}

        {/* Name */}
        <div>
          <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Nome do Áudio</label>
          <input
            type="text"
            value={name}
            onChange={e => setName(e.target.value)}
            placeholder="Ex: Ep48 - Segredos do Universo"
            className="dp-input w-full text-xs"
          />
        </div>

        {/* Text area */}
        <div>
          <div className="flex items-center justify-between mb-1.5">
            <label className="text-xs font-medium text-dp-text-secondary flex items-center gap-1.5">
              <FileText size={12} /> Texto para Narração
            </label>
            <div className="flex items-center gap-3 text-[10px] text-dp-text-tertiary">
              <span>{stats.chars.toLocaleString('pt-BR')} chars</span>
              <span>{stats.words} palavras</span>
              <span>~{stats.minutes} min</span>
            </div>
          </div>
          <textarea
            value={text}
            onChange={e => setText(e.target.value)}
            rows={14}
            placeholder="Cole ou escreva o texto que será narrado..."
            className="dp-input w-full resize-y font-mono text-sm leading-relaxed"
          />
        </div>

        {/* Params */}
        <div className="grid grid-cols-3 gap-4">
          <div>
            <label className="flex items-center gap-1.5 text-xs font-medium text-dp-text-secondary mb-1.5">
              <Gauge size={12} /> Velocidade: {speed.toFixed(1)}x
            </label>
            <input
              type="range"
              min="0.5" max="2.0" step="0.1"
              value={speed}
              onChange={e => setSpeed(parseFloat(e.target.value))}
              className="w-full accent-dp-accent-cyan"
            />
          </div>
          <div>
            <label className="flex items-center gap-1.5 text-xs font-medium text-dp-text-secondary mb-1.5">
              <Volume2 size={12} /> Volume: {Math.round(volume * 100)}%
            </label>
            <input
              type="range"
              min="0" max="1" step="0.05"
              value={volume}
              onChange={e => setVolume(parseFloat(e.target.value))}
              className="w-full accent-dp-accent-cyan"
            />
          </div>
          <div>
            <label className="flex items-center gap-1.5 text-xs font-medium text-dp-text-secondary mb-1.5">
              <AlignLeft size={12} /> Palavras/Legenda: {wordsPerCaption}
            </label>
            <input
              type="range"
              min="2" max="10" step="1"
              value={wordsPerCaption}
              onChange={e => setWordsPerCaption(parseInt(e.target.value))}
              className="w-full accent-dp-accent-cyan"
            />
          </div>
        </div>

        {/* Generate button */}
        <button
          onClick={handleGenerate}
          disabled={!text.trim() || !selectedVoice || status === 'generating'}
          className="dp-btn-primary w-full py-3 text-sm flex items-center justify-center gap-2 disabled:opacity-50"
        >
          {status === 'generating' ? (
            <><Loader2 size={16} className="animate-spin" /> Gerando áudio...</>
          ) : (
            <><Mic size={16} /> Gerar Áudio + SRT</>
          )}
        </button>

        {/* Result */}
        {status === 'success' && result && (
          <div className="dp-card border-dp-accent-green/30 space-y-3">
            <div className="flex items-center gap-2">
              <CheckCircle size={16} className="text-dp-accent-green" />
              <span className="text-sm font-medium text-dp-accent-green">Áudio gerado com sucesso!</span>
            </div>
            <div className="flex items-center gap-3">
              <a href={result.audio_url} target="_blank" className="dp-btn-primary text-xs flex items-center gap-1.5">
                <Download size={12} /> Download MP3
              </a>
              <a href={result.srt_url} target="_blank" className="dp-btn-secondary text-xs flex items-center gap-1.5">
                <Download size={12} /> Download SRT
              </a>
              <a href={result.view_srt_url} target="_blank" className="dp-btn-secondary text-xs flex items-center gap-1.5">
                <Download size={12} /> SRT View (8s)
              </a>
            </div>
          </div>
        )}

        {status === 'error' && (
          <div className="dp-card border-dp-accent-red/30">
            <div className="flex items-center gap-2">
              <AlertCircle size={16} className="text-dp-accent-red" />
              <span className="text-sm text-dp-accent-red">{error}</span>
            </div>
          </div>
        )}
      </div>

      {/* Right: Voice selector */}
      <div className="space-y-4">
        <h3 className="text-xs font-semibold text-dp-text-primary flex items-center gap-2">
          <Mic size={14} className="text-dp-accent-cyan" />
          Selecionar Voz
        </h3>

        {selectedVoice && (
          <div className="dp-card border-dp-accent-cyan/30 flex items-center gap-3">
            <div className="p-2 rounded-lg bg-dp-accent-cyan/10">
              <Mic size={14} className="text-dp-accent-cyan" />
            </div>
            <div>
              <p className="text-xs font-medium text-dp-text-primary">{selectedVoice.name}</p>
              <p className="text-[10px] text-dp-text-tertiary">
                {selectedVoice.provider === 'google' ? 'Google TTS' : 'ElevenLabs'} · {selectedVoice.language_tags.join(', ')}
              </p>
            </div>
          </div>
        )}

        <VoiceSelector
          voices={voices}
          selectedId={selectedVoice?.id || null}
          onSelect={setSelectedVoice}
        />
      </div>
    </div>
  );
}
