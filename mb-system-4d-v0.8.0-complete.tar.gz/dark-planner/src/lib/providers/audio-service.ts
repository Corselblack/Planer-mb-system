import type { TTSProvider, Voice } from '@/lib/supabase/types';

// ============================================================
// Interface comum para todos os providers TTS
// ============================================================

export interface TTSParams {
  text: string;
  voiceId: string;
  speed?: number;      // 0.5 - 2.0, default 1.0
  volume?: number;     // 0.0 - 1.0, default 1.0
}

export interface TTSResult {
  audioBuffer: ArrayBuffer;
  contentType: string;
  durationMs?: number;
  wordTimings?: WordTiming[];
}

export interface WordTiming {
  word: string;
  startMs: number;
  endMs: number;
}

export interface SRTSegment {
  index: number;
  startTime: string;  // "00:00:01,000"
  endTime: string;
  text: string;
}

export interface QuotaInfo {
  provider: TTSProvider;
  used: number;
  limit: number;
  unit: string;       // "characters" | "minutes"
  resetDate: string;
}

export interface ITTSProvider {
  readonly name: TTSProvider;
  listVoices(language?: string): Promise<Voice[]>;
  generateAudio(params: TTSParams): Promise<TTSResult>;
  getQuota(): Promise<QuotaInfo>;
}

// ============================================================
// SRT Generation Utilities
// ============================================================

export function generateSRT(wordTimings: WordTiming[], wordsPerCaption: number = 5): SRTSegment[] {
  const segments: SRTSegment[] = [];
  let idx = 1;

  for (let i = 0; i < wordTimings.length; i += wordsPerCaption) {
    const group = wordTimings.slice(i, i + wordsPerCaption);
    if (group.length === 0) continue;

    segments.push({
      index: idx++,
      startTime: msToSrtTime(group[0].startMs),
      endTime: msToSrtTime(group[group.length - 1].endMs),
      text: group.map(w => w.word).join(' '),
    });
  }

  return segments;
}

export function generateViewSRT(wordTimings: WordTiming[], segmentDurationMs: number = 8000): SRTSegment[] {
  const segments: SRTSegment[] = [];
  if (wordTimings.length === 0) return segments;

  const totalDuration = wordTimings[wordTimings.length - 1].endMs;
  let idx = 1;

  for (let startMs = 0; startMs < totalDuration; startMs += segmentDurationMs) {
    const endMs = Math.min(startMs + segmentDurationMs, totalDuration);
    const words = wordTimings.filter(w => w.startMs >= startMs && w.startMs < endMs);

    if (words.length > 0) {
      segments.push({
        index: idx++,
        startTime: msToSrtTime(startMs),
        endTime: msToSrtTime(endMs),
        text: words.map(w => w.word).join(' '),
      });
    }
  }

  return segments;
}

export function srtToString(segments: SRTSegment[]): string {
  return segments.map(s =>
    `${s.index}\n${s.startTime} --> ${s.endTime}\n${s.text}\n`
  ).join('\n');
}

// Fallback: se provider não retorna timestamps, gerar SRT estimado
export function generateEstimatedSRT(text: string, durationMs: number, wordsPerCaption: number = 5): SRTSegment[] {
  const words = text.split(/\s+/).filter(Boolean);
  const msPerWord = durationMs / words.length;
  const timings: WordTiming[] = words.map((word, i) => ({
    word,
    startMs: Math.round(i * msPerWord),
    endMs: Math.round((i + 1) * msPerWord),
  }));
  return generateSRT(timings, wordsPerCaption);
}

function msToSrtTime(ms: number): string {
  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  const mill = ms % 1000;
  return `${pad(h)}:${pad(m)}:${pad(s)},${pad3(mill)}`;
}

function pad(n: number): string { return n.toString().padStart(2, '0'); }
function pad3(n: number): string { return n.toString().padStart(3, '0'); }
