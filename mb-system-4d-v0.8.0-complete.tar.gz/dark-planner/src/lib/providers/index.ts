export { GoogleTTSProvider } from './google-tts';
export { ElevenLabsProvider } from './elevenlabs';
export {
  generateSRT,
  generateViewSRT,
  generateEstimatedSRT,
  srtToString,
  type ITTSProvider,
  type TTSParams,
  type TTSResult,
  type WordTiming,
  type SRTSegment,
  type QuotaInfo,
} from './audio-service';

import { GoogleTTSProvider } from './google-tts';
import { ElevenLabsProvider } from './elevenlabs';
import type { ITTSProvider } from './audio-service';
import type { TTSProvider } from '@/lib/supabase/types';

export function createProvider(provider: TTSProvider): ITTSProvider {
  switch (provider) {
    case 'google': return new GoogleTTSProvider();
    case 'elevenlabs': return new ElevenLabsProvider();
    default: throw new Error(`Unknown TTS provider: ${provider}`);
  }
}
