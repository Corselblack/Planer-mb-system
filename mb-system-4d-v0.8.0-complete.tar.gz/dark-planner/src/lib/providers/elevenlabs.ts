import type { Voice } from '@/lib/supabase/types';
import type { ITTSProvider, TTSParams, TTSResult, QuotaInfo, WordTiming } from './audio-service';

// ============================================================
// ElevenLabs TTS Provider (Complementar)
// ============================================================
// Free tier: ~20 min/mês (non-commercial)
// Docs: https://docs.elevenlabs.io/api-reference
// ============================================================

const API_BASE = 'https://api.elevenlabs.io/v1';

interface ELVoice {
  voice_id: string;
  name: string;
  labels?: Record<string, string>;
  preview_url?: string;
}

interface ELAlignment {
  characters: string[];
  character_start_times_seconds: number[];
  character_end_times_seconds: number[];
}

export class ElevenLabsProvider implements ITTSProvider {
  readonly name = 'elevenlabs' as const;
  private apiKey: string;

  constructor(apiKey?: string) {
    this.apiKey = apiKey || process.env.ELEVENLABS_API_KEY || '';
  }

  private headers() {
    return {
      'xi-api-key': this.apiKey,
      'Content-Type': 'application/json',
    };
  }

  async listVoices(language?: string): Promise<Voice[]> {
    const res = await fetch(`${API_BASE}/voices`, { headers: this.headers() });
    if (!res.ok) throw new Error(`ElevenLabs voices error: ${res.status}`);

    const data = await res.json();
    let voices: ELVoice[] = data.voices || [];

    // Filtrar por language se fornecido (usando labels)
    if (language) {
      voices = voices.filter(v =>
        v.labels?.language?.toLowerCase().includes(language.toLowerCase()) ||
        v.labels?.accent?.toLowerCase().includes(language.toLowerCase())
      );
    }

    return voices.map(v => ({
      id: '',
      provider: 'elevenlabs' as const,
      provider_voice_id: v.voice_id,
      name: `ElevenLabs ${v.name}`,
      gender: mapELGender(v.labels),
      language_tags: extractLanguageTags(v.labels),
      preview_url: v.preview_url || null,
      is_clone: v.labels?.use_case === 'cloned' || false,
      is_active: true,
      created_at: new Date().toISOString(),
    }));
  }

  async generateAudio(params: TTSParams): Promise<TTSResult> {
    const { text, voiceId, speed = 1.0 } = params;

    // Usar endpoint com timestamps
    const url = `${API_BASE}/text-to-speech/${voiceId}/with-timestamps`;

    const body = {
      text,
      model_id: 'eleven_multilingual_v2',
      voice_settings: {
        stability: 0.5,
        similarity_boost: 0.75,
        speed,
      },
      output_format: 'mp3_44100_128',
    };

    const res = await fetch(url, {
      method: 'POST',
      headers: this.headers(),
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      const err = await res.text();
      throw new Error(`ElevenLabs synthesis error: ${res.status} - ${err}`);
    }

    const data = await res.json();

    // audio_base64 contém o MP3
    const audioBuffer = base64ToArrayBuffer(data.audio_base64);

    // Extrair word timings do alignment
    const wordTimings = extractWordTimingsFromAlignment(text, data.alignment);

    return {
      audioBuffer,
      contentType: 'audio/mpeg',
      wordTimings,
    };
  }

  async getQuota(): Promise<QuotaInfo> {
    const res = await fetch(`${API_BASE}/user/subscription`, { headers: this.headers() });
    if (!res.ok) {
      return {
        provider: 'elevenlabs',
        used: 0,
        limit: 10000, // ~20 min free
        unit: 'characters',
        resetDate: getNextMonthReset(),
      };
    }

    const data = await res.json();
    return {
      provider: 'elevenlabs',
      used: data.character_count || 0,
      limit: data.character_limit || 10000,
      unit: 'characters',
      resetDate: data.next_character_count_reset_unix
        ? new Date(data.next_character_count_reset_unix * 1000).toISOString()
        : getNextMonthReset(),
    };
  }
}

// ============================================================
// Helpers
// ============================================================

function extractWordTimingsFromAlignment(text: string, alignment?: ELAlignment): WordTiming[] {
  if (!alignment) return [];

  const words = text.split(/\s+/).filter(Boolean);
  const timings: WordTiming[] = [];
  let charIdx = 0;

  for (const word of words) {
    // Encontrar a posição do word no texto original
    const wordStart = text.indexOf(word, charIdx);
    if (wordStart === -1) continue;

    const wordEnd = wordStart + word.length;

    // Pegar timestamps do primeiro e último caractere da palavra
    const startMs = (alignment.character_start_times_seconds[wordStart] || 0) * 1000;
    const endMs = (alignment.character_end_times_seconds[Math.min(wordEnd - 1, alignment.character_end_times_seconds.length - 1)] || 0) * 1000;

    timings.push({
      word,
      startMs: Math.round(startMs),
      endMs: Math.round(endMs),
    });

    charIdx = wordEnd;
  }

  return timings;
}

function mapELGender(labels?: Record<string, string>): 'male' | 'female' | 'neutral' {
  const gender = labels?.gender?.toLowerCase();
  if (gender === 'male') return 'male';
  if (gender === 'female') return 'female';
  return 'neutral';
}

function extractLanguageTags(labels?: Record<string, string>): string[] {
  if (!labels?.language) return [];
  const lang = labels.language.toLowerCase();
  const map: Record<string, string> = {
    portuguese: 'pt-BR', english: 'en-US', spanish: 'es-ES',
    french: 'fr-FR', german: 'de-DE', italian: 'it-IT',
    japanese: 'ja-JP', chinese: 'zh-CN', korean: 'ko-KR',
  };
  return [map[lang] || lang];
}

function base64ToArrayBuffer(base64: string): ArrayBuffer {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

function getNextMonthReset(): string {
  const d = new Date();
  d.setMonth(d.getMonth() + 1, 1);
  d.setHours(0, 0, 0, 0);
  return d.toISOString();
}
