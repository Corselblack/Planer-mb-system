// ============================================================
// YouTube Data API v3 — Service Layer
// ============================================================
// Requer: YOUTUBE_API_KEY no .env.local
// Quota: 10,000 units/day (search=100, videos.list=1, channels.list=1)
// ============================================================

const API_BASE = 'https://www.googleapis.com/youtube/v3';

function apiKey() {
  return process.env.YOUTUBE_API_KEY || '';
}

// ============================================================
// Types
// ============================================================

export interface YTVideo {
  id: string;
  title: string;
  description: string;
  channelId: string;
  channelTitle: string;
  publishedAt: string;
  thumbnailUrl: string;
  viewCount: number;
  likeCount: number;
  commentCount: number;
  duration: string;
  tags: string[];
  categoryId: string;
}

export interface YTChannel {
  id: string;
  title: string;
  description: string;
  customUrl: string;
  thumbnailUrl: string;
  subscriberCount: number;
  videoCount: number;
  viewCount: number;
  publishedAt: string;
  country: string;
}

export interface YTSearchResult {
  videoId: string;
  title: string;
  channelTitle: string;
  channelId: string;
  publishedAt: string;
  thumbnailUrl: string;
  description: string;
}

export interface ViralMetrics {
  video: YTVideo;
  viralScore: number;        // 0-100
  viewsPerDay: number;
  engagementRate: number;     // (likes + comments) / views
  ageInDays: number;
  isShort: boolean;
}

export interface ChannelInsight {
  channel: YTChannel;
  avgViewsPerVideo: number;
  uploadFrequency: string;
  topVideos: YTVideo[];
  recentGrowthScore: number;  // 0-100
  estimatedNiche: string;
}

// ============================================================
// Search
// ============================================================

export async function searchVideos(query: string, options?: {
  maxResults?: number;
  order?: 'relevance' | 'date' | 'viewCount' | 'rating';
  publishedAfter?: string;
  regionCode?: string;
  videoDuration?: 'short' | 'medium' | 'long';
}): Promise<YTSearchResult[]> {
  const params = new URLSearchParams({
    key: apiKey(),
    part: 'snippet',
    type: 'video',
    q: query,
    maxResults: String(options?.maxResults || 20),
    order: options?.order || 'viewCount',
  });
  if (options?.publishedAfter) params.set('publishedAfter', options.publishedAfter);
  if (options?.regionCode) params.set('regionCode', options.regionCode);
  if (options?.videoDuration) params.set('videoDuration', options.videoDuration);

  const res = await fetch(`${API_BASE}/search?${params}`);
  if (!res.ok) throw new Error(`YT search error: ${res.status}`);
  const data = await res.json();

  return (data.items || []).map((item: any) => ({
    videoId: item.id.videoId,
    title: item.snippet.title,
    channelTitle: item.snippet.channelTitle,
    channelId: item.snippet.channelId,
    publishedAt: item.snippet.publishedAt,
    thumbnailUrl: item.snippet.thumbnails?.high?.url || item.snippet.thumbnails?.default?.url || '',
    description: item.snippet.description,
  }));
}

// ============================================================
// Video Details (batch)
// ============================================================

export async function getVideoDetails(videoIds: string[]): Promise<YTVideo[]> {
  if (videoIds.length === 0) return [];
  const chunks = [];
  for (let i = 0; i < videoIds.length; i += 50) chunks.push(videoIds.slice(i, i + 50));

  const results: YTVideo[] = [];
  for (const chunk of chunks) {
    const params = new URLSearchParams({
      key: apiKey(),
      part: 'snippet,statistics,contentDetails',
      id: chunk.join(','),
    });
    const res = await fetch(`${API_BASE}/videos?${params}`);
    if (!res.ok) throw new Error(`YT videos error: ${res.status}`);
    const data = await res.json();

    for (const item of data.items || []) {
      results.push({
        id: item.id,
        title: item.snippet.title,
        description: item.snippet.description,
        channelId: item.snippet.channelId,
        channelTitle: item.snippet.channelTitle,
        publishedAt: item.snippet.publishedAt,
        thumbnailUrl: item.snippet.thumbnails?.high?.url || '',
        viewCount: parseInt(item.statistics.viewCount || '0'),
        likeCount: parseInt(item.statistics.likeCount || '0'),
        commentCount: parseInt(item.statistics.commentCount || '0'),
        duration: item.contentDetails.duration,
        tags: item.snippet.tags || [],
        categoryId: item.snippet.categoryId || '',
      });
    }
  }
  return results;
}

// ============================================================
// Channel Details
// ============================================================

export async function getChannelDetails(channelIds: string[]): Promise<YTChannel[]> {
  if (channelIds.length === 0) return [];
  const params = new URLSearchParams({
    key: apiKey(),
    part: 'snippet,statistics',
    id: channelIds.join(','),
  });
  const res = await fetch(`${API_BASE}/channels?${params}`);
  if (!res.ok) throw new Error(`YT channels error: ${res.status}`);
  const data = await res.json();

  return (data.items || []).map((item: any) => ({
    id: item.id,
    title: item.snippet.title,
    description: item.snippet.description,
    customUrl: item.snippet.customUrl || '',
    thumbnailUrl: item.snippet.thumbnails?.high?.url || '',
    subscriberCount: parseInt(item.statistics.subscriberCount || '0'),
    videoCount: parseInt(item.statistics.videoCount || '0'),
    viewCount: parseInt(item.statistics.viewCount || '0'),
    publishedAt: item.snippet.publishedAt,
    country: item.snippet.country || '',
  }));
}

// ============================================================
// Channel Videos (latest)
// ============================================================

export async function getChannelVideos(channelId: string, maxResults: number = 10): Promise<YTSearchResult[]> {
  const params = new URLSearchParams({
    key: apiKey(),
    part: 'snippet',
    type: 'video',
    channelId,
    maxResults: String(maxResults),
    order: 'date',
  });
  const res = await fetch(`${API_BASE}/search?${params}`);
  if (!res.ok) throw new Error(`YT channel videos error: ${res.status}`);
  const data = await res.json();

  return (data.items || []).map((item: any) => ({
    videoId: item.id.videoId,
    title: item.snippet.title,
    channelTitle: item.snippet.channelTitle,
    channelId: item.snippet.channelId,
    publishedAt: item.snippet.publishedAt,
    thumbnailUrl: item.snippet.thumbnails?.high?.url || '',
    description: item.snippet.description,
  }));
}

// ============================================================
// Trending (country-based)
// ============================================================

export async function getTrending(regionCode: string = 'BR', categoryId?: string, maxResults: number = 20): Promise<YTVideo[]> {
  const params = new URLSearchParams({
    key: apiKey(),
    part: 'snippet,statistics,contentDetails',
    chart: 'mostPopular',
    regionCode,
    maxResults: String(maxResults),
  });
  if (categoryId) params.set('videoCategoryId', categoryId);

  const res = await fetch(`${API_BASE}/videos?${params}`);
  if (!res.ok) throw new Error(`YT trending error: ${res.status}`);
  const data = await res.json();

  return (data.items || []).map((item: any) => ({
    id: item.id,
    title: item.snippet.title,
    description: item.snippet.description,
    channelId: item.snippet.channelId,
    channelTitle: item.snippet.channelTitle,
    publishedAt: item.snippet.publishedAt,
    thumbnailUrl: item.snippet.thumbnails?.high?.url || '',
    viewCount: parseInt(item.statistics.viewCount || '0'),
    likeCount: parseInt(item.statistics.likeCount || '0'),
    commentCount: parseInt(item.statistics.commentCount || '0'),
    duration: item.contentDetails.duration,
    tags: item.snippet.tags || [],
    categoryId: item.snippet.categoryId || '',
  }));
}

// ============================================================
// Viral Score Calculator
// ============================================================

export function calculateViralMetrics(video: YTVideo): ViralMetrics {
  const ageMs = Date.now() - new Date(video.publishedAt).getTime();
  const ageInDays = Math.max(ageMs / 86400000, 0.5);
  const viewsPerDay = video.viewCount / ageInDays;
  const engagementRate = video.viewCount > 0
    ? (video.likeCount + video.commentCount) / video.viewCount
    : 0;
  const isShort = parseDurationSeconds(video.duration) <= 60;

  // Viral score: weighted composite (0-100)
  let score = 0;
  // Views velocity (50% weight)
  if (viewsPerDay >= 1_000_000) score += 50;
  else if (viewsPerDay >= 100_000) score += 40;
  else if (viewsPerDay >= 10_000) score += 30;
  else if (viewsPerDay >= 1_000) score += 20;
  else if (viewsPerDay >= 100) score += 10;

  // Engagement (30% weight)
  if (engagementRate >= 0.10) score += 30;
  else if (engagementRate >= 0.05) score += 24;
  else if (engagementRate >= 0.03) score += 18;
  else if (engagementRate >= 0.01) score += 12;
  else score += 6;

  // Recency bonus (20% weight)
  if (ageInDays <= 1) score += 20;
  else if (ageInDays <= 3) score += 16;
  else if (ageInDays <= 7) score += 12;
  else if (ageInDays <= 14) score += 8;
  else if (ageInDays <= 30) score += 4;

  return { video, viralScore: Math.min(score, 100), viewsPerDay: Math.round(viewsPerDay), engagementRate, ageInDays: Math.round(ageInDays), isShort };
}

// ============================================================
// Channel Insight Builder
// ============================================================

export async function buildChannelInsight(channelId: string): Promise<ChannelInsight> {
  const [channels, searchResults] = await Promise.all([
    getChannelDetails([channelId]),
    getChannelVideos(channelId, 15),
  ]);

  if (channels.length === 0) throw new Error('Channel not found');
  const channel = channels[0];

  const videoIds = searchResults.map(r => r.videoId).filter(Boolean);
  const videos = await getVideoDetails(videoIds);

  const avgViews = videos.length > 0
    ? videos.reduce((s, v) => s + v.viewCount, 0) / videos.length
    : 0;

  // Upload frequency estimate
  let uploadFrequency = 'Desconhecida';
  if (videos.length >= 2) {
    const dates = videos.map(v => new Date(v.publishedAt).getTime()).sort((a, b) => b - a);
    const gaps = [];
    for (let i = 0; i < dates.length - 1; i++) gaps.push((dates[i] - dates[i + 1]) / 86400000);
    const avgGap = gaps.reduce((a, b) => a + b, 0) / gaps.length;
    if (avgGap <= 1.5) uploadFrequency = 'Diário';
    else if (avgGap <= 3) uploadFrequency = '3-4x/semana';
    else if (avgGap <= 5) uploadFrequency = '2x/semana';
    else if (avgGap <= 8) uploadFrequency = 'Semanal';
    else if (avgGap <= 16) uploadFrequency = 'Quinzenal';
    else uploadFrequency = 'Mensal ou menos';
  }

  const topVideos = [...videos].sort((a, b) => b.viewCount - a.viewCount).slice(0, 5);

  // Growth score: ratio of recent video views vs channel average
  const recentVideos = videos.slice(0, 5);
  const recentAvg = recentVideos.length > 0
    ? recentVideos.reduce((s, v) => s + v.viewCount, 0) / recentVideos.length
    : 0;
  const growthRatio = avgViews > 0 ? recentAvg / avgViews : 1;
  const recentGrowthScore = Math.min(Math.round(growthRatio * 50), 100);

  // Niche estimation from tags and titles
  const allTags = videos.flatMap(v => v.tags).map(t => t.toLowerCase());
  const tagFreq = new Map<string, number>();
  allTags.forEach(t => tagFreq.set(t, (tagFreq.get(t) || 0) + 1));
  const topTag = [...tagFreq.entries()].sort((a, b) => b[1] - a[1])[0];
  const estimatedNiche = topTag ? topTag[0] : 'Não identificado';

  return {
    channel,
    avgViewsPerVideo: Math.round(avgViews),
    uploadFrequency,
    topVideos,
    recentGrowthScore,
    estimatedNiche,
  };
}

// ============================================================
// Helpers
// ============================================================

function parseDurationSeconds(iso: string): number {
  const match = iso.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  if (!match) return 0;
  return (parseInt(match[1] || '0') * 3600) + (parseInt(match[2] || '0') * 60) + parseInt(match[3] || '0');
}

export function formatDuration(iso: string): string {
  const secs = parseDurationSeconds(iso);
  const h = Math.floor(secs / 3600);
  const m = Math.floor((secs % 3600) / 60);
  const s = secs % 60;
  if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  return `${m}:${String(s).padStart(2, '0')}`;
}

export function formatNumber(n: number): string {
  if (n >= 1_000_000_000) return `${(n / 1_000_000_000).toFixed(1)}B`;
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}K`;
  return n.toString();
}
