import type { Voice } from '@/lib/supabase/types';
import type { ITTSProvider, TTSParams, TTSResult, QuotaInfo, WordTiming } from './audio-service';

// ============================================================
// Google Cloud Text-to-Speech Provider
// ============================================================
// Free tier: 4M Standard chars / 1M WaveNet chars / mês
// Docs: https://cloud.google.com/text-to-speech/docs
// ============================================================

const API_BASE = 'https://texttospeech.googleapis.com/v1';

interface GoogleVoice {
  languageCodes: string[];
  name: string;
  ssmlGender: string;
  naturalSampleRateHertz: number;
}

interface GoogleSynthResponse {
  audioContent: string; // base64
  timepoints?: { markName: string; timeSeconds: number }[];
}

export class GoogleTTSProvider implements ITTSProvider {
  readonly name = 'google' as const;
  private apiKey: string;

  constructor(apiKey?: string) {
    this.apiKey = apiKey || process.env.GOOGLE_TTS_API_KEY || '';
  }

  async listVoices(language?: string): Promise<Voice[]> {
    const url = new URL(`${API_BASE}/voices`);
    url.searchParams.set('key', this.apiKey);
    if (language) url.searchParams.set('languageCode', language);

    const res = await fetch(url.toString());
    if (!res.ok) throw new Error(`Google TTS voices error: ${res.status}`);

    const data = await res.json();
    return (data.voices || []).map((v: GoogleVoice) => ({
      id: '', // UUID gerado no insert
      provider: 'google' as const,
      provider_voice_id: v.name,
      name: formatGoogleVoiceName(v.name),
      gender: mapGender(v.ssmlGender),
      language_tags: v.languageCodes,
      preview_url: null,
      is_clone: false,
      is_active: true,
      created_at: new Date().toISOString(),
    }));
  }

  async generateAudio(params: TTSParams): Promise<TTSResult> {
    const { text, voiceId, speed = 1.0, volume = 1.0 } = params;

    // Usar SSML com marks para obter timestamps por palavra
    const words = text.split(/\s+/).filter(Boolean);
    const ssml = buildSSMLWithMarks(words);

    const body = {
      input: { ssml },
      voice: {
        name: voiceId,
        languageCode: voiceId.substring(0, 5), // ex: "pt-BR" de "pt-BR-Wavenet-A"
      },
      audioConfig: {
        audioEncoding: 'MP3',
        speakingRate: speed,
        volumeGainDb: volumeToDb(volume),
        effectsProfileId: ['headphone-class-device'],
      },
      enableTimePointing: ['SSML_MARK'],
    };

    const url = `${API_BASE}/text:synthesize?key=${this.apiKey}`;
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      const err = await res.text();
      throw new Error(`Google TTS synthesis error: ${res.status} - ${err}`);
    }

    const data: GoogleSynthResponse = await res.json();
    const audioBuffer = base64ToArrayBuffer(data.audioContent);

    // Extrair word timings dos timepoints
    const wordTimings = extractWordTimings(words, data.timepoints || []);

    return {
      audioBuffer,
      contentType: 'audio/mpeg',
      wordTimings,
    };
  }

  async getQuota(): Promise<QuotaInfo> {
    // Google não tem API de quota — retornar estimativa
    return {
      provider: 'google',
      used: 0,
      limit: 1_000_000, // WaveNet free tier
      unit: 'characters',
      resetDate: getNextMonthReset(),
    };
  }
}

// ============================================================
// Helpers
// ============================================================

function buildSSMLWithMarks(words: string[]): string {
  const marked = words.map((w, i) => `<mark name="w${i}"/>${escapeXml(w)}`).join(' ');
  return `<speak>${marked}</speak>`;
}

function extractWordTimings(words: string[], timepoints: { markName: string; timeSeconds: number }[]): WordTiming[] {
  const timings: WordTiming[] = [];
  const tpMap = new Map(timepoints.map(tp => [tp.markName, tp.timeSeconds * 1000]));

  for (let i = 0; i < words.length; i++) {
    const startMs = tpMap.get(`w${i}`) ?? 0;
    const endMs = tpMap.get(`w${i + 1}`) ?? (startMs + 300); // fallback 300ms
    timings.push({ word: words[i], startMs: Math.round(startMs), endMs: Math.round(endMs) });
  }

  return timings;
}

function formatGoogleVoiceName(name: string): string {
  // "pt-BR-Wavenet-A" → "Google Wavenet A (pt-BR)"
  const parts = name.split('-');
  if (parts.length >= 4) {
    const lang = `${parts[0]}-${parts[1]}`;
    const type = parts[2];
    const letter = parts[3];
    return `Google ${type} ${letter} (${lang})`;
  }
  return name;
}

function mapGender(ssmlGender: string): 'male' | 'female' | 'neutral' {
  if (ssmlGender === 'MALE') return 'male';
  if (ssmlGender === 'FEMALE') return 'female';
  return 'neutral';
}

function volumeToDb(volume: number): number {
  // 0.0-1.0 → -6.0 to 6.0 dB
  return (volume - 0.5) * 12;
}

function escapeXml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function base64ToArrayBuffer(base64: string): ArrayBuffer {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

function getNextMonthReset(): string {
  const d = new Date();
  d.setMonth(d.getMonth() + 1, 1);
  d.setHours(0, 0, 0, 0);
  return d.toISOString();
}
