import { createClient } from './client';

const supabase = () => createClient();

// ============================================================
// Niche Monitoring
// ============================================================

export interface MonitoredNiche {
  id: string;
  user_id: string;
  name: string;
  keywords: string[];
  region: string;
  last_scanned_at: string | null;
  scan_count: number;
  avg_viral_score: number | null;
  notes: string | null;
  created_at: string;
}

export async function getMonitoredNiches() {
  const { data, error } = await supabase().from('monitored_niches').select('*').order('created_at', { ascending: false });
  if (error) throw error;
  return data as MonitoredNiche[];
}

export type NicheInsert = { name: string; keywords: string[]; region?: string; notes?: string };

export async function createMonitoredNiche(niche: NicheInsert) {
  const { data: { user } } = await supabase().auth.getUser();
  if (!user) throw new Error('Not authenticated');
  const { data, error } = await supabase().from('monitored_niches').insert({ ...niche, user_id: user.id, region: niche.region || 'BR' }).select().single();
  if (error) throw error;
  return data as MonitoredNiche;
}

export async function updateMonitoredNiche(id: string, updates: Partial<NicheInsert & { last_scanned_at?: string; avg_viral_score?: number; scan_count?: number }>) {
  const { data, error } = await supabase().from('monitored_niches').update(updates).eq('id', id).select().single();
  if (error) throw error;
  return data as MonitoredNiche;
}

export async function deleteMonitoredNiche(id: string) {
  const { error } = await supabase().from('monitored_niches').delete().eq('id', id);
  if (error) throw error;
}

// ============================================================
// Removed/Dead Channels Tracker
// ============================================================

export interface RemovedChannel {
  id: string;
  user_id: string;
  channel_name: string;
  channel_url: string | null;
  niche: string | null;
  reason: string;
  subscribers_at_removal: number | null;
  detected_at: string;
  notes: string | null;
  created_at: string;
}

export async function getRemovedChannels() {
  const { data, error } = await supabase().from('removed_channels').select('*').order('detected_at', { ascending: false });
  if (error) throw error;
  return data as RemovedChannel[];
}

export type RemovedChannelInsert = {
  channel_name: string; channel_url?: string; niche?: string;
  reason: string; subscribers_at_removal?: number; notes?: string;
};

export async function createRemovedChannel(ch: RemovedChannelInsert) {
  const { data: { user } } = await supabase().auth.getUser();
  if (!user) throw new Error('Not authenticated');
  const { data, error } = await supabase().from('removed_channels').insert({
    ...ch, user_id: user.id, detected_at: new Date().toISOString(),
  }).select().single();
  if (error) throw error;
  return data as RemovedChannel;
}

export async function deleteRemovedChannel(id: string) {
  const { error } = await supabase().from('removed_channels').delete().eq('id', id);
  if (error) throw error;
}
