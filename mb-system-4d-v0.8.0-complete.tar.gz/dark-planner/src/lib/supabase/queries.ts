import { createClient } from './client';
import type { ProjectChannel, ChannelShortcut, VideoItem, Script, VideoStatus } from './types';

const supabase = () => createClient();

// ============================================================
// CHANNELS
// ============================================================

export async function getChannels() {
  const { data, error } = await supabase()
    .from('project_channels')
    .select('*')
    .order('created_at', { ascending: true });
  if (error) throw error;
  return data as ProjectChannel[];
}

export async function getChannel(id: string) {
  const { data, error } = await supabase()
    .from('project_channels')
    .select('*')
    .eq('id', id)
    .single();
  if (error) throw error;
  return data as ProjectChannel;
}

export type ChannelInsert = Omit<ProjectChannel, 'id' | 'user_id' | 'created_at' | 'updated_at' | 'already_posted_count'>;

export async function createChannel(channel: ChannelInsert) {
  const { data: { user } } = await supabase().auth.getUser();
  if (!user) throw new Error('Not authenticated');

  const { data, error } = await supabase()
    .from('project_channels')
    .insert({ ...channel, user_id: user.id })
    .select()
    .single();
  if (error) throw error;
  return data as ProjectChannel;
}

export async function updateChannel(id: string, updates: Partial<ChannelInsert>) {
  const { data, error } = await supabase()
    .from('project_channels')
    .update(updates)
    .eq('id', id)
    .select()
    .single();
  if (error) throw error;
  return data as ProjectChannel;
}

export async function deleteChannel(id: string) {
  const { error } = await supabase()
    .from('project_channels')
    .delete()
    .eq('id', id);
  if (error) throw error;
}

// ============================================================
// CHANNEL SHORTCUTS
// ============================================================

export async function getChannelShortcuts(channelId: string) {
  const { data, error } = await supabase()
    .from('channel_shortcuts')
    .select('*')
    .eq('channel_id', channelId)
    .order('sort_order');
  if (error) throw error;
  return data as ChannelShortcut[];
}

export type ShortcutInsert = { channel_id: string; label: string; url: string; sort_order?: number };

export async function upsertShortcuts(channelId: string, shortcuts: Omit<ShortcutInsert, 'channel_id'>[]) {
  // Delete existing
  await supabase().from('channel_shortcuts').delete().eq('channel_id', channelId);
  
  if (shortcuts.length === 0) return [];

  const rows = shortcuts.map((s, i) => ({
    channel_id: channelId,
    label: s.label,
    url: s.url,
    sort_order: s.sort_order ?? i,
  }));

  const { data, error } = await supabase()
    .from('channel_shortcuts')
    .insert(rows)
    .select();
  if (error) throw error;
  return data as ChannelShortcut[];
}

// ============================================================
// VIDEOS
// ============================================================

export async function getVideosByChannel(channelId: string) {
  const { data, error } = await supabase()
    .from('video_items')
    .select('*, scripts(id, title, char_count)')
    .eq('channel_id', channelId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data as (VideoItem & { scripts: Pick<Script, 'id' | 'title' | 'char_count'> | null })[];
}

export async function getVideoCountsByChannel(channelId: string): Promise<Record<VideoStatus, number>> {
  const { data, error } = await supabase()
    .from('video_items')
    .select('status')
    .eq('channel_id', channelId);
  if (error) throw error;

  const counts: Record<VideoStatus, number> = {
    planning: 0, production: 0, ready: 0, scheduled: 0, published: 0, overdue: 0,
  };
  (data || []).forEach(v => { counts[v.status as VideoStatus]++; });
  return counts;
}

export type VideoInsert = {
  channel_id: string;
  title: string;
  description?: string;
  script_id?: string;
  status?: VideoStatus;
  scheduled_at?: string;
  notes?: string;
};

export async function createVideo(video: VideoInsert) {
  const { data, error } = await supabase()
    .from('video_items')
    .insert(video)
    .select()
    .single();
  if (error) throw error;
  return data as VideoItem;
}

export async function updateVideo(id: string, updates: Partial<VideoInsert>) {
  const { data, error } = await supabase()
    .from('video_items')
    .update(updates)
    .eq('id', id)
    .select()
    .single();
  if (error) throw error;
  return data as VideoItem;
}

export async function updateVideoStatus(id: string, status: VideoStatus) {
  return updateVideo(id, { status });
}

export async function deleteVideo(id: string) {
  const { error } = await supabase()
    .from('video_items')
    .delete()
    .eq('id', id);
  if (error) throw error;
}

// ============================================================
// SCRIPTS
// ============================================================

export async function getScriptsByChannel(channelId: string) {
  const { data, error } = await supabase()
    .from('scripts')
    .select('*')
    .eq('channel_id', channelId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return data as Script[];
}

export async function getScript(id: string) {
  const { data, error } = await supabase()
    .from('scripts')
    .select('*')
    .eq('id', id)
    .single();
  if (error) throw error;
  return data as Script;
}

export type ScriptInsert = {
  channel_id?: string;
  title: string;
  body_text?: string;
  source?: 'manual' | 'upload' | 'import';
};

export async function createScript(script: ScriptInsert) {
  const { data: { user } } = await supabase().auth.getUser();
  if (!user) throw new Error('Not authenticated');

  const wordCount = (script.body_text || '').split(/\s+/).filter(Boolean).length;

  const { data, error } = await supabase()
    .from('scripts')
    .insert({ ...script, user_id: user.id, word_count: wordCount })
    .select()
    .single();
  if (error) throw error;
  return data as Script;
}

export async function updateScript(id: string, updates: Partial<ScriptInsert> & { body_text?: string }) {
  const patch: Record<string, unknown> = { ...updates };
  if (updates.body_text !== undefined) {
    patch.word_count = updates.body_text.split(/\s+/).filter(Boolean).length;
  }

  const { data, error } = await supabase()
    .from('scripts')
    .update(patch)
    .eq('id', id)
    .select()
    .single();
  if (error) throw error;
  return data as Script;
}

export async function deleteScript(id: string) {
  const { error } = await supabase()
    .from('scripts')
    .delete()
    .eq('id', id);
  if (error) throw error;
}

// ============================================================
// STATS (Dashboard helpers)
// ============================================================

export async function getChannelStats() {
  const channels = await getChannels();
  
  const statsPromises = channels.map(async (ch) => {
    const counts = await getVideoCountsByChannel(ch.id);
    return { channel: ch, counts };
  });

  return Promise.all(statsPromises);
}
