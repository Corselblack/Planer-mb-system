// Types derivados do schema do banco (00001_initial_schema.sql)
// Atualizar com: npx supabase gen types typescript --local > src/lib/supabase/types.ts

export type VideoStatus = 'planning' | 'production' | 'ready' | 'scheduled' | 'published' | 'overdue';
export type ScriptSource = 'manual' | 'upload' | 'import';
export type AudioJobStatus = 'queued' | 'processing' | 'succeeded' | 'failed';
export type InsightJobStatus = 'queued' | 'processing' | 'succeeded' | 'failed';
export type AssetType = 'audio_mp3' | 'srt' | 'view_srt' | 'insight_txt' | 'thumbnail' | 'other';
export type VoiceGender = 'male' | 'female' | 'neutral';
export type TTSProvider = 'google' | 'elevenlabs';
export type CaptionFontSize = 'small' | 'medium' | 'large';
export type ViralChannelCategory = 'exploding' | 'high' | 'growing' | 'new' | 'other';

export interface Profile {
  id: string;
  display_name: string | null;
  avatar_url: string | null;
  youtube_api_key_encrypted: string | null;
  timezone: string;
  theme: string;
  created_at: string;
  updated_at: string;
}

export interface ProjectChannel {
  id: string;
  user_id: string;
  name: string;
  language: string;
  posting_time: string | null;
  frequency: string | null;
  already_posted_count: number;
  default_description: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface ChannelShortcut {
  id: string;
  channel_id: string;
  label: string;
  url: string;
  sort_order: number;
  created_at: string;
}

export interface Script {
  id: string;
  user_id: string;
  channel_id: string | null;
  title: string;
  body_text: string;
  source: ScriptSource;
  char_count: number;
  word_count: number;
  created_at: string;
  updated_at: string;
}

export interface VideoItem {
  id: string;
  channel_id: string;
  title: string;
  description: string | null;
  thumbnail_url: string | null;
  script_id: string | null;
  status: VideoStatus;
  scheduled_at: string | null;
  published_at: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface Voice {
  id: string;
  provider: TTSProvider;
  provider_voice_id: string;
  name: string;
  gender: VoiceGender;
  language_tags: string[];
  preview_url: string | null;
  is_clone: boolean;
  is_active: boolean;
  created_at: string;
}

export interface AudioJob {
  id: string;
  user_id: string;
  channel_id: string | null;
  script_id: string | null;
  voice_id: string;
  input_text: string;
  name: string | null;
  provider: TTSProvider;
  params_speed: number;
  params_volume: number;
  params_words_per_caption: number;
  params_caption_font_size: CaptionFontSize;
  status: AudioJobStatus;
  provider_request_id: string | null;
  output_audio_asset_id: string | null;
  output_srt_asset_id: string | null;
  output_view_srt_asset_id: string | null;
  error_message: string | null;
  created_at: string;
  finished_at: string | null;
}

export interface Prompt {
  id: string;
  user_id: string;
  title: string;
  body: string;
  tags: string[];
  created_at: string;
  updated_at: string;
}

export interface Reference {
  id: string;
  user_id: string;
  channel_id: string | null;
  title: string;
  url: string | null;
  niche: string | null;
  notes: string | null;
  created_at: string;
}

export interface Notification {
  id: string;
  user_id: string;
  type: string;
  title: string;
  payload: Record<string, unknown>;
  action_url: string | null;
  read_at: string | null;
  created_at: string;
}

// Dashboard aggregation type
export interface DashboardStats {
  total_channels: number;
  videos_planning: number;
  videos_production: number;
  videos_ready: number;
  videos_scheduled: number;
  videos_published: number;
  videos_overdue: number;
  unread_notifications: number;
}

// Video status config (for UI)
export const VIDEO_STATUS_CONFIG: Record<VideoStatus, { label: string; color: string; icon: string }> = {
  planning: { label: 'Planejamento', color: 'blue', icon: 'FileText' },
  production: { label: 'Em Produção', color: 'orange', icon: 'Cog' },
  ready: { label: 'Pronto', color: 'purple', icon: 'CheckCircle' },
  scheduled: { label: 'Agendado', color: 'yellow', icon: 'Calendar' },
  published: { label: 'Publicado', color: 'green', icon: 'Globe' },
  overdue: { label: 'Atrasado', color: 'red', icon: 'AlertTriangle' },
};
