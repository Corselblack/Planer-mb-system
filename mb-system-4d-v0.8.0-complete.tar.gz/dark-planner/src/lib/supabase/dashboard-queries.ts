import { createClient } from './client';
import type { VideoStatus, ProjectChannel, VideoItem, Notification } from './types';

const supabase = () => createClient();

// ============================================================
// Dashboard Stats (agregação completa)
// ============================================================

export interface DashboardData {
  stats: {
    total_channels: number;
    videos_planning: number;
    videos_production: number;
    videos_ready: number;
    videos_scheduled: number;
    videos_published: number;
    videos_overdue: number;
    total_scripts: number;
    total_audios: number;
    unread_notifications: number;
  };
  channels: ChannelSummary[];
  upcoming: UpcomingVideo[];
  notifications: Notification[];
  overdue: OverdueVideo[];
}

export interface ChannelSummary {
  id: string;
  name: string;
  language: string;
  frequency: string | null;
  counts: Record<VideoStatus, number>;
  total_videos: number;
}

export interface UpcomingVideo {
  id: string;
  title: string;
  channel_name: string;
  channel_id: string;
  scheduled_at: string;
  status: VideoStatus;
}

export interface OverdueVideo {
  id: string;
  title: string;
  channel_name: string;
  channel_id: string;
  scheduled_at: string;
}

export async function getDashboardData(): Promise<DashboardData> {
  const s = supabase();

  // Queries paralelas
  const [channelsRes, videosRes, scriptsRes, audiosRes, notifRes] = await Promise.all([
    s.from('project_channels').select('*').order('created_at'),
    s.from('video_items').select('id, title, channel_id, status, scheduled_at'),
    s.from('scripts').select('id', { count: 'exact', head: true }),
    s.from('audio_jobs').select('id', { count: 'exact', head: true }).eq('status', 'succeeded'),
    s.from('notifications').select('*').is('read_at', null).order('created_at', { ascending: false }).limit(10),
  ]);

  const channels = (channelsRes.data || []) as ProjectChannel[];
  const videos = (videosRes.data || []) as (Pick<VideoItem, 'id' | 'title' | 'channel_id' | 'status' | 'scheduled_at'>)[];
  const notifications = (notifRes.data || []) as Notification[];

  // Contagem de vídeos por status
  const statusCounts: Record<VideoStatus, number> = {
    planning: 0, production: 0, ready: 0, scheduled: 0, published: 0, overdue: 0,
  };
  videos.forEach(v => { statusCounts[v.status]++; });

  // Detectar vídeos atrasados (scheduled_at no passado mas não published)
  const now = new Date();
  const overdueVideos: OverdueVideo[] = [];
  videos.forEach(v => {
    if (v.scheduled_at && v.status === 'scheduled' && new Date(v.scheduled_at) < now) {
      const ch = channels.find(c => c.id === v.channel_id);
      overdueVideos.push({
        id: v.id,
        title: v.title,
        channel_name: ch?.name || 'Canal desconhecido',
        channel_id: v.channel_id,
        scheduled_at: v.scheduled_at,
      });
    }
  });

  // Canais com contagens
  const channelMap = new Map<string, string>();
  channels.forEach(c => channelMap.set(c.id, c.name));

  const channelSummaries: ChannelSummary[] = channels.map(ch => {
    const counts: Record<VideoStatus, number> = {
      planning: 0, production: 0, ready: 0, scheduled: 0, published: 0, overdue: 0,
    };
    videos.filter(v => v.channel_id === ch.id).forEach(v => { counts[v.status]++; });
    const total = Object.values(counts).reduce((a, b) => a + b, 0);

    return {
      id: ch.id,
      name: ch.name,
      language: ch.language,
      frequency: ch.frequency,
      counts,
      total_videos: total,
    };
  });

  // Próximas publicações (scheduled no futuro, ordenados por data)
  const upcoming: UpcomingVideo[] = videos
    .filter(v => v.scheduled_at && v.status === 'scheduled' && new Date(v.scheduled_at) >= now)
    .sort((a, b) => new Date(a.scheduled_at!).getTime() - new Date(b.scheduled_at!).getTime())
    .slice(0, 10)
    .map(v => ({
      id: v.id,
      title: v.title,
      channel_name: channelMap.get(v.channel_id) || 'Canal desconhecido',
      channel_id: v.channel_id,
      scheduled_at: v.scheduled_at!,
      status: v.status,
    }));

  return {
    stats: {
      total_channels: channels.length,
      videos_planning: statusCounts.planning,
      videos_production: statusCounts.production,
      videos_ready: statusCounts.ready,
      videos_scheduled: statusCounts.scheduled,
      videos_published: statusCounts.published,
      videos_overdue: statusCounts.overdue + overdueVideos.length,
      total_scripts: scriptsRes.count || 0,
      total_audios: audiosRes.count || 0,
      unread_notifications: notifications.length,
    },
    channels: channelSummaries,
    upcoming,
    notifications,
    overdue: overdueVideos,
  };
}

// ============================================================
// Marcar notificação como lida
// ============================================================

export async function markNotificationRead(id: string) {
  const { error } = await supabase()
    .from('notifications')
    .update({ read_at: new Date().toISOString() })
    .eq('id', id);
  if (error) throw error;
}

export async function markAllNotificationsRead() {
  const { data: { user } } = await supabase().auth.getUser();
  if (!user) return;
  await supabase()
    .from('notifications')
    .update({ read_at: new Date().toISOString() })
    .eq('user_id', user.id)
    .is('read_at', null);
}
