import { createClient } from './client';

const supabase = () => createClient();

// ============================================================
// PROMPTS
// ============================================================

export interface Prompt {
  id: string;
  user_id: string;
  title: string;
  body: string;
  tags: string[];
  created_at: string;
  updated_at: string;
}

export async function getPrompts() {
  const { data, error } = await supabase().from('prompts').select('*').order('updated_at', { ascending: false });
  if (error) throw error;
  return (data || []) as Prompt[];
}

export async function createPrompt(p: { title: string; body: string; tags?: string[] }) {
  const { data: { user } } = await supabase().auth.getUser();
  if (!user) throw new Error('Unauthorized');
  const { data, error } = await supabase().from('prompts').insert({ ...p, tags: p.tags || [], user_id: user.id }).select().single();
  if (error) throw error;
  return data as Prompt;
}

export async function updatePrompt(id: string, updates: Partial<Pick<Prompt, 'title' | 'body' | 'tags'>>) {
  const { data, error } = await supabase().from('prompts').update({ ...updates, updated_at: new Date().toISOString() }).eq('id', id).select().single();
  if (error) throw error;
  return data as Prompt;
}

export async function deletePrompt(id: string) {
  const { error } = await supabase().from('prompts').delete().eq('id', id);
  if (error) throw error;
}

// ============================================================
// REFERÊNCIAS
// ============================================================

export interface Reference {
  id: string;
  user_id: string;
  channel_id: string | null;
  title: string;
  url: string;
  niche: string;
  notes: string;
  created_at: string;
}

export async function getReferences(channelId?: string) {
  let q = supabase().from('references').select('*').order('created_at', { ascending: false });
  if (channelId) q = q.eq('channel_id', channelId);
  const { data, error } = await q;
  if (error) throw error;
  return (data || []) as Reference[];
}

export async function createReference(r: { title: string; url: string; niche?: string; notes?: string; channel_id?: string }) {
  const { data: { user } } = await supabase().auth.getUser();
  if (!user) throw new Error('Unauthorized');
  const { data, error } = await supabase().from('references').insert({ ...r, niche: r.niche || '', notes: r.notes || '', user_id: user.id }).select().single();
  if (error) throw error;
  return data as Reference;
}

export async function updateReference(id: string, updates: Partial<Pick<Reference, 'title' | 'url' | 'niche' | 'notes' | 'channel_id'>>) {
  const { data, error } = await supabase().from('references').update(updates).eq('id', id).select().single();
  if (error) throw error;
  return data as Reference;
}

export async function deleteReference(id: string) {
  const { error } = await supabase().from('references').delete().eq('id', id);
  if (error) throw error;
}

// ============================================================
// QUADRO DE IDEIAS (usa tabela ideas)
// ============================================================

export interface Idea {
  id: string;
  user_id: string;
  channel_id: string | null;
  title: string;
  body: string;
  color: string;
  pinned: boolean;
  created_at: string;
}

export async function getIdeas(channelId?: string) {
  let q = supabase().from('ideas').select('*').order('pinned', { ascending: false }).order('created_at', { ascending: false });
  if (channelId) q = q.eq('channel_id', channelId);
  const { data, error } = await q;
  if (error) throw error;
  return (data || []) as Idea[];
}

export async function createIdea(i: { title: string; body?: string; color?: string; channel_id?: string }) {
  const { data: { user } } = await supabase().auth.getUser();
  if (!user) throw new Error('Unauthorized');
  const { data, error } = await supabase().from('ideas').insert({ ...i, body: i.body || '', color: i.color || 'cyan', user_id: user.id }).select().single();
  if (error) throw error;
  return data as Idea;
}

export async function updateIdea(id: string, updates: Partial<Pick<Idea, 'title' | 'body' | 'color' | 'pinned' | 'channel_id'>>) {
  const { data, error } = await supabase().from('ideas').update(updates).eq('id', id).select().single();
  if (error) throw error;
  return data as Idea;
}

export async function deleteIdea(id: string) {
  const { error } = await supabase().from('ideas').delete().eq('id', id);
  if (error) throw error;
}
