import { createClient } from './client';
import type { Prompt, Reference } from './types';

const supabase = () => createClient();

// ============================================================
// PROMPTS
// ============================================================

export async function getPrompts(tag?: string) {
  let query = supabase().from('prompts').select('*').order('updated_at', { ascending: false });
  if (tag) query = query.contains('tags', [tag]);
  const { data, error } = await query;
  if (error) throw error;
  return data as Prompt[];
}

export async function getPrompt(id: string) {
  const { data, error } = await supabase().from('prompts').select('*').eq('id', id).single();
  if (error) throw error;
  return data as Prompt;
}

export type PromptInsert = { title: string; body: string; tags?: string[] };

export async function createPrompt(prompt: PromptInsert) {
  const { data: { user } } = await supabase().auth.getUser();
  if (!user) throw new Error('Not authenticated');
  const { data, error } = await supabase().from('prompts').insert({ ...prompt, user_id: user.id }).select().single();
  if (error) throw error;
  return data as Prompt;
}

export async function updatePrompt(id: string, updates: Partial<PromptInsert>) {
  const { data, error } = await supabase().from('prompts').update(updates).eq('id', id).select().single();
  if (error) throw error;
  return data as Prompt;
}

export async function deletePrompt(id: string) {
  const { error } = await supabase().from('prompts').delete().eq('id', id);
  if (error) throw error;
}

export function getAllPromptTags(prompts: Prompt[]): string[] {
  const tags = new Set<string>();
  prompts.forEach(p => p.tags.forEach(t => tags.add(t)));
  return Array.from(tags).sort();
}

// ============================================================
// REFERENCES
// ============================================================

export async function getReferences(niche?: string) {
  let query = supabase().from('references').select('*').order('created_at', { ascending: false });
  if (niche) query = query.eq('niche', niche);
  const { data, error } = await query;
  if (error) throw error;
  return data as Reference[];
}

export type ReferenceInsert = { title: string; url?: string; niche?: string; notes?: string; channel_id?: string };

export async function createReference(ref: ReferenceInsert) {
  const { data: { user } } = await supabase().auth.getUser();
  if (!user) throw new Error('Not authenticated');
  const { data, error } = await supabase().from('references').insert({ ...ref, user_id: user.id }).select().single();
  if (error) throw error;
  return data as Reference;
}

export async function updateReference(id: string, updates: Partial<ReferenceInsert>) {
  const { data, error } = await supabase().from('references').update(updates).eq('id', id).select().single();
  if (error) throw error;
  return data as Reference;
}

export async function deleteReference(id: string) {
  const { error } = await supabase().from('references').delete().eq('id', id);
  if (error) throw error;
}

export function getAllNiches(refs: Reference[]): string[] {
  const niches = new Set<string>();
  refs.forEach(r => { if (r.niche) niches.add(r.niche); });
  return Array.from(niches).sort();
}

// ============================================================
// IDEA BOARD
// ============================================================

export interface IdeaItem {
  id: string;
  user_id: string;
  channel_id: string | null;
  content: string;
  color: string;
  sort_order: number;
  created_at: string;
  updated_at: string;
}

export async function getIdeas() {
  const { data, error } = await supabase().from('idea_board').select('*').order('sort_order');
  if (error) throw error;
  return data as IdeaItem[];
}

export type IdeaInsert = { content: string; color?: string; channel_id?: string };

export async function createIdea(idea: IdeaInsert) {
  const { data: { user } } = await supabase().auth.getUser();
  if (!user) throw new Error('Not authenticated');
  const { data, error } = await supabase().from('idea_board').insert({ ...idea, user_id: user.id }).select().single();
  if (error) throw error;
  return data as IdeaItem;
}

export async function updateIdea(id: string, updates: Partial<IdeaInsert & { sort_order?: number }>) {
  const { data, error } = await supabase().from('idea_board').update(updates).eq('id', id).select().single();
  if (error) throw error;
  return data as IdeaItem;
}

export async function deleteIdea(id: string) {
  const { error } = await supabase().from('idea_board').delete().eq('id', id);
  if (error) throw error;
}
