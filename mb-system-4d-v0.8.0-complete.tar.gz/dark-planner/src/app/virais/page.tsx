'use client';

import { useState, useCallback } from 'react';
import { Header } from '@/components/layout';
import { EmptyState } from '@/components/ui';
import {
  Flame, Search, TrendingUp, Eye, ThumbsUp, MessageCircle, Clock,
  ExternalLink, Loader2, Globe, BarChart3, Zap, Play, Users,
} from 'lucide-react';
import { cn } from '@/lib/utils';

type Tab = 'trending' | 'search' | 'channel';

interface ViralVideo {
  video: { id: string; title: string; channelTitle: string; channelId: string; publishedAt: string; thumbnailUrl: string; viewCount: number; likeCount: number; commentCount: number; duration: string; tags: string[] };
  viralScore: number;
  viewsPerDay: number;
  engagementRate: number;
  ageInDays: number;
  isShort: boolean;
}

interface ChannelInsightData {
  channel: { id: string; title: string; thumbnailUrl: string; subscriberCount: number; videoCount: number; viewCount: number; country: string };
  avgViewsPerVideo: number;
  uploadFrequency: string;
  topVideos: any[];
  recentGrowthScore: number;
  estimatedNiche: string;
}

const REGIONS = [
  { code: 'BR', label: '🇧🇷 Brasil' }, { code: 'US', label: '🇺🇸 EUA' },
  { code: 'ES', label: '🇪🇸 Espanha' }, { code: 'MX', label: '🇲🇽 México' },
  { code: 'PT', label: '🇵🇹 Portugal' }, { code: 'GB', label: '🇬🇧 Reino Unido' },
  { code: 'FR', label: '🇫🇷 França' }, { code: 'DE', label: '🇩🇪 Alemanha' },
];

export default function ViraisPage() {
  const [tab, setTab] = useState<Tab>('trending');
  const [videos, setVideos] = useState<ViralVideo[]>([]);
  const [channelInsight, setChannelInsight] = useState<ChannelInsightData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Trending
  const [region, setRegion] = useState('BR');
  // Search
  const [query, setQuery] = useState('');
  const [searchDays, setSearchDays] = useState(30);
  const [searchOrder, setSearchOrder] = useState('viewCount');
  // Channel
  const [channelId, setChannelId] = useState('');

  const fetchTrending = useCallback(async () => {
    setLoading(true); setError(''); setVideos([]);
    try {
      const res = await fetch(`/api/youtube?action=trending&region=${region}`);
      if (!res.ok) throw new Error((await res.json()).error);
      const data = await res.json();
      setVideos(data.videos);
    } catch (e: any) { setError(e.message); } finally { setLoading(false); }
  }, [region]);

  const fetchSearch = useCallback(async () => {
    if (!query.trim()) return;
    setLoading(true); setError(''); setVideos([]);
    try {
      const res = await fetch(`/api/youtube?action=search&q=${encodeURIComponent(query)}&days=${searchDays}&order=${searchOrder}&region=${region}`);
      if (!res.ok) throw new Error((await res.json()).error);
      const data = await res.json();
      setVideos(data.videos);
    } catch (e: any) { setError(e.message); } finally { setLoading(false); }
  }, [query, searchDays, searchOrder, region]);

  const fetchChannel = useCallback(async () => {
    if (!channelId.trim()) return;
    setLoading(true); setError(''); setChannelInsight(null);
    try {
      const res = await fetch(`/api/youtube?action=channel&channelId=${encodeURIComponent(channelId)}`);
      if (!res.ok) throw new Error((await res.json()).error);
      setChannelInsight(await res.json());
    } catch (e: any) { setError(e.message); } finally { setLoading(false); }
  }, [channelId]);

  const fmtN = (n: number) => {
    if (n >= 1e9) return `${(n / 1e9).toFixed(1)}B`;
    if (n >= 1e6) return `${(n / 1e6).toFixed(1)}M`;
    if (n >= 1e3) return `${(n / 1e3).toFixed(1)}K`;
    return n.toString();
  };

  const scoreColor = (s: number) => s >= 70 ? 'text-dp-accent-green' : s >= 40 ? 'text-dp-accent-yellow' : 'text-dp-accent-red';
  const scoreBg = (s: number) => s >= 70 ? 'bg-dp-accent-green/10' : s >= 40 ? 'bg-dp-accent-yellow/10' : 'bg-dp-accent-red/10';

  return (
    <>
      <Header title="Scanner de Virais" subtitle="Descubra vídeos em alta e analise canais concorrentes" />
      <div className="p-6 animate-fade-in">
        {/* Tabs */}
        <div className="flex items-center gap-1 border-b border-dp-border-primary mb-6">
          {([
            ['trending', 'Trending', Flame],
            ['search', 'Buscar Virais', Search],
            ['channel', 'Análise de Canal', BarChart3],
          ] as const).map(([k, l, I]) => (
            <button key={k} onClick={() => setTab(k)}
              className={cn('flex items-center gap-1.5 px-4 py-2.5 text-xs font-medium border-b-2 -mb-px transition-colors',
                tab === k ? 'text-dp-accent-cyan border-dp-accent-cyan' : 'text-dp-text-tertiary border-transparent hover:text-dp-text-secondary')}>
              <I size={14} /> {l}
            </button>
          ))}
        </div>

        {/* Trending Controls */}
        {tab === 'trending' && (
          <div className="flex items-center gap-3 mb-6">
            <select value={region} onChange={e => setRegion(e.target.value)} className="dp-input text-xs py-2">
              {REGIONS.map(r => <option key={r.code} value={r.code}>{r.label}</option>)}
            </select>
            <button onClick={fetchTrending} disabled={loading} className="dp-btn-primary text-xs flex items-center gap-1.5">
              {loading ? <Loader2 size={13} className="animate-spin" /> : <Flame size={13} />} Carregar Trending
            </button>
          </div>
        )}

        {/* Search Controls */}
        {tab === 'search' && (
          <div className="flex items-center gap-3 mb-6 flex-wrap">
            <div className="relative flex-1 min-w-[200px]">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-dp-text-tertiary" />
              <input value={query} onChange={e => setQuery(e.target.value)} onKeyDown={e => e.key === 'Enter' && fetchSearch()}
                placeholder="Ex: dark faceless curiosidades" className="dp-input w-full pl-8 text-xs py-2" />
            </div>
            <select value={region} onChange={e => setRegion(e.target.value)} className="dp-input text-xs py-2">
              {REGIONS.map(r => <option key={r.code} value={r.code}>{r.label}</option>)}
            </select>
            <select value={searchDays} onChange={e => setSearchDays(+e.target.value)} className="dp-input text-xs py-2">
              <option value={7}>Últimos 7 dias</option>
              <option value={30}>Últimos 30 dias</option>
              <option value={90}>Últimos 90 dias</option>
              <option value={365}>Último ano</option>
            </select>
            <select value={searchOrder} onChange={e => setSearchOrder(e.target.value)} className="dp-input text-xs py-2">
              <option value="viewCount">Mais vistos</option>
              <option value="date">Mais recentes</option>
              <option value="rating">Melhor avaliados</option>
              <option value="relevance">Relevância</option>
            </select>
            <button onClick={fetchSearch} disabled={loading || !query.trim()} className="dp-btn-primary text-xs flex items-center gap-1.5 disabled:opacity-50">
              {loading ? <Loader2 size={13} className="animate-spin" /> : <Search size={13} />} Buscar
            </button>
          </div>
        )}

        {/* Channel Controls */}
        {tab === 'channel' && (
          <div className="flex items-center gap-3 mb-6">
            <input value={channelId} onChange={e => setChannelId(e.target.value)} onKeyDown={e => e.key === 'Enter' && fetchChannel()}
              placeholder="Channel ID (ex: UCxxxxxxx)" className="dp-input flex-1 text-xs py-2" />
            <button onClick={fetchChannel} disabled={loading || !channelId.trim()} className="dp-btn-primary text-xs flex items-center gap-1.5 disabled:opacity-50">
              {loading ? <Loader2 size={13} className="animate-spin" /> : <BarChart3 size={13} />} Analisar
            </button>
          </div>
        )}

        {error && <div className="dp-card border-dp-accent-red/30 text-sm text-dp-accent-red mb-4">{error}</div>}

        {/* Video Grid (trending + search) */}
        {(tab === 'trending' || tab === 'search') && (
          loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">{[1,2,3,4].map(i => <div key={i} className="dp-card animate-pulse h-40" />)}</div>
          ) : videos.length === 0 ? (
            <EmptyState icon={tab === 'trending' ? Flame : Search}
              title={tab === 'trending' ? 'Clique para carregar trending' : 'Busque vídeos virais'}
              description={tab === 'trending' ? 'Selecione a região e carregue os vídeos em alta.' : 'Pesquise por nicho, tema ou palavra-chave.'} />
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {videos.map(vm => (
                <div key={vm.video.id} className="dp-card-interactive group flex gap-4">
                  {/* Thumbnail */}
                  <div className="relative flex-shrink-0 w-40 h-24 rounded-lg overflow-hidden bg-dp-bg-tertiary">
                    {vm.video.thumbnailUrl && <img src={vm.video.thumbnailUrl} alt="" className="w-full h-full object-cover" />}
                    <div className="absolute bottom-1 right-1 bg-black/80 text-white text-[9px] px-1 py-0.5 rounded">{formatDuration(vm.video.duration)}</div>
                    {vm.isShort && <div className="absolute top-1 left-1 bg-dp-accent-red text-white text-[8px] px-1.5 py-0.5 rounded font-bold">SHORT</div>}
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <a href={`https://youtube.com/watch?v=${vm.video.id}`} target="_blank" rel="noopener noreferrer"
                        className="text-sm font-medium text-dp-text-primary line-clamp-2 hover:text-dp-accent-cyan">
                        {vm.video.title}
                      </a>
                      <div className={cn('flex-shrink-0 text-xs font-bold px-2 py-0.5 rounded-full', scoreBg(vm.viralScore), scoreColor(vm.viralScore))}>
                        {vm.viralScore}
                      </div>
                    </div>
                    <p className="text-[10px] text-dp-text-tertiary mt-0.5">{vm.video.channelTitle}</p>
                    <div className="flex items-center gap-3 mt-2 text-[10px] text-dp-text-tertiary">
                      <span className="flex items-center gap-0.5"><Eye size={10} /> {fmtN(vm.video.viewCount)}</span>
                      <span className="flex items-center gap-0.5"><ThumbsUp size={10} /> {fmtN(vm.video.likeCount)}</span>
                      <span className="flex items-center gap-0.5"><MessageCircle size={10} /> {fmtN(vm.video.commentCount)}</span>
                      <span className="flex items-center gap-0.5"><Zap size={10} className="text-dp-accent-yellow" /> {fmtN(vm.viewsPerDay)}/dia</span>
                    </div>
                    <div className="flex items-center gap-2 mt-1.5">
                      <span className="text-[9px] text-dp-text-tertiary">{vm.ageInDays}d atrás</span>
                      <span className="text-[9px] text-dp-text-tertiary">Eng: {(vm.engagementRate * 100).toFixed(1)}%</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )
        )}

        {/* Channel Insight */}
        {tab === 'channel' && channelInsight && (
          <div className="space-y-6">
            {/* Channel header */}
            <div className="dp-card flex items-center gap-4">
              {channelInsight.channel.thumbnailUrl && (
                <img src={channelInsight.channel.thumbnailUrl} alt="" className="w-16 h-16 rounded-full" />
              )}
              <div className="flex-1">
                <h2 className="text-lg font-bold text-dp-text-primary">{channelInsight.channel.title}</h2>
                <div className="flex items-center gap-4 mt-1 text-xs text-dp-text-tertiary">
                  <span className="flex items-center gap-1"><Users size={12} /> {fmtN(channelInsight.channel.subscriberCount)} subs</span>
                  <span className="flex items-center gap-1"><Play size={12} /> {fmtN(channelInsight.channel.videoCount)} vídeos</span>
                  <span className="flex items-center gap-1"><Eye size={12} /> {fmtN(channelInsight.channel.viewCount)} views totais</span>
                  {channelInsight.channel.country && <span className="flex items-center gap-1"><Globe size={12} /> {channelInsight.channel.country}</span>}
                </div>
              </div>
              <div className={cn('text-center px-4 py-2 rounded-xl', scoreBg(channelInsight.recentGrowthScore))}>
                <div className={cn('text-2xl font-bold', scoreColor(channelInsight.recentGrowthScore))}>{channelInsight.recentGrowthScore}</div>
                <div className="text-[9px] text-dp-text-tertiary">Growth Score</div>
              </div>
            </div>

            {/* Metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                ['Média Views/Vídeo', fmtN(channelInsight.avgViewsPerVideo), Eye],
                ['Frequência Upload', channelInsight.uploadFrequency, Clock],
                ['Nicho Estimado', channelInsight.estimatedNiche, TrendingUp],
                ['Crescimento', `${channelInsight.recentGrowthScore}/100`, Zap],
              ].map(([label, value, I]: any) => (
                <div key={label} className="dp-card text-center">
                  <I size={16} className="text-dp-accent-cyan mx-auto mb-2" />
                  <p className="text-lg font-bold text-dp-text-primary">{value}</p>
                  <p className="text-[10px] text-dp-text-tertiary">{label}</p>
                </div>
              ))}
            </div>

            {/* Top Videos */}
            <div>
              <h3 className="text-sm font-semibold text-dp-text-primary mb-3 flex items-center gap-2">
                <Flame size={14} className="text-dp-accent-orange" /> Top Vídeos
              </h3>
              <div className="space-y-2">
                {channelInsight.topVideos.map((v: any, i: number) => (
                  <div key={v.id} className="dp-card flex items-center gap-3">
                    <span className="text-xs font-bold text-dp-text-tertiary w-5">#{i + 1}</span>
                    <div className="flex-1 min-w-0">
                      <a href={`https://youtube.com/watch?v=${v.id}`} target="_blank" className="text-xs font-medium text-dp-text-primary truncate block hover:text-dp-accent-cyan">{v.title}</a>
                    </div>
                    <span className="text-xs text-dp-text-tertiary flex items-center gap-1"><Eye size={10} /> {fmtN(v.viewCount)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </>
  );
}

function formatDuration(iso: string): string {
  const m = iso.match(/PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?/);
  if (!m) return '0:00';
  const h = parseInt(m[1] || '0'), min = parseInt(m[2] || '0'), s = parseInt(m[3] || '0');
  if (h > 0) return `${h}:${String(min).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  return `${min}:${String(s).padStart(2, '0')}`;
}
