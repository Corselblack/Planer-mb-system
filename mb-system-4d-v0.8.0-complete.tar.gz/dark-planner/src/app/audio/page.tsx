'use client';

import { useState, useEffect, useCallback } from 'react';
import { Header } from '@/components/layout';
import { AudioGenerator } from '@/components/audio';
import { Mic, History, Download, Clock, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import { createClient } from '@/lib/supabase/client';
import type { Voice, AudioJob, Script } from '@/lib/supabase/types';

export default function AudioPage() {
  const [voices, setVoices] = useState<Voice[]>([]);
  const [scripts, setScripts] = useState<Script[]>([]);
  const [recentJobs, setRecentJobs] = useState<AudioJob[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'generator' | 'history'>('generator');

  const supabase = createClient();

  const loadData = useCallback(async () => {
    try {
      const [voicesRes, scriptsRes, jobsRes] = await Promise.all([
        supabase.from('voices').select('*').eq('is_active', true).order('name'),
        supabase.from('scripts').select('*').order('created_at', { ascending: false }),
        supabase.from('audio_jobs').select('*').order('created_at', { ascending: false }).limit(20),
      ]);
      setVoices(voicesRes.data || []);
      setScripts(scriptsRes.data || []);
      setRecentJobs(jobsRes.data || []);
    } catch (err) {
      console.error('Error loading audio data:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const statusIcon = (status: string) => {
    switch (status) {
      case 'succeeded': return <CheckCircle size={13} className="text-dp-accent-green" />;
      case 'failed': return <AlertCircle size={13} className="text-dp-accent-red" />;
      case 'processing': return <Loader2 size={13} className="text-dp-accent-yellow animate-spin" />;
      default: return <Clock size={13} className="text-dp-text-tertiary" />;
    }
  };

  return (
    <>
      <Header title="Gerador de Áudio" subtitle="Transforme texto em áudio narrado com IA" />

      <div className="p-6 animate-fade-in">
        {/* Tabs */}
        <div className="flex items-center gap-1 border-b border-dp-border-primary mb-6">
          <button
            onClick={() => setTab('generator')}
            className={cn(
              'px-4 py-2.5 text-xs font-medium border-b-2 -mb-px transition-colors',
              tab === 'generator'
                ? 'text-dp-accent-cyan border-dp-accent-cyan'
                : 'text-dp-text-tertiary border-transparent hover:text-dp-text-secondary',
            )}
          >
            <Mic size={14} className="inline mr-1.5" /> Gerar Áudio
          </button>
          <button
            onClick={() => setTab('history')}
            className={cn(
              'px-4 py-2.5 text-xs font-medium border-b-2 -mb-px transition-colors',
              tab === 'history'
                ? 'text-dp-accent-cyan border-dp-accent-cyan'
                : 'text-dp-text-tertiary border-transparent hover:text-dp-text-secondary',
            )}
          >
            <History size={14} className="inline mr-1.5" /> Histórico ({recentJobs.length})
          </button>
        </div>

        {loading ? (
          <div className="dp-card animate-pulse h-96" />
        ) : tab === 'generator' ? (
          <AudioGenerator
            voices={voices}
            scripts={scripts}
            onGenerate={() => loadData()}
          />
        ) : (
          /* History tab */
          <div className="space-y-2">
            {recentJobs.length === 0 ? (
              <div className="dp-card text-center py-12">
                <History size={32} className="text-dp-accent-cyan/40 mx-auto mb-3" />
                <p className="text-sm text-dp-text-secondary">Nenhum áudio gerado ainda</p>
              </div>
            ) : (
              recentJobs.map(job => (
                <div key={job.id} className="dp-card flex items-center gap-4">
                  {statusIcon(job.status)}
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-dp-text-primary truncate">
                      {job.name || 'Sem nome'}
                    </p>
                    <div className="flex items-center gap-3 mt-0.5 text-[10px] text-dp-text-tertiary">
                      <span>{job.provider === 'google' ? 'Google TTS' : 'ElevenLabs'}</span>
                      <span>{job.input_text.length.toLocaleString()} chars</span>
                      <span>{new Date(job.created_at).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                  </div>
                  <div className={cn(
                    'text-[10px] font-medium px-2 py-0.5 rounded-full',
                    job.status === 'succeeded' && 'bg-dp-accent-green/10 text-dp-accent-green',
                    job.status === 'failed' && 'bg-dp-accent-red/10 text-dp-accent-red',
                    job.status === 'processing' && 'bg-dp-accent-yellow/10 text-dp-accent-yellow',
                    job.status === 'queued' && 'bg-dp-bg-tertiary text-dp-text-tertiary',
                  )}>
                    {job.status === 'succeeded' ? 'Concluído' : job.status === 'failed' ? 'Falhou' : job.status === 'processing' ? 'Processando' : 'Na fila'}
                  </div>
                  {job.status === 'succeeded' && (
                    <button className="p-1.5 rounded hover:bg-dp-bg-hover text-dp-text-tertiary hover:text-dp-accent-cyan">
                      <Download size={14} />
                    </button>
                  )}
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </>
  );
}
