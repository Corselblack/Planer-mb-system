'use client';

import { useState, useEffect, useCallback, useMemo } from 'react';
import { Header } from '@/components/layout';
import { Modal, EmptyState } from '@/components/ui';
import { FileText, Plus, Search, Tag, Copy, Pencil, Trash2, X, Check } from 'lucide-react';
import { getPrompts, createPrompt, updatePrompt, deletePrompt, type Prompt } from '@/lib/supabase/organization-queries';
import { cn } from '@/lib/utils';

export default function PromptsPage() {
  const [prompts, setPrompts] = useState<Prompt[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [tagFilter, setTagFilter] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Prompt | null>(null);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  // Form
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [tagsInput, setTagsInput] = useState('');
  const [saving, setSaving] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);

  const loadData = useCallback(async () => {
    try { setPrompts(await getPrompts()); } catch (e) { console.error(e); } finally { setLoading(false); }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const allTags = useMemo(() => {
    const s = new Set<string>();
    prompts.forEach(p => p.tags.forEach(t => s.add(t)));
    return Array.from(s).sort();
  }, [prompts]);

  const filtered = useMemo(() => {
    return prompts.filter(p => {
      if (search && !p.title.toLowerCase().includes(search.toLowerCase()) && !p.body.toLowerCase().includes(search.toLowerCase())) return false;
      if (tagFilter && !p.tags.includes(tagFilter)) return false;
      return true;
    });
  }, [prompts, search, tagFilter]);

  const openNew = () => { setEditing(null); setTitle(''); setBody(''); setTagsInput(''); setModalOpen(true); };
  const openEdit = (p: Prompt) => { setEditing(p); setTitle(p.title); setBody(p.body); setTagsInput(p.tags.join(', ')); setModalOpen(true); };

  const handleSave = async () => {
    if (!title.trim()) return;
    setSaving(true);
    const tags = tagsInput.split(',').map(t => t.trim()).filter(Boolean);
    try {
      if (editing) { await updatePrompt(editing.id, { title, body, tags }); }
      else { await createPrompt({ title, body, tags }); }
      setModalOpen(false);
      loadData();
    } catch (e) { console.error(e); } finally { setSaving(false); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Deletar este prompt?')) return;
    await deletePrompt(id); loadData();
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <>
      <Header title="Biblioteca de Prompts" subtitle="Salve e reutilize seus melhores prompts" />

      <div className="p-6 space-y-4 animate-fade-in">
        {/* Toolbar */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-dp-text-tertiary" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar prompts..." className="dp-input w-full pl-8 text-xs" />
          </div>
          {allTags.length > 0 && (
            <select value={tagFilter} onChange={e => setTagFilter(e.target.value)} className="dp-input text-xs">
              <option value="">Todas as tags</option>
              {allTags.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          )}
          <button onClick={openNew} className="dp-btn-primary text-xs flex items-center gap-1.5">
            <Plus size={14} /> Novo Prompt
          </button>
        </div>

        {/* List */}
        {loading ? (
          <div className="space-y-3">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="dp-card animate-pulse h-24" />)}</div>
        ) : filtered.length === 0 ? (
          <EmptyState icon={FileText} title="Nenhum prompt encontrado" description={search || tagFilter ? 'Tente ajustar os filtros.' : 'Crie seu primeiro prompt para reutilizar nas suas sessões com IA.'} action={!search && !tagFilter ? { label: 'Criar Prompt', onClick: openNew } : undefined} />
        ) : (
          <div className="space-y-2">
            {filtered.map(p => (
              <div key={p.id} className="dp-card group">
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-dp-accent-cyan/10 mt-0.5">
                    <FileText size={14} className="text-dp-accent-cyan" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 cursor-pointer" onClick={() => setExpandedId(expandedId === p.id ? null : p.id)}>
                      <h3 className="text-sm font-medium text-dp-text-primary">{p.title}</h3>
                    </div>
                    {p.tags.length > 0 && (
                      <div className="flex gap-1.5 mt-1.5 flex-wrap">
                        {p.tags.map(t => (
                          <span key={t} className="text-[9px] px-2 py-0.5 rounded-full bg-dp-bg-tertiary text-dp-text-tertiary border border-dp-border-primary">
                            <Tag size={8} className="inline mr-0.5" />{t}
                          </span>
                        ))}
                      </div>
                    )}
                    {(expandedId === p.id) && p.body && (
                      <pre className="mt-3 text-xs text-dp-text-secondary whitespace-pre-wrap font-mono bg-dp-bg-tertiary/50 rounded-lg p-3 max-h-64 overflow-y-auto">{p.body}</pre>
                    )}
                  </div>
                  <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => handleCopy(p.id, p.body || p.title)} className="p-1.5 rounded hover:bg-dp-bg-hover" title="Copiar">
                      {copied === p.id ? <Check size={13} className="text-dp-accent-green" /> : <Copy size={13} className="text-dp-text-tertiary" />}
                    </button>
                    <button onClick={() => openEdit(p)} className="p-1.5 rounded hover:bg-dp-bg-hover" title="Editar">
                      <Pencil size={13} className="text-dp-text-tertiary" />
                    </button>
                    <button onClick={() => handleDelete(p.id)} className="p-1.5 rounded hover:bg-dp-bg-hover" title="Deletar">
                      <Trash2 size={13} className="text-dp-accent-red" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Modal */}
      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Editar Prompt' : 'Novo Prompt'} size="lg"
        footer={<div className="flex justify-end gap-2"><button onClick={() => setModalOpen(false)} className="dp-btn-secondary text-xs">Cancelar</button><button onClick={handleSave} disabled={!title.trim() || saving} className="dp-btn-primary text-xs">{saving ? 'Salvando...' : 'Salvar'}</button></div>}
      >
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Título *</label>
            <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Ex: Gerar roteiro de curiosidades" className="dp-input w-full text-xs" />
          </div>
          <div>
            <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Corpo do Prompt</label>
            <textarea value={body} onChange={e => setBody(e.target.value)} rows={10} placeholder="Cole aqui o conteúdo completo do prompt..." className="dp-input w-full text-xs font-mono resize-y" />
          </div>
          <div>
            <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Tags (separadas por vírgula)</label>
            <input value={tagsInput} onChange={e => setTagsInput(e.target.value)} placeholder="Ex: roteiro, curiosidades, ChatGPT" className="dp-input w-full text-xs" />
          </div>
        </div>
      </Modal>
    </>
  );
}
