import { NextRequest, NextResponse } from 'next/server';
import { createServerSupabase } from '@/lib/supabase/server';

export async function GET(request: NextRequest) {
  const supabase = createServerSupabase();
  const language = request.nextUrl.searchParams.get('language');
  const provider = request.nextUrl.searchParams.get('provider');

  let query = supabase.from('voices').select('*').eq('is_active', true);
  if (provider) query = query.eq('provider', provider);
  if (language) query = query.contains('language_tags', [language]);

  const { data, error } = await query.order('name');
  if (error) return NextResponse.json({ error: error.message }, { status: 500 });
  return NextResponse.json(data);
}
