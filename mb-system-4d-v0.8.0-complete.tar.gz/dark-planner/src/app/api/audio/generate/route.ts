import { NextRequest, NextResponse } from 'next/server';
import { createServerSupabase } from '@/lib/supabase/server';
import { createProvider, generateSRT, generateViewSRT, generateEstimatedSRT, srtToString } from '@/lib/providers';
import type { TTSProvider, CaptionFontSize } from '@/lib/supabase/types';

interface GenerateRequest {
  text: string;
  voice_id: string;        // UUID da tabela voices
  provider: TTSProvider;
  provider_voice_id: string;
  name?: string;
  channel_id?: string;
  script_id?: string;
  speed?: number;
  volume?: number;
  words_per_caption?: number;
  caption_font_size?: CaptionFontSize;
}

export async function POST(request: NextRequest) {
  const supabase = createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const body: GenerateRequest = await request.json();
  const {
    text, voice_id, provider, provider_voice_id,
    name, channel_id, script_id,
    speed = 1.0, volume = 1.0,
    words_per_caption = 5, caption_font_size = 'medium',
  } = body;

  if (!text?.trim()) return NextResponse.json({ error: 'Text is required' }, { status: 400 });
  if (!provider_voice_id) return NextResponse.json({ error: 'Voice is required' }, { status: 400 });

  // 1. Criar audio_job com status 'processing'
  const { data: job, error: jobErr } = await supabase
    .from('audio_jobs')
    .insert({
      user_id: user.id,
      channel_id: channel_id || null,
      script_id: script_id || null,
      voice_id,
      input_text: text,
      name: name || `Audio_${Date.now()}`,
      provider,
      params_speed: speed,
      params_volume: volume,
      params_words_per_caption: words_per_caption,
      params_caption_font_size: caption_font_size,
      status: 'processing',
    })
    .select()
    .single();

  if (jobErr) return NextResponse.json({ error: jobErr.message }, { status: 500 });

  try {
    // 2. Gerar áudio via provider
    const ttsProvider = createProvider(provider);
    const result = await ttsProvider.generateAudio({
      text, voiceId: provider_voice_id, speed, volume,
    });

    // 3. Upload MP3 para Supabase Storage
    const audioPath = `audio/${user.id}/${job.id}.mp3`;
    const { error: uploadErr } = await supabase.storage
      .from('assets')
      .upload(audioPath, new Uint8Array(result.audioBuffer), {
        contentType: 'audio/mpeg',
        upsert: true,
      });
    if (uploadErr) throw new Error(`Upload MP3 failed: ${uploadErr.message}`);

    // 4. Gerar SRT
    let srtContent: string;
    let viewSrtContent: string;

    if (result.wordTimings && result.wordTimings.length > 0) {
      const srtSegments = generateSRT(result.wordTimings, words_per_caption);
      srtContent = srtToString(srtSegments);
      const viewSegments = generateViewSRT(result.wordTimings, 8000);
      viewSrtContent = srtToString(viewSegments);
    } else {
      // Fallback: SRT estimado
      const durationMs = result.durationMs || estimateDuration(text, speed);
      const srtSegments = generateEstimatedSRT(text, durationMs, words_per_caption);
      srtContent = srtToString(srtSegments);
      viewSrtContent = srtContent; // sem timestamps reais, view = normal
    }

    // 5. Upload SRT files
    const srtPath = `srt/${user.id}/${job.id}.srt`;
    const viewSrtPath = `srt/${user.id}/${job.id}_view.srt`;

    await supabase.storage.from('assets').upload(srtPath, srtContent, {
      contentType: 'text/plain', upsert: true,
    });
    await supabase.storage.from('assets').upload(viewSrtPath, viewSrtContent, {
      contentType: 'text/plain', upsert: true,
    });

    // 6. Criar registros de assets
    const audioAsset = await createAsset(supabase, user.id, 'audio_mp3', audioPath, 'audio/mpeg', result.audioBuffer.byteLength);
    const srtAsset = await createAsset(supabase, user.id, 'srt', srtPath, 'text/plain', new Blob([srtContent]).size);
    const viewSrtAsset = await createAsset(supabase, user.id, 'view_srt', viewSrtPath, 'text/plain', new Blob([viewSrtContent]).size);

    // 7. Atualizar job como succeeded
    const { data: updatedJob } = await supabase
      .from('audio_jobs')
      .update({
        status: 'succeeded',
        output_audio_asset_id: audioAsset.id,
        output_srt_asset_id: srtAsset.id,
        output_view_srt_asset_id: viewSrtAsset.id,
        finished_at: new Date().toISOString(),
      })
      .eq('id', job.id)
      .select()
      .single();

    // 8. Atualizar usage counter
    await supabase.rpc('increment_usage', {
      p_user_id: user.id,
      p_chars: text.length,
    }).catch(() => {
      // Fallback: upsert manual
      // Se RPC não existe, ignorar (será criada depois)
    });

    return NextResponse.json({
      job: updatedJob,
      audio_url: getPublicUrl(supabase, audioPath),
      srt_url: getPublicUrl(supabase, srtPath),
      view_srt_url: getPublicUrl(supabase, viewSrtPath),
    });

  } catch (err: any) {
    // Marcar job como failed
    await supabase
      .from('audio_jobs')
      .update({
        status: 'failed',
        error_message: err.message,
        finished_at: new Date().toISOString(),
      })
      .eq('id', job.id);

    return NextResponse.json({ error: err.message, job_id: job.id }, { status: 500 });
  }
}

// ============================================================
// Helpers
// ============================================================

async function createAsset(supabase: any, userId: string, type: string, path: string, contentType: string, sizeBytes: number) {
  const { data, error } = await supabase
    .from('assets')
    .insert({
      user_id: userId,
      type,
      storage_path: path,
      content_type: contentType,
      size_bytes: sizeBytes,
    })
    .select()
    .single();
  if (error) throw new Error(`Asset creation failed: ${error.message}`);
  return data;
}

function getPublicUrl(supabase: any, path: string): string {
  const { data } = supabase.storage.from('assets').getPublicUrl(path);
  return data?.publicUrl || '';
}

function estimateDuration(text: string, speed: number): number {
  const words = text.split(/\s+/).filter(Boolean).length;
  const wpm = 150 * speed;
  return Math.round((words / wpm) * 60 * 1000);
}
