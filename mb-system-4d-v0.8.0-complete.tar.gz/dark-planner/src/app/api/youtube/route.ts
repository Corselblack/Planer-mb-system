import { NextRequest, NextResponse } from 'next/server';
import { createServerSupabase } from '@/lib/supabase/server';
import {
  searchVideos, getVideoDetails, getTrending,
  buildChannelInsight, calculateViralMetrics,
} from '@/lib/providers/youtube';

// GET /api/youtube?action=trending|search|channel&...
export async function GET(request: NextRequest) {
  const supabase = createServerSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const action = request.nextUrl.searchParams.get('action');

  try {
    switch (action) {
      case 'trending': {
        const region = request.nextUrl.searchParams.get('region') || 'BR';
        const category = request.nextUrl.searchParams.get('category') || undefined;
        const videos = await getTrending(region, category, 25);
        const metrics = videos.map(v => calculateViralMetrics(v));
        metrics.sort((a, b) => b.viralScore - a.viralScore);
        return NextResponse.json({ videos: metrics });
      }

      case 'search': {
        const q = request.nextUrl.searchParams.get('q');
        if (!q) return NextResponse.json({ error: 'Query required' }, { status: 400 });
        const order = (request.nextUrl.searchParams.get('order') || 'viewCount') as any;
        const days = parseInt(request.nextUrl.searchParams.get('days') || '30');
        const publishedAfter = new Date(Date.now() - days * 86400000).toISOString();
        const region = request.nextUrl.searchParams.get('region') || 'BR';

        const results = await searchVideos(q, { maxResults: 20, order, publishedAfter, regionCode: region });
        const videoIds = results.map(r => r.videoId).filter(Boolean);
        const details = await getVideoDetails(videoIds);
        const metrics = details.map(v => calculateViralMetrics(v));
        metrics.sort((a, b) => b.viralScore - a.viralScore);
        return NextResponse.json({ videos: metrics });
      }

      case 'channel': {
        const channelId = request.nextUrl.searchParams.get('channelId');
        if (!channelId) return NextResponse.json({ error: 'channelId required' }, { status: 400 });
        const insight = await buildChannelInsight(channelId);
        return NextResponse.json(insight);
      }

      default:
        return NextResponse.json({ error: 'Invalid action' }, { status: 400 });
    }
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
