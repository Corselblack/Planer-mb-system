'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { Header } from '@/components/layout';
import { EmptyState } from '@/components/ui';
import { ChannelForm, type ChannelFormData } from '@/components/pipeline';
import { Tv, Plus, ArrowRight, Clock, FileText, Cog, CheckCircle, Calendar, Globe, AlertTriangle } from 'lucide-react';
import type { ProjectChannel, VideoStatus } from '@/lib/supabase/types';
import * as queries from '@/lib/supabase/queries';

type ChannelWithStats = {
  channel: ProjectChannel;
  counts: Record<VideoStatus, number>;
};

export default function CanaisPage() {
  const router = useRouter();
  const [channels, setChannels] = useState<ChannelWithStats[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);

  const loadChannels = useCallback(async () => {
    try {
      const stats = await queries.getChannelStats();
      setChannels(stats);
    } catch (err) {
      console.error('Error loading channels:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadChannels(); }, [loadChannels]);

  const handleCreateChannel = async (data: ChannelFormData) => {
    const { shortcuts, ...channelData } = data;
    const newChannel = await queries.createChannel(channelData);
    if (shortcuts.length > 0) {
      await queries.upsertShortcuts(newChannel.id, shortcuts);
    }
    await loadChannels();
  };

  const total = channels.reduce((sum, c) => {
    return sum + Object.values(c.counts).reduce((a, b) => a + b, 0);
  }, 0);

  return (
    <>
      <Header title="Canais" subtitle={`${channels.length} canais · ${total} vídeos no total`} />

      <div className="p-6 animate-fade-in">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-xl font-bold text-dp-text-primary">Meus Canais</h1>
          <button onClick={() => setShowForm(true)} className="dp-btn-primary text-sm flex items-center gap-2">
            <Plus size={16} /> Novo Canal
          </button>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3].map(i => (
              <div key={i} className="dp-card animate-pulse h-48" />
            ))}
          </div>
        ) : channels.length === 0 ? (
          <EmptyState
            icon={Tv}
            title="Nenhum canal criado"
            description="Crie seu primeiro canal Dark/Faceless para começar a organizar seus vídeos e roteiros."
            action={{ label: '+ Criar Primeiro Canal', onClick: () => setShowForm(true) }}
          />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {channels.map(({ channel, counts }) => {
              const videoTotal = Object.values(counts).reduce((a, b) => a + b, 0);
              return (
                <div
                  key={channel.id}
                  onClick={() => router.push(`/canais/${channel.id}`)}
                  className="dp-card-interactive group cursor-pointer"
                >
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-dp-accent-cyan/20 to-dp-accent-blue/20 flex items-center justify-center">
                        <Tv size={18} className="text-dp-accent-cyan" />
                      </div>
                      <div>
                        <h3 className="text-sm font-semibold text-dp-text-primary group-hover:text-dp-accent-cyan transition-colors">
                          {channel.name}
                        </h3>
                        <div className="flex items-center gap-2 mt-0.5">
                          <span className="text-[10px] text-dp-text-tertiary">{channel.language}</span>
                          {channel.frequency && (
                            <>
                              <span className="text-dp-text-tertiary">·</span>
                              <span className="text-[10px] text-dp-text-tertiary">{channel.frequency}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                    <ArrowRight size={16} className="text-dp-text-tertiary group-hover:text-dp-accent-cyan transition-colors" />
                  </div>

                  <div className="grid grid-cols-3 gap-2 mb-2">
                    <MiniStat icon={FileText} value={counts.planning} color="blue" />
                    <MiniStat icon={Cog} value={counts.production} color="orange" />
                    <MiniStat icon={CheckCircle} value={counts.ready} color="purple" />
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <MiniStat icon={Calendar} value={counts.scheduled} color="yellow" />
                    <MiniStat icon={Globe} value={counts.published} color="green" />
                    <MiniStat icon={AlertTriangle} value={counts.overdue} color="red" />
                  </div>

                  <div className="flex items-center justify-between mt-4 pt-3 border-t border-dp-border-primary">
                    <span className="text-[10px] text-dp-text-tertiary">{videoTotal} vídeos</span>
                    {channel.posting_time && (
                      <span className="flex items-center gap-1 text-[10px] text-dp-text-tertiary">
                        <Clock size={10} /> {channel.posting_time}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <ChannelForm open={showForm} onClose={() => setShowForm(false)} onSave={handleCreateChannel} />
    </>
  );
}

function MiniStat({ icon: Icon, value, color }: { icon: typeof FileText; value: number; color: string }) {
  return (
    <div className="flex items-center gap-1.5 px-2 py-1.5 rounded-md bg-dp-bg-tertiary/50">
      <Icon size={10} className={`text-dp-accent-${color}`} />
      <span className="text-[10px] text-dp-text-secondary">{value}</span>
    </div>
  );
}
