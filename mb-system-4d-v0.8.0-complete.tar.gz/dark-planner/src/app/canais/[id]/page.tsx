'use client';

import { useState, useEffect, useCallback } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { Header } from '@/components/layout';
import { PipelineBoard, ChannelForm, VideoForm, ScriptEditor, type ChannelFormData, type VideoFormData } from '@/components/pipeline';
import {
  Tv, Pencil, Trash2, ExternalLink, FileText, Plus, ArrowLeft, Link2, Settings,
} from 'lucide-react';
import type { ProjectChannel, ChannelShortcut, VideoItem, Script, VideoStatus } from '@/lib/supabase/types';
import * as queries from '@/lib/supabase/queries';

type VideoWithScript = VideoItem & { scripts: Pick<Script, 'id' | 'title' | 'char_count'> | null };

export default function ChannelDetailPage() {
  const params = useParams();
  const router = useRouter();
  const channelId = params.id as string;

  const [channel, setChannel] = useState<ProjectChannel | null>(null);
  const [shortcuts, setShortcuts] = useState<ChannelShortcut[]>([]);
  const [videos, setVideos] = useState<VideoWithScript[]>([]);
  const [scripts, setScripts] = useState<Script[]>([]);
  const [loading, setLoading] = useState(true);

  // Modal states
  const [showEditChannel, setShowEditChannel] = useState(false);
  const [showVideoForm, setShowVideoForm] = useState(false);
  const [showScriptEditor, setShowScriptEditor] = useState(false);
  const [editingVideo, setEditingVideo] = useState<VideoItem | null>(null);
  const [editingScript, setEditingScript] = useState<Script | null>(null);
  const [newVideoStatus, setNewVideoStatus] = useState<VideoStatus>('planning');
  const [activeTab, setActiveTab] = useState<'pipeline' | 'scripts'>('pipeline');

  const loadData = useCallback(async () => {
    try {
      const [ch, sc, vids, scrpts] = await Promise.all([
        queries.getChannel(channelId),
        queries.getChannelShortcuts(channelId),
        queries.getVideosByChannel(channelId),
        queries.getScriptsByChannel(channelId),
      ]);
      setChannel(ch);
      setShortcuts(sc);
      setVideos(vids);
      setScripts(scrpts);
    } catch (err) {
      console.error('Error loading channel:', err);
    } finally {
      setLoading(false);
    }
  }, [channelId]);

  useEffect(() => { loadData(); }, [loadData]);

  // === Channel handlers ===
  const handleUpdateChannel = async (data: ChannelFormData) => {
    const { shortcuts: newShortcuts, ...channelData } = data;
    await queries.updateChannel(channelId, channelData);
    await queries.upsertShortcuts(channelId, newShortcuts);
    await loadData();
  };

  const handleDeleteChannel = async () => {
    if (!confirm(`Excluir "${channel?.name}"? Todos os vídeos e roteiros serão removidos.`)) return;
    await queries.deleteChannel(channelId);
    router.push('/canais');
  };

  // === Video handlers ===
  const handleCreateVideo = async (data: VideoFormData) => {
    await queries.createVideo({ ...data, channel_id: channelId });
    await loadData();
  };

  const handleEditVideo = async (data: VideoFormData) => {
    if (!editingVideo) return;
    await queries.updateVideo(editingVideo.id, data);
    setEditingVideo(null);
    await loadData();
  };

  const handleDeleteVideo = async (id: string) => {
    if (!confirm('Excluir este vídeo?')) return;
    await queries.deleteVideo(id);
    await loadData();
  };

  const handleMoveVideo = async (id: string, newStatus: VideoStatus) => {
    await queries.updateVideoStatus(id, newStatus);
    await loadData();
  };

  // === Script handlers ===
  const handleCreateScript = async (data: { title: string; body_text: string }) => {
    await queries.createScript({ ...data, channel_id: channelId });
    await loadData();
  };

  const handleEditScript = async (data: { title: string; body_text: string }) => {
    if (!editingScript) return;
    await queries.updateScript(editingScript.id, data);
    setEditingScript(null);
    await loadData();
  };

  const handleDeleteScript = async (id: string) => {
    if (!confirm('Excluir este roteiro?')) return;
    await queries.deleteScript(id);
    await loadData();
  };

  if (loading) {
    return (
      <>
        <Header title="Carregando..." />
        <div className="p-6"><div className="dp-card animate-pulse h-96" /></div>
      </>
    );
  }

  if (!channel) {
    return (
      <>
        <Header title="Canal não encontrado" />
        <div className="p-6 text-center">
          <p className="text-dp-text-secondary">Canal não existe ou foi removido.</p>
          <button onClick={() => router.push('/canais')} className="dp-btn-primary mt-4 text-sm">
            Voltar
          </button>
        </div>
      </>
    );
  }

  return (
    <>
      <Header
        title={channel.name}
        subtitle={`${channel.language} · ${videos.length} vídeos · ${scripts.length} roteiros`}
      />

      <div className="p-6 space-y-6 animate-fade-in">
        {/* Top nav */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => router.push('/canais')}
            className="flex items-center gap-1.5 text-xs text-dp-text-secondary hover:text-dp-accent-cyan transition-colors"
          >
            <ArrowLeft size={14} /> Voltar para Canais
          </button>
          <div className="flex items-center gap-2">
            <button onClick={() => setShowEditChannel(true)} className="dp-btn-secondary text-xs flex items-center gap-1.5 py-1.5">
              <Settings size={14} /> Configurações
            </button>
            <button onClick={handleDeleteChannel} className="p-2 rounded-lg hover:bg-dp-accent-red/10 text-dp-text-tertiary hover:text-dp-accent-red transition-colors" title="Excluir canal">
              <Trash2 size={16} />
            </button>
          </div>
        </div>

        {/* Shortcuts bar */}
        {shortcuts.length > 0 && (
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-[10px] text-dp-text-tertiary font-medium">ATALHOS:</span>
            {shortcuts.map(s => (
              <a
                key={s.id}
                href={s.url}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1 px-2.5 py-1 rounded-md bg-dp-bg-tertiary border border-dp-border-primary text-xs text-dp-text-secondary hover:text-dp-accent-cyan hover:border-dp-accent-cyan/30 transition-colors"
              >
                <ExternalLink size={10} />
                {s.label}
              </a>
            ))}
          </div>
        )}

        {/* Notes */}
        {channel.notes && (
          <div className="px-4 py-3 rounded-lg bg-dp-bg-tertiary/50 border border-dp-border-primary">
            <p className="text-xs text-dp-text-secondary">{channel.notes}</p>
          </div>
        )}

        {/* Tabs */}
        <div className="flex items-center gap-1 border-b border-dp-border-primary">
          <TabButton active={activeTab === 'pipeline'} onClick={() => setActiveTab('pipeline')}>
            Pipeline ({videos.length})
          </TabButton>
          <TabButton active={activeTab === 'scripts'} onClick={() => setActiveTab('scripts')}>
            Roteiros ({scripts.length})
          </TabButton>
        </div>

        {/* Pipeline Tab */}
        {activeTab === 'pipeline' && (
          <>
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold text-dp-text-primary">Pipeline de Vídeos</h2>
              <button
                onClick={() => { setNewVideoStatus('planning'); setEditingVideo(null); setShowVideoForm(true); }}
                className="dp-btn-primary text-xs flex items-center gap-1.5"
              >
                <Plus size={14} /> Novo Vídeo
              </button>
            </div>

            <PipelineBoard
              videos={videos}
              onCreateVideo={(status) => { setNewVideoStatus(status); setEditingVideo(null); setShowVideoForm(true); }}
              onEditVideo={(v) => { setEditingVideo(v); setShowVideoForm(true); }}
              onDeleteVideo={handleDeleteVideo}
              onMoveVideo={handleMoveVideo}
            />
          </>
        )}

        {/* Scripts Tab */}
        {activeTab === 'scripts' && (
          <>
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold text-dp-text-primary">Roteiros</h2>
              <button
                onClick={() => { setEditingScript(null); setShowScriptEditor(true); }}
                className="dp-btn-primary text-xs flex items-center gap-1.5"
              >
                <Plus size={14} /> Novo Roteiro
              </button>
            </div>

            {scripts.length === 0 ? (
              <div className="dp-card text-center py-12">
                <FileText size={32} className="text-dp-accent-cyan/40 mx-auto mb-3" />
                <p className="text-sm text-dp-text-secondary mb-2">Nenhum roteiro criado</p>
                <button
                  onClick={() => { setEditingScript(null); setShowScriptEditor(true); }}
                  className="text-xs text-dp-accent-cyan hover:underline"
                >
                  + Criar primeiro roteiro
                </button>
              </div>
            ) : (
              <div className="space-y-2">
                {scripts.map(script => {
                  const linkedVideos = videos.filter(v => v.script_id === script.id);
                  return (
                    <div key={script.id} className="dp-card-interactive group flex items-center gap-4">
                      <div className="p-2 rounded-lg bg-dp-accent-cyan/10">
                        <FileText size={16} className="text-dp-accent-cyan" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-dp-text-primary truncate">{script.title}</p>
                        <div className="flex items-center gap-3 mt-0.5">
                          <span className="text-[10px] text-dp-text-tertiary">
                            {script.char_count.toLocaleString('pt-BR')} chars · {script.word_count} palavras
                          </span>
                          {linkedVideos.length > 0 && (
                            <span className="flex items-center gap-1 text-[10px] text-dp-accent-cyan">
                              <Link2 size={9} /> {linkedVideos.length} vídeo{linkedVideos.length > 1 ? 's' : ''}
                            </span>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => { setEditingScript(script); setShowScriptEditor(true); }}
                          className="p-1.5 rounded hover:bg-dp-bg-hover text-dp-text-tertiary hover:text-dp-accent-cyan"
                        >
                          <Pencil size={13} />
                        </button>
                        <button
                          onClick={() => handleDeleteScript(script.id)}
                          className="p-1.5 rounded hover:bg-dp-bg-hover text-dp-text-tertiary hover:text-dp-accent-red"
                        >
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </>
        )}
      </div>

      {/* Modals */}
      <ChannelForm
        open={showEditChannel}
        onClose={() => setShowEditChannel(false)}
        onSave={handleUpdateChannel}
        channel={channel}
        shortcuts={shortcuts}
      />

      <VideoForm
        open={showVideoForm}
        onClose={() => { setShowVideoForm(false); setEditingVideo(null); }}
        onSave={editingVideo ? handleEditVideo : handleCreateVideo}
        video={editingVideo ?? undefined}
        scripts={scripts}
        channelId={channelId}
      />

      <ScriptEditor
        open={showScriptEditor}
        onClose={() => { setShowScriptEditor(false); setEditingScript(null); }}
        onSave={editingScript ? handleEditScript : handleCreateScript}
        script={editingScript ?? undefined}
      />
    </>
  );
}

function TabButton({ active, onClick, children }: { active: boolean; onClick: () => void; children: React.ReactNode }) {
  return (
    <button
      onClick={onClick}
      className={`px-4 py-2.5 text-xs font-medium transition-colors border-b-2 -mb-px ${
        active
          ? 'text-dp-accent-cyan border-dp-accent-cyan'
          : 'text-dp-text-tertiary border-transparent hover:text-dp-text-secondary'
      }`}
    >
      {children}
    </button>
  );
}
