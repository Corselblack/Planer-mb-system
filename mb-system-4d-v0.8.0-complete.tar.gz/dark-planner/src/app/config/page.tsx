'use client';

import { useState, useEffect, useCallback } from 'react';
import { Header } from '@/components/layout';
import {
  Settings, Key, Palette, Shield, Database, Bell, Save, Check,
  Eye, EyeOff, AlertTriangle, RefreshCw, Trash2, Download,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { createClient } from '@/lib/supabase/client';

type Section = 'api' | 'theme' | 'notifications' | 'data' | 'about';

export default function ConfigPage() {
  const [section, setSection] = useState<Section>('api');
  const [saved, setSaved] = useState(false);

  const showSaved = () => { setSaved(true); setTimeout(() => setSaved(false), 2000); };

  return (
    <>
      <Header title="Configurações" subtitle="Gerencie APIs, preferências e dados" />
      <div className="p-6 animate-fade-in">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Sidebar */}
          <nav className="space-y-1">
            {([
              ['api', 'Chaves de API', Key],
              ['theme', 'Aparência', Palette],
              ['notifications', 'Notificações', Bell],
              ['data', 'Dados & Backup', Database],
              ['about', 'Sobre', Shield],
            ] as const).map(([k, l, I]) => (
              <button key={k} onClick={() => setSection(k)}
                className={cn('flex items-center gap-2.5 w-full px-3 py-2.5 rounded-lg text-xs font-medium transition-colors',
                  section === k ? 'bg-dp-accent-cyan/10 text-dp-accent-cyan' : 'text-dp-text-tertiary hover:bg-dp-bg-hover hover:text-dp-text-secondary')}>
                <I size={14} /> {l}
              </button>
            ))}
          </nav>

          {/* Content */}
          <div className="lg:col-span-3">
            {section === 'api' && <ApiKeysSection onSave={showSaved} />}
            {section === 'theme' && <ThemeSection onSave={showSaved} />}
            {section === 'notifications' && <NotificationSection onSave={showSaved} />}
            {section === 'data' && <DataSection />}
            {section === 'about' && <AboutSection />}
          </div>
        </div>

        {/* Save toast */}
        {saved && (
          <div className="fixed bottom-6 right-6 bg-dp-accent-green text-dp-bg-primary px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 shadow-lg animate-fade-in">
            <Check size={16} /> Configurações salvas
          </div>
        )}
      </div>
    </>
  );
}

// ============================================================
// API Keys
// ============================================================
function ApiKeysSection({ onSave }: { onSave: () => void }) {
  const [googleKey, setGoogleKey] = useState('');
  const [elevenKey, setElevenKey] = useState('');
  const [ytKey, setYtKey] = useState('');
  const [showKeys, setShowKeys] = useState(false);

  const KeyInput = ({ label, value, onChange, placeholder }: any) => (
    <div className="dp-card mb-3">
      <div className="flex items-center justify-between mb-2">
        <label className="text-xs font-medium text-dp-text-secondary">{label}</label>
        <span className={cn('text-[9px] px-1.5 py-0.5 rounded-full', value ? 'bg-dp-accent-green/10 text-dp-accent-green' : 'bg-dp-bg-tertiary text-dp-text-tertiary')}>
          {value ? 'Configurada' : 'Não configurada'}
        </span>
      </div>
      <div className="relative">
        <input type={showKeys ? 'text' : 'password'} value={value} onChange={onChange} placeholder={placeholder}
          className="dp-input w-full pr-10 text-xs font-mono" />
        <button onClick={() => setShowKeys(!showKeys)} className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-dp-text-tertiary hover:text-dp-accent-cyan">
          {showKeys ? <EyeOff size={13} /> : <Eye size={13} />}
        </button>
      </div>
    </div>
  );

  return (
    <div>
      <h2 className="text-sm font-semibold text-dp-text-primary mb-4 flex items-center gap-2"><Key size={16} className="text-dp-accent-cyan" /> Chaves de API</h2>
      <div className="dp-card border-dp-accent-yellow/20 mb-4 flex items-start gap-2">
        <AlertTriangle size={14} className="text-dp-accent-yellow mt-0.5 flex-shrink-0" />
        <p className="text-[11px] text-dp-text-secondary">As chaves são armazenadas localmente no arquivo <code className="bg-dp-bg-tertiary px-1 rounded">.env.local</code>. Nunca compartilhe ou commite este arquivo.</p>
      </div>
      <KeyInput label="Google Cloud TTS API Key" value={googleKey} onChange={(e: any) => setGoogleKey(e.target.value)} placeholder="AIza..." />
      <KeyInput label="ElevenLabs API Key" value={elevenKey} onChange={(e: any) => setElevenKey(e.target.value)} placeholder="sk_..." />
      <KeyInput label="YouTube Data API v3 Key" value={ytKey} onChange={(e: any) => setYtKey(e.target.value)} placeholder="AIza..." />
      <p className="text-[10px] text-dp-text-tertiary mt-4">As chaves devem ser configuradas no arquivo <code>.env.local</code> na raiz do projeto. Esta seção é apenas para referência visual.</p>
    </div>
  );
}

// ============================================================
// Theme
// ============================================================
function ThemeSection({ onSave }: { onSave: () => void }) {
  const [accentColor, setAccentColor] = useState('cyan');
  const [sidebarWidth, setSidebarWidth] = useState('240');
  const [density, setDensity] = useState('normal');

  const colors = [
    { v: 'cyan', bg: '#00BCD4' }, { v: 'blue', bg: '#2196F3' }, { v: 'purple', bg: '#9C27B0' },
    { v: 'green', bg: '#4CAF50' }, { v: 'orange', bg: '#FF9800' }, { v: 'red', bg: '#F44336' },
  ];

  return (
    <div>
      <h2 className="text-sm font-semibold text-dp-text-primary mb-4 flex items-center gap-2"><Palette size={16} className="text-dp-accent-cyan" /> Aparência</h2>
      <div className="dp-card mb-3">
        <label className="block text-xs font-medium text-dp-text-secondary mb-3">Cor de Destaque</label>
        <div className="flex items-center gap-3">
          {colors.map(c => (
            <button key={c.v} onClick={() => { setAccentColor(c.v); onSave(); }}
              className={cn('w-8 h-8 rounded-full border-2 transition-transform',
                accentColor === c.v ? 'border-white scale-110' : 'border-transparent')}
              style={{ backgroundColor: c.bg }} />
          ))}
        </div>
      </div>
      <div className="dp-card mb-3">
        <label className="block text-xs font-medium text-dp-text-secondary mb-2">Densidade da Interface</label>
        <div className="flex gap-2">
          {(['compact', 'Compacto'], ['normal', 'Normal'], ['relaxed', 'Espaçado']).map(([v, l]: any) => (
            <button key={v} onClick={() => { setDensity(v); onSave(); }}
              className={cn('px-3 py-1.5 rounded-lg text-xs border transition-colors',
                density === v ? 'bg-dp-accent-cyan/10 text-dp-accent-cyan border-dp-accent-cyan/30' : 'text-dp-text-tertiary border-dp-border-primary hover:bg-dp-bg-hover')}>
              {l}
            </button>
          ))}
        </div>
      </div>
      <p className="text-[10px] text-dp-text-tertiary">Tema escuro é o padrão. Tema claro poderá ser adicionado em versões futuras.</p>
    </div>
  );
}

// ============================================================
// Notifications
// ============================================================
function NotificationSection({ onSave }: { onSave: () => void }) {
  const [overdueAlert, setOverdueAlert] = useState(true);
  const [viralAlert, setViralAlert] = useState(true);
  const [quotaAlert, setQuotaAlert] = useState(true);

  const Toggle = ({ label, desc, checked, onChange }: any) => (
    <div className="dp-card flex items-center justify-between mb-2">
      <div>
        <p className="text-xs font-medium text-dp-text-primary">{label}</p>
        <p className="text-[10px] text-dp-text-tertiary">{desc}</p>
      </div>
      <button onClick={() => { onChange(!checked); onSave(); }}
        className={cn('w-10 h-5 rounded-full transition-colors relative', checked ? 'bg-dp-accent-cyan' : 'bg-dp-bg-tertiary')}>
        <div className={cn('w-4 h-4 rounded-full bg-white absolute top-0.5 transition-transform', checked ? 'translate-x-5' : 'translate-x-0.5')} />
      </button>
    </div>
  );

  return (
    <div>
      <h2 className="text-sm font-semibold text-dp-text-primary mb-4 flex items-center gap-2"><Bell size={16} className="text-dp-accent-cyan" /> Notificações</h2>
      <Toggle label="Vídeos Atrasados" desc="Alertar quando um vídeo agendado não foi publicado" checked={overdueAlert} onChange={setOverdueAlert} />
      <Toggle label="Nicho Viral" desc="Alertar quando um nicho monitorado tiver score alto" checked={viralAlert} onChange={setViralAlert} />
      <Toggle label="Quota TTS" desc="Alertar quando a quota de caracteres estiver perto do limite" checked={quotaAlert} onChange={setQuotaAlert} />
    </div>
  );
}

// ============================================================
// Data & Backup
// ============================================================
function DataSection() {
  const supabase = createClient();
  const [exporting, setExporting] = useState(false);

  const handleExport = async () => {
    setExporting(true);
    try {
      const tables = ['project_channels', 'video_items', 'scripts', 'prompts', 'references', 'idea_board', 'monitored_niches', 'removed_channels'];
      const dump: Record<string, any[]> = {};
      for (const t of tables) {
        const { data } = await supabase.from(t).select('*');
        dump[t] = data || [];
      }
      const blob = new Blob([JSON.stringify(dump, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a'); a.href = url; a.download = `mb-system-4d-backup-${new Date().toISOString().slice(0, 10)}.json`;
      a.click(); URL.revokeObjectURL(url);
    } catch (e) { console.error(e); } finally { setExporting(false); }
  };

  return (
    <div>
      <h2 className="text-sm font-semibold text-dp-text-primary mb-4 flex items-center gap-2"><Database size={16} className="text-dp-accent-cyan" /> Dados & Backup</h2>
      <div className="dp-card mb-3">
        <h3 className="text-xs font-medium text-dp-text-primary mb-2">Exportar Dados</h3>
        <p className="text-[10px] text-dp-text-tertiary mb-3">Exporta todos os dados (canais, vídeos, roteiros, prompts, referências, ideias, nichos) em formato JSON.</p>
        <button onClick={handleExport} disabled={exporting} className="dp-btn-primary text-xs flex items-center gap-1.5">
          {exporting ? <RefreshCw size={12} className="animate-spin" /> : <Download size={12} />}
          {exporting ? 'Exportando...' : 'Exportar JSON'}
        </button>
      </div>
      <div className="dp-card border-dp-accent-red/20">
        <h3 className="text-xs font-medium text-dp-accent-red mb-2 flex items-center gap-1.5"><AlertTriangle size={12} /> Zona de Perigo</h3>
        <p className="text-[10px] text-dp-text-tertiary mb-3">Ações irreversíveis. Faça backup antes.</p>
        <button className="text-xs text-dp-accent-red border border-dp-accent-red/30 px-3 py-1.5 rounded-lg hover:bg-dp-accent-red/10 transition-colors flex items-center gap-1.5">
          <Trash2 size={12} /> Limpar Todos os Dados
        </button>
      </div>
    </div>
  );
}

// ============================================================
// About
// ============================================================
function AboutSection() {
  return (
    <div>
      <h2 className="text-sm font-semibold text-dp-text-primary mb-4 flex items-center gap-2"><Shield size={16} className="text-dp-accent-cyan" /> Sobre</h2>
      <div className="dp-card space-y-3">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-dp-accent-cyan flex items-center justify-center text-dp-bg-primary font-bold text-sm">4D</div>
          <div>
            <h3 className="text-sm font-bold text-dp-text-primary">MB SYSTEM 4D</h3>
            <p className="text-[10px] text-dp-text-tertiary">Canais Dark Globais</p>
          </div>
        </div>
        <div className="grid grid-cols-2 gap-3 text-xs">
          <div className="py-2 border-b border-dp-border-primary">
            <span className="text-dp-text-tertiary">Versão</span>
            <span className="float-right text-dp-text-primary font-medium">0.8.0</span>
          </div>
          <div className="py-2 border-b border-dp-border-primary">
            <span className="text-dp-text-tertiary">Framework</span>
            <span className="float-right text-dp-text-primary font-medium">ACPC-IA v1.0</span>
          </div>
          <div className="py-2 border-b border-dp-border-primary">
            <span className="text-dp-text-tertiary">Stack</span>
            <span className="float-right text-dp-text-primary font-medium">Next.js 14 + Supabase</span>
          </div>
          <div className="py-2 border-b border-dp-border-primary">
            <span className="text-dp-text-tertiary">Autor</span>
            <span className="float-right text-dp-text-primary font-medium">Marcelo Brasil</span>
          </div>
          <div className="py-2">
            <span className="text-dp-text-tertiary">TTS Providers</span>
            <span className="float-right text-dp-text-primary font-medium">Google + ElevenLabs</span>
          </div>
          <div className="py-2">
            <span className="text-dp-text-tertiary">Inteligência</span>
            <span className="float-right text-dp-text-primary font-medium">YouTube Data API v3</span>
          </div>
        </div>
        <p className="text-[10px] text-dp-text-tertiary pt-2 border-t border-dp-border-primary">
          Construído com ACPC-IA Framework v1.0.0 — Arquitetura de Continuidade e Persistência de Contexto para Projetos Assistidos por IA.
        </p>
      </div>
    </div>
  );
}
