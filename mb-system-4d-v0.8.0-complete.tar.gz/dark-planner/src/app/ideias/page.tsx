'use client';

import { useState, useEffect, useCallback } from 'react';
import { Header } from '@/components/layout';
import { EmptyState } from '@/components/ui';
import { Lightbulb, Plus, Trash2, Pencil, Check, X, GripVertical } from 'lucide-react';
import { getIdeas, createIdea, updateIdea, deleteIdea, type IdeaItem } from '@/lib/supabase/org-queries';
import { cn } from '@/lib/utils';

const COLORS = [
  { value: 'cyan', bg: 'bg-dp-accent-cyan/10', border: 'border-dp-accent-cyan/30', text: 'text-dp-accent-cyan' },
  { value: 'yellow', bg: 'bg-dp-accent-yellow/10', border: 'border-dp-accent-yellow/30', text: 'text-dp-accent-yellow' },
  { value: 'purple', bg: 'bg-dp-accent-purple/10', border: 'border-dp-accent-purple/30', text: 'text-dp-accent-purple' },
  { value: 'green', bg: 'bg-dp-accent-green/10', border: 'border-dp-accent-green/30', text: 'text-dp-accent-green' },
  { value: 'orange', bg: 'bg-dp-accent-orange/10', border: 'border-dp-accent-orange/30', text: 'text-dp-accent-orange' },
  { value: 'blue', bg: 'bg-dp-accent-blue/10', border: 'border-dp-accent-blue/30', text: 'text-dp-accent-blue' },
];

function getColor(c: string) {
  return COLORS.find(x => x.value === c) || COLORS[0];
}

export default function IdeiasPage() {
  const [ideas, setIdeas] = useState<IdeaItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [adding, setAdding] = useState(false);
  const [newContent, setNewContent] = useState('');
  const [newColor, setNewColor] = useState('cyan');
  const [editId, setEditId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState('');
  const [dragging, setDragging] = useState<string | null>(null);

  const loadData = useCallback(async () => {
    try { setIdeas(await getIdeas()); } catch (e) { console.error(e); } finally { setLoading(false); }
  }, []);
  useEffect(() => { loadData(); }, [loadData]);

  const handleAdd = async () => {
    if (!newContent.trim()) return;
    await createIdea({ content: newContent.trim(), color: newColor });
    setNewContent(''); setNewColor('cyan'); setAdding(false); loadData();
  };

  const handleEdit = async (id: string) => {
    if (!editContent.trim()) return;
    await updateIdea(id, { content: editContent.trim() });
    setEditId(null); loadData();
  };

  const handleDelete = async (id: string) => {
    await deleteIdea(id); loadData();
  };

  const handleDragStart = (id: string) => setDragging(id);
  const handleDragOver = (e: React.DragEvent) => e.preventDefault();
  const handleDrop = async (targetId: string) => {
    if (!dragging || dragging === targetId) { setDragging(null); return; }
    const fromIdx = ideas.findIndex(i => i.id === dragging);
    const toIdx = ideas.findIndex(i => i.id === targetId);
    if (fromIdx === -1 || toIdx === -1) { setDragging(null); return; }

    const reordered = [...ideas];
    const [moved] = reordered.splice(fromIdx, 1);
    reordered.splice(toIdx, 0, moved);
    setIdeas(reordered);
    setDragging(null);

    // Persist order
    await Promise.all(reordered.map((item, i) => updateIdea(item.id, { sort_order: i })));
  };

  return (
    <>
      <Header title="Quadro de Ideias" subtitle={`${ideas.length} ideias anotadas`} />
      <div className="p-6 animate-fade-in">
        {/* Add button */}
        <div className="flex items-center justify-between mb-6">
          <p className="text-xs text-dp-text-tertiary">Anote ideias de vídeos, títulos, ganchos e conceitos rapidamente.</p>
          <button onClick={() => setAdding(true)} className="dp-btn-primary text-xs flex items-center gap-1.5">
            <Plus size={14} /> Nova Ideia
          </button>
        </div>

        {/* New idea form */}
        {adding && (
          <div className="dp-card border-dp-accent-cyan/30 mb-6">
            <textarea value={newContent} onChange={e => setNewContent(e.target.value)} rows={3}
              placeholder="Anote sua ideia..." autoFocus className="dp-input w-full resize-none text-sm mb-3" />
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] text-dp-text-tertiary mr-1">Cor:</span>
                {COLORS.map(c => (
                  <button key={c.value} onClick={() => setNewColor(c.value)}
                    className={cn('w-5 h-5 rounded-full border-2 transition-transform', c.bg, newColor === c.value ? `${c.border} scale-125` : 'border-transparent')} />
                ))}
              </div>
              <div className="flex gap-2">
                <button onClick={() => { setAdding(false); setNewContent(''); }} className="dp-btn-secondary text-xs px-3 py-1.5">Cancelar</button>
                <button onClick={handleAdd} disabled={!newContent.trim()} className="dp-btn-primary text-xs px-3 py-1.5 disabled:opacity-50">Salvar</button>
              </div>
            </div>
          </div>
        )}

        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">{[1,2,3,4].map(i => <div key={i} className="dp-card animate-pulse h-32" />)}</div>
        ) : ideas.length === 0 && !adding ? (
          <EmptyState icon={Lightbulb} title="Quadro vazio"
            description="Anote ideias rápidas para seus próximos vídeos."
            action={{ label: '+ Anotar Primeira Ideia', onClick: () => setAdding(true) }} />
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {ideas.map(idea => {
              const color = getColor(idea.color);
              const isEditing = editId === idea.id;

              return (
                <div key={idea.id}
                  draggable={!isEditing}
                  onDragStart={() => handleDragStart(idea.id)}
                  onDragOver={handleDragOver}
                  onDrop={() => handleDrop(idea.id)}
                  className={cn(
                    'rounded-xl border p-4 transition-all group relative',
                    color.bg, color.border,
                    dragging === idea.id && 'opacity-40 scale-95',
                    !isEditing && 'cursor-grab active:cursor-grabbing',
                  )}
                >
                  {/* Drag handle */}
                  {!isEditing && (
                    <div className="absolute top-2 left-2 opacity-0 group-hover:opacity-50 transition-opacity">
                      <GripVertical size={12} className="text-dp-text-tertiary" />
                    </div>
                  )}

                  {/* Actions */}
                  {!isEditing && (
                    <div className="absolute top-2 right-2 flex gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity">
                      <button onClick={() => { setEditId(idea.id); setEditContent(idea.content); }}
                        className="p-1 rounded hover:bg-dp-bg-primary/50 text-dp-text-tertiary"><Pencil size={11} /></button>
                      <button onClick={() => handleDelete(idea.id)}
                        className="p-1 rounded hover:bg-dp-bg-primary/50 text-dp-text-tertiary hover:text-dp-accent-red"><Trash2 size={11} /></button>
                    </div>
                  )}

                  {isEditing ? (
                    <div>
                      <textarea value={editContent} onChange={e => setEditContent(e.target.value)} rows={3} autoFocus
                        className="dp-input w-full resize-none text-sm mb-2 bg-transparent border-dp-border-primary" />
                      <div className="flex justify-end gap-1.5">
                        <button onClick={() => setEditId(null)} className="p-1 rounded hover:bg-dp-bg-primary/50"><X size={14} className="text-dp-text-tertiary" /></button>
                        <button onClick={() => handleEdit(idea.id)} className="p-1 rounded hover:bg-dp-bg-primary/50"><Check size={14} className={color.text} /></button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <p className="text-sm text-dp-text-primary whitespace-pre-wrap leading-relaxed">{idea.content}</p>
                      <p className="text-[9px] text-dp-text-tertiary mt-3">{new Date(idea.created_at).toLocaleDateString('pt-BR')}</p>
                    </>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </>
  );
}
