'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { Header } from '@/components/layout';
import { StatCard } from '@/components/dashboard/stat-card';
import {
  Tv, FileText, Cog, CheckCircle, Calendar, Globe, AlertTriangle, Bell,
  TrendingUp, Flame, ArrowRight, Plus, Clock, Mic, RefreshCw, CheckCheck,
} from 'lucide-react';
import { getDashboardData, markNotificationRead, markAllNotificationsRead, type DashboardData } from '@/lib/supabase/dashboard-queries';
import { cn } from '@/lib/utils';

export default function DashboardPage() {
  const router = useRouter();
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const loadData = useCallback(async () => {
    try {
      const d = await getDashboardData();
      setData(d);
    } catch (err) {
      console.error('Dashboard load error:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const handleRefresh = () => { setRefreshing(true); loadData(); };

  const handleMarkRead = async (id: string) => {
    await markNotificationRead(id);
    loadData();
  };

  const handleMarkAllRead = async () => {
    await markAllNotificationsRead();
    loadData();
  };

  const greeting = getGreeting();
  const dateStr = new Date().toLocaleDateString('pt-BR', {
    weekday: 'long', day: 'numeric', month: 'long', year: 'numeric',
  });

  const s = data?.stats || {
    total_channels: 0, videos_planning: 0, videos_production: 0, videos_ready: 0,
    videos_scheduled: 0, videos_published: 0, videos_overdue: 0,
    total_scripts: 0, total_audios: 0, unread_notifications: 0,
  };

  return (
    <>
      <Header title="Dashboard" subtitle={dateStr} />

      <div className="p-6 space-y-6 animate-fade-in">
        {/* Greeting + refresh */}
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <h1 className="text-2xl font-bold text-dp-text-primary">
              {greeting}, Marcelo 👋
            </h1>
            <p className="text-sm text-dp-text-secondary">
              {s.total_channels === 0
                ? 'Crie seu primeiro canal para começar a organizar seus vídeos.'
                : s.videos_overdue > 0
                  ? `⚠️ ${s.videos_overdue} vídeo${s.videos_overdue > 1 ? 's' : ''} atrasado${s.videos_overdue > 1 ? 's' : ''}. Hora de agir.`
                  : `${s.total_channels} canal${s.total_channels > 1 ? 'is' : ''} ativo${s.total_channels > 1 ? 's' : ''}. Continue produzindo.`
              }
            </p>
          </div>
          <button
            onClick={handleRefresh}
            disabled={refreshing}
            className="p-2 rounded-lg hover:bg-dp-bg-hover text-dp-text-tertiary hover:text-dp-accent-cyan transition-colors"
            title="Atualizar dados"
          >
            <RefreshCw size={16} className={cn(refreshing && 'animate-spin')} />
          </button>
        </div>

        {loading ? (
          <div className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
              {Array.from({ length: 7 }).map((_, i) => (
                <div key={i} className="dp-card animate-pulse h-24" />
              ))}
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 dp-card animate-pulse h-64" />
              <div className="dp-card animate-pulse h-64" />
            </div>
          </div>
        ) : (
          <>
            {/* Stats Grid */}
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
              <StatCard label="Total Canais" value={s.total_channels} icon={Tv} color="cyan" />
              <StatCard label="Planejamento" value={s.videos_planning} icon={FileText} color="blue" />
              <StatCard label="Em Produção" value={s.videos_production} icon={Cog} color="orange" />
              <StatCard label="Prontos" value={s.videos_ready} icon={CheckCircle} color="purple" />
              <StatCard label="Agendados" value={s.videos_scheduled} icon={Calendar} color="yellow" />
              <StatCard label="Publicados" value={s.videos_published} icon={Globe} color="green" />
              <StatCard label="Atrasados" value={s.videos_overdue} icon={AlertTriangle} color="red" />
            </div>

            {/* Secondary stats (mini) */}
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-dp-bg-secondary border border-dp-border-primary">
                <FileText size={12} className="text-dp-accent-cyan" />
                <span className="text-[10px] text-dp-text-secondary"><span className="text-dp-text-primary font-medium">{s.total_scripts}</span> roteiros</span>
              </div>
              <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-dp-bg-secondary border border-dp-border-primary">
                <Mic size={12} className="text-dp-accent-purple" />
                <span className="text-[10px] text-dp-text-secondary"><span className="text-dp-text-primary font-medium">{s.total_audios}</span> áudios gerados</span>
              </div>
            </div>

            {/* Main content grid */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

              {/* Alerts & Notifications + Overdue */}
              <div className="lg:col-span-2 space-y-4">
                {/* Overdue warning */}
                {data && data.overdue.length > 0 && (
                  <div className="dp-card border-dp-accent-red/30">
                    <div className="flex items-center gap-2 mb-3">
                      <AlertTriangle size={16} className="text-dp-accent-red" />
                      <h3 className="text-sm font-semibold text-dp-accent-red">
                        Vídeos Atrasados ({data.overdue.length})
                      </h3>
                    </div>
                    <div className="space-y-1.5">
                      {data.overdue.map(v => (
                        <div key={v.id} className="flex items-center gap-3 px-3 py-2 rounded-lg bg-dp-accent-red/5 hover:bg-dp-accent-red/10 transition-colors cursor-pointer"
                          onClick={() => router.push(`/canais/${v.channel_id}`)}
                        >
                          <AlertTriangle size={12} className="text-dp-accent-red flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <p className="text-xs text-dp-text-primary truncate">{v.title}</p>
                            <p className="text-[10px] text-dp-text-tertiary">{v.channel_name} · Agendado para {formatDate(v.scheduled_at)}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Notifications */}
                <div className="dp-card">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-sm font-semibold text-dp-text-primary flex items-center gap-2">
                      <Bell size={16} className="text-dp-accent-cyan" />
                      Notificações
                      {s.unread_notifications > 0 && (
                        <span className="text-[10px] bg-dp-accent-red text-white px-1.5 py-0.5 rounded-full">
                          {s.unread_notifications}
                        </span>
                      )}
                    </h3>
                    {s.unread_notifications > 0 && (
                      <button onClick={handleMarkAllRead} className="flex items-center gap-1 text-[10px] text-dp-accent-cyan hover:underline">
                        <CheckCheck size={11} /> Marcar todas como lidas
                      </button>
                    )}
                  </div>
                  <div className="space-y-2">
                    {data && data.notifications.length > 0 ? (
                      data.notifications.map(n => (
                        <div key={n.id} className="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-dp-bg-tertiary/50 hover:bg-dp-bg-hover transition-colors group">
                          <div className="p-1.5 rounded-md bg-dp-accent-cyan/10">
                            {n.type === 'overdue' ? <AlertTriangle size={14} className="text-dp-accent-red" /> :
                             n.type === 'niche_viral' ? <Flame size={14} className="text-dp-accent-orange" /> :
                             n.type === 'trending' ? <TrendingUp size={14} className="text-dp-accent-green" /> :
                             <Bell size={14} className="text-dp-accent-cyan" />}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm text-dp-text-primary truncate">{n.title}</p>
                            <p className="text-[10px] text-dp-text-tertiary">{timeAgo(n.created_at)}</p>
                          </div>
                          <button
                            onClick={() => handleMarkRead(n.id)}
                            className="text-[10px] text-dp-text-tertiary hover:text-dp-accent-cyan opacity-0 group-hover:opacity-100 transition-opacity"
                          >
                            Marcar lida
                          </button>
                        </div>
                      ))
                    ) : (
                      <p className="text-center text-sm text-dp-text-tertiary py-8">Nenhuma notificação pendente ✓</p>
                    )}
                  </div>
                </div>
              </div>

              {/* Próximas Publicações */}
              <div className="dp-card">
                <div className="flex items-center justify-between mb-4">
                  <h3 className="text-sm font-semibold text-dp-text-primary flex items-center gap-2">
                    <Clock size={16} className="text-dp-accent-yellow" />
                    Próximas Publicações
                  </h3>
                </div>
                {data && data.upcoming.length > 0 ? (
                  <div className="space-y-2">
                    {groupByDay(data.upcoming).map(group => (
                      <div key={group.label}>
                        <div className="flex items-center gap-2 mb-1.5">
                          <span className="text-xs font-medium text-dp-text-primary">{group.label}</span>
                          <span className="text-[10px] text-dp-text-tertiary">({group.dateStr})</span>
                        </div>
                        {group.items.map(v => (
                          <div
                            key={v.id}
                            onClick={() => router.push(`/canais/${v.channel_id}`)}
                            className="flex items-center gap-2 px-3 py-2 rounded-md bg-dp-bg-tertiary/50 mb-1 text-xs text-dp-text-secondary hover:bg-dp-bg-hover cursor-pointer transition-colors"
                          >
                            <Calendar size={12} className="text-dp-accent-yellow flex-shrink-0" />
                            <div className="flex-1 min-w-0">
                              <span className="truncate block">{v.channel_name} — {v.title}</span>
                              <span className="text-[10px] text-dp-text-tertiary">{formatTime(v.scheduled_at)}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    ))}
                  </div>
                ) : (
                  <p className="text-center text-sm text-dp-text-tertiary py-8 italic">Nenhum vídeo agendado</p>
                )}
              </div>
            </div>

            {/* Resumo dos Canais */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-sm font-semibold text-dp-text-primary flex items-center gap-2">
                  <Tv size={16} className="text-dp-accent-cyan" />
                  Resumo dos Canais
                </h3>
                <button onClick={() => router.push('/canais')} className="dp-btn-primary text-xs py-1.5 flex items-center gap-1.5">
                  <Plus size={14} /> Novo Canal
                </button>
              </div>

              {data && data.channels.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {data.channels.map(ch => (
                    <div
                      key={ch.id}
                      onClick={() => router.push(`/canais/${ch.id}`)}
                      className="dp-card-interactive group cursor-pointer"
                    >
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-dp-accent-cyan/20 to-dp-accent-blue/20 flex items-center justify-center">
                            <Tv size={14} className="text-dp-accent-cyan" />
                          </div>
                          <div>
                            <p className="text-sm font-medium text-dp-text-primary group-hover:text-dp-accent-cyan transition-colors">{ch.name}</p>
                            <div className="flex items-center gap-1.5 mt-0.5">
                              <span className="text-[10px] text-dp-text-tertiary">{ch.language}</span>
                              {ch.frequency && (
                                <span className="text-[10px] text-dp-text-tertiary">· {ch.frequency}</span>
                              )}
                            </div>
                          </div>
                        </div>
                        <ArrowRight size={14} className="text-dp-text-tertiary group-hover:text-dp-accent-cyan transition-colors" />
                      </div>
                      <div className="flex gap-2 flex-wrap">
                        {ch.counts.planning > 0 && <span className="dp-badge-blue">{ch.counts.planning} Planejamento</span>}
                        {ch.counts.production > 0 && <span className="dp-badge-orange">{ch.counts.production} Produção</span>}
                        {ch.counts.ready > 0 && <span className="dp-badge-purple">{ch.counts.ready} Prontos</span>}
                        {ch.counts.scheduled > 0 && <span className="dp-badge-yellow">{ch.counts.scheduled} Agendados</span>}
                        {ch.counts.published > 0 && <span className="dp-badge-green">{ch.counts.published} Publicados</span>}
                        {ch.counts.overdue > 0 && <span className="dp-badge-red">{ch.counts.overdue} Atrasados</span>}
                        {ch.total_videos === 0 && <span className="text-[10px] text-dp-text-tertiary italic">Sem vídeos</span>}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="dp-card text-center py-12">
                  <Tv size={32} className="text-dp-accent-cyan/40 mx-auto mb-3" />
                  <p className="text-sm text-dp-text-secondary mb-2">Nenhum canal criado ainda</p>
                  <button onClick={() => router.push('/canais')} className="text-xs text-dp-accent-cyan hover:underline">
                    + Criar primeiro canal
                  </button>
                </div>
              )}
            </div>
          </>
        )}
      </div>
    </>
  );
}

// ============================================================
// Helpers
// ============================================================

function getGreeting(): string {
  const h = new Date().getHours();
  if (h < 12) return 'Bom dia';
  if (h < 18) return 'Boa tarde';
  return 'Boa noite';
}

function formatDate(iso: string): string {
  return new Date(iso).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });
}

function formatTime(iso: string): string {
  return new Date(iso).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}

function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'agora';
  if (mins < 60) return `${mins}m atrás`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h atrás`;
  const days = Math.floor(hours / 24);
  return `${days}d atrás`;
}

interface DayGroup { label: string; dateStr: string; items: { id: string; title: string; channel_name: string; channel_id: string; scheduled_at: string }[] }

function groupByDay(videos: { id: string; title: string; channel_name: string; channel_id: string; scheduled_at: string }[]): DayGroup[] {
  const groups = new Map<string, DayGroup>();
  const today = new Date();
  const tomorrow = new Date(today);
  tomorrow.setDate(tomorrow.getDate() + 1);

  const todayKey = today.toISOString().slice(0, 10);
  const tomorrowKey = tomorrow.toISOString().slice(0, 10);

  for (const v of videos) {
    const dateKey = v.scheduled_at.slice(0, 10);
    let label: string;
    if (dateKey === todayKey) label = 'Hoje';
    else if (dateKey === tomorrowKey) label = 'Amanhã';
    else {
      const d = new Date(v.scheduled_at);
      label = d.toLocaleDateString('pt-BR', { weekday: 'long' });
      label = label.charAt(0).toUpperCase() + label.slice(1);
    }

    const dateStr = new Date(v.scheduled_at).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });

    if (!groups.has(dateKey)) {
      groups.set(dateKey, { label, dateStr, items: [] });
    }
    groups.get(dateKey)!.items.push(v);
  }

  return Array.from(groups.values());
}
