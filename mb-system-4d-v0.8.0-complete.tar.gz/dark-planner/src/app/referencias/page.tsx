'use client';

import { useState, useEffect, useCallback, useMemo } from 'react';
import { Header } from '@/components/layout';
import { Modal, EmptyState } from '@/components/ui';
import { Bookmark, Plus, Search, ExternalLink, Pencil, Trash2, Globe } from 'lucide-react';
import { getReferences, createReference, updateReference, deleteReference, type Reference } from '@/lib/supabase/organization-queries';
import { createClient } from '@/lib/supabase/client';
import type { ProjectChannel } from '@/lib/supabase/types';

export default function ReferencesPage() {
  const [refs, setRefs] = useState<Reference[]>([]);
  const [channels, setChannels] = useState<ProjectChannel[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [nicheFilter, setNicheFilter] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Reference | null>(null);

  // Form
  const [title, setTitle] = useState('');
  const [url, setUrl] = useState('');
  const [niche, setNiche] = useState('');
  const [notes, setNotes] = useState('');
  const [channelId, setChannelId] = useState('');
  const [saving, setSaving] = useState(false);

  const supabase = createClient();

  const loadData = useCallback(async () => {
    try {
      const [refsData, chData] = await Promise.all([
        getReferences(),
        supabase.from('project_channels').select('*').order('name'),
      ]);
      setRefs(refsData);
      setChannels((chData.data || []) as ProjectChannel[]);
    } catch (e) { console.error(e); } finally { setLoading(false); }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const niches = useMemo(() => [...new Set(refs.map(r => r.niche).filter(Boolean))].sort(), [refs]);

  const filtered = useMemo(() => {
    return refs.filter(r => {
      if (search && !r.title.toLowerCase().includes(search.toLowerCase()) && !r.url.toLowerCase().includes(search.toLowerCase())) return false;
      if (nicheFilter && r.niche !== nicheFilter) return false;
      return true;
    });
  }, [refs, search, nicheFilter]);

  const openNew = () => { setEditing(null); setTitle(''); setUrl(''); setNiche(''); setNotes(''); setChannelId(''); setModalOpen(true); };
  const openEdit = (r: Reference) => { setEditing(r); setTitle(r.title); setUrl(r.url); setNiche(r.niche); setNotes(r.notes); setChannelId(r.channel_id || ''); setModalOpen(true); };

  const handleSave = async () => {
    if (!title.trim()) return;
    setSaving(true);
    try {
      const data = { title, url, niche, notes, channel_id: channelId || undefined };
      if (editing) await updateReference(editing.id, data);
      else await createReference(data);
      setModalOpen(false); loadData();
    } catch (e) { console.error(e); } finally { setSaving(false); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Deletar esta referência?')) return;
    await deleteReference(id); loadData();
  };

  const channelName = (id: string | null) => channels.find(c => c.id === id)?.name || '';

  return (
    <>
      <Header title="Referências" subtitle="Salve canais e ideias organizados por nicho" />

      <div className="p-6 space-y-4 animate-fade-in">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-dp-text-tertiary" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar referências..." className="dp-input w-full pl-8 text-xs" />
          </div>
          {niches.length > 0 && (
            <select value={nicheFilter} onChange={e => setNicheFilter(e.target.value)} className="dp-input text-xs">
              <option value="">Todos os nichos</option>
              {niches.map(n => <option key={n} value={n}>{n}</option>)}
            </select>
          )}
          <button onClick={openNew} className="dp-btn-primary text-xs flex items-center gap-1.5">
            <Plus size={14} /> Nova Referência
          </button>
        </div>

        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="dp-card animate-pulse h-32" />)}</div>
        ) : filtered.length === 0 ? (
          <EmptyState icon={Bookmark} title="Nenhuma referência" description="Salve canais e links de referência para seus nichos." action={{ label: 'Adicionar Referência', onClick: openNew }} />
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filtered.map(r => (
              <div key={r.id} className="dp-card-interactive group">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <div className="p-1.5 rounded-lg bg-dp-accent-purple/10">
                      <Bookmark size={14} className="text-dp-accent-purple" />
                    </div>
                    <h3 className="text-sm font-medium text-dp-text-primary">{r.title}</h3>
                  </div>
                  <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => openEdit(r)} className="p-1 rounded hover:bg-dp-bg-hover"><Pencil size={12} className="text-dp-text-tertiary" /></button>
                    <button onClick={() => handleDelete(r.id)} className="p-1 rounded hover:bg-dp-bg-hover"><Trash2 size={12} className="text-dp-accent-red" /></button>
                  </div>
                </div>
                {r.url && (
                  <a href={r.url} target="_blank" rel="noopener" className="flex items-center gap-1 text-[10px] text-dp-accent-cyan hover:underline mb-2 truncate">
                    <ExternalLink size={10} /> {r.url}
                  </a>
                )}
                <div className="flex items-center gap-2 flex-wrap">
                  {r.niche && <span className="text-[9px] px-2 py-0.5 rounded-full bg-dp-accent-purple/10 text-dp-accent-purple">{r.niche}</span>}
                  {r.channel_id && <span className="text-[9px] px-2 py-0.5 rounded-full bg-dp-accent-cyan/10 text-dp-accent-cyan">{channelName(r.channel_id)}</span>}
                </div>
                {r.notes && <p className="text-[10px] text-dp-text-tertiary mt-2 line-clamp-2">{r.notes}</p>}
              </div>
            ))}
          </div>
        )}
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Editar Referência' : 'Nova Referência'} size="md"
        footer={<div className="flex justify-end gap-2"><button onClick={() => setModalOpen(false)} className="dp-btn-secondary text-xs">Cancelar</button><button onClick={handleSave} disabled={!title.trim() || saving} className="dp-btn-primary text-xs">{saving ? 'Salvando...' : 'Salvar'}</button></div>}
      >
        <div className="space-y-3">
          <div><label className="block text-xs font-medium text-dp-text-secondary mb-1">Título *</label><input value={title} onChange={e => setTitle(e.target.value)} placeholder="Ex: Canal de Curiosidades Top" className="dp-input w-full text-xs" /></div>
          <div><label className="block text-xs font-medium text-dp-text-secondary mb-1">URL</label><input value={url} onChange={e => setUrl(e.target.value)} placeholder="https://youtube.com/@..." className="dp-input w-full text-xs" /></div>
          <div><label className="block text-xs font-medium text-dp-text-secondary mb-1">Nicho</label><input value={niche} onChange={e => setNiche(e.target.value)} placeholder="Ex: curiosidades, finanças, terror" className="dp-input w-full text-xs" /></div>
          <div><label className="block text-xs font-medium text-dp-text-secondary mb-1">Canal associado</label>
            <select value={channelId} onChange={e => setChannelId(e.target.value)} className="dp-input w-full text-xs">
              <option value="">Nenhum</option>
              {channels.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </div>
          <div><label className="block text-xs font-medium text-dp-text-secondary mb-1">Notas</label><textarea value={notes} onChange={e => setNotes(e.target.value)} rows={3} className="dp-input w-full text-xs resize-y" /></div>
        </div>
      </Modal>
    </>
  );
}
