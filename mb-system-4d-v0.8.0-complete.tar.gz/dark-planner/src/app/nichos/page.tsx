'use client';

import { useState, useEffect, useCallback } from 'react';
import { Header } from '@/components/layout';
import { Modal, EmptyState } from '@/components/ui';
import {
  Radar, Plus, Search, Trash2, Pencil, Play, Loader2, Eye, Zap,
  Skull, ExternalLink, Users, Calendar, AlertTriangle, Globe,
} from 'lucide-react';
import {
  getMonitoredNiches, createMonitoredNiche, updateMonitoredNiche, deleteMonitoredNiche,
  getRemovedChannels, createRemovedChannel, deleteRemovedChannel,
  type MonitoredNiche, type RemovedChannel, type NicheInsert, type RemovedChannelInsert,
} from '@/lib/supabase/niche-queries';
import { cn } from '@/lib/utils';

type Tab = 'niches' | 'removed';

const REASONS = [
  'Violação de diretrizes', 'Spam/Enganoso', 'Copyright strike',
  'Inatividade', 'Conta encerrada', 'Motivo desconhecido', 'Outro',
];

export default function NichosPage() {
  const [tab, setTab] = useState<Tab>('niches');
  const [niches, setNiches] = useState<MonitoredNiche[]>([]);
  const [removed, setRemoved] = useState<RemovedChannel[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNicheForm, setShowNicheForm] = useState(false);
  const [showRemovedForm, setShowRemovedForm] = useState(false);
  const [scanning, setScanning] = useState<string | null>(null);
  const [scanResults, setScanResults] = useState<any[]>([]);

  const loadData = useCallback(async () => {
    try {
      const [n, r] = await Promise.all([getMonitoredNiches(), getRemovedChannels()]);
      setNiches(n); setRemoved(r);
    } catch (e) { console.error(e); } finally { setLoading(false); }
  }, []);
  useEffect(() => { loadData(); }, [loadData]);

  const handleCreateNiche = async (data: NicheInsert) => {
    await createMonitoredNiche(data);
    setShowNicheForm(false); loadData();
  };

  const handleDeleteNiche = async (id: string) => {
    if (!confirm('Excluir este nicho?')) return;
    await deleteMonitoredNiche(id); loadData();
  };

  const handleScan = async (niche: MonitoredNiche) => {
    setScanning(niche.id); setScanResults([]);
    try {
      const q = niche.keywords.join(' ');
      const res = await fetch(`/api/youtube?action=search&q=${encodeURIComponent(q)}&days=30&region=${niche.region}`);
      if (!res.ok) throw new Error('Scan failed');
      const data = await res.json();
      setScanResults(data.videos || []);
      const avgScore = data.videos.length > 0
        ? data.videos.reduce((s: number, v: any) => s + v.viralScore, 0) / data.videos.length
        : 0;
      await updateMonitoredNiche(niche.id, {
        last_scanned_at: new Date().toISOString(),
        scan_count: niche.scan_count + 1,
        avg_viral_score: Math.round(avgScore * 100) / 100,
      });
      loadData();
    } catch (e) { console.error(e); } finally { setScanning(null); }
  };

  const handleCreateRemoved = async (data: RemovedChannelInsert) => {
    await createRemovedChannel(data);
    setShowRemovedForm(false); loadData();
  };

  const handleDeleteRemoved = async (id: string) => {
    if (!confirm('Excluir este registro?')) return;
    await deleteRemovedChannel(id); loadData();
  };

  const fmtN = (n: number) => n >= 1e6 ? `${(n / 1e6).toFixed(1)}M` : n >= 1e3 ? `${(n / 1e3).toFixed(1)}K` : n.toString();

  return (
    <>
      <Header title="Nichos & Canais Removidos" subtitle="Monitore oportunidades e aprenda com canais que caíram" />
      <div className="p-6 animate-fade-in">
        {/* Tabs */}
        <div className="flex items-center gap-1 border-b border-dp-border-primary mb-6">
          {([
            ['niches', `Nichos Monitorados (${niches.length})`, Radar],
            ['removed', `Canais Removidos (${removed.length})`, Skull],
          ] as const).map(([k, l, I]) => (
            <button key={k} onClick={() => setTab(k)}
              className={cn('flex items-center gap-1.5 px-4 py-2.5 text-xs font-medium border-b-2 -mb-px transition-colors',
                tab === k ? 'text-dp-accent-cyan border-dp-accent-cyan' : 'text-dp-text-tertiary border-transparent hover:text-dp-text-secondary')}>
              <I size={14} /> {l}
            </button>
          ))}
        </div>

        {/* ===================== NICHES TAB ===================== */}
        {tab === 'niches' && (
          <>
            <div className="flex justify-end mb-4">
              <button onClick={() => setShowNicheForm(true)} className="dp-btn-primary text-xs flex items-center gap-1.5">
                <Plus size={14} /> Monitorar Nicho
              </button>
            </div>

            {loading ? (
              <div className="space-y-3">{[1,2,3].map(i => <div key={i} className="dp-card animate-pulse h-28" />)}</div>
            ) : niches.length === 0 ? (
              <EmptyState icon={Radar} title="Nenhum nicho monitorado"
                description="Adicione nichos para escanear vídeos virais automaticamente."
                action={{ label: '+ Adicionar Nicho', onClick: () => setShowNicheForm(true) }} />
            ) : (
              <div className="space-y-3">
                {niches.map(n => (
                  <div key={n.id} className="dp-card-interactive">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="p-2.5 rounded-lg bg-dp-accent-cyan/10">
                          <Radar size={18} className="text-dp-accent-cyan" />
                        </div>
                        <div>
                          <h3 className="text-sm font-semibold text-dp-text-primary">{n.name}</h3>
                          <div className="flex items-center gap-2 mt-1 flex-wrap">
                            {n.keywords.map(k => (
                              <span key={k} className="text-[9px] px-1.5 py-0.5 rounded bg-dp-accent-blue/10 text-dp-accent-blue">{k}</span>
                            ))}
                            <span className="text-[9px] text-dp-text-tertiary flex items-center gap-0.5"><Globe size={8} /> {n.region}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {n.avg_viral_score !== null && (
                          <div className="text-center px-3 py-1 rounded-lg bg-dp-bg-tertiary">
                            <div className={cn('text-sm font-bold',
                              n.avg_viral_score >= 50 ? 'text-dp-accent-green' : n.avg_viral_score >= 30 ? 'text-dp-accent-yellow' : 'text-dp-accent-red')}>
                              {n.avg_viral_score.toFixed(0)}
                            </div>
                            <div className="text-[8px] text-dp-text-tertiary">Viral Médio</div>
                          </div>
                        )}
                        <div className="text-center px-3 py-1">
                          <div className="text-sm font-medium text-dp-text-primary">{n.scan_count}</div>
                          <div className="text-[8px] text-dp-text-tertiary">Scans</div>
                        </div>
                        <button onClick={() => handleScan(n)} disabled={scanning === n.id}
                          className="dp-btn-primary text-xs flex items-center gap-1.5">
                          {scanning === n.id ? <Loader2 size={12} className="animate-spin" /> : <Play size={12} />}
                          Scan
                        </button>
                        <button onClick={() => handleDeleteNiche(n.id)} className="p-1.5 rounded hover:bg-dp-bg-hover text-dp-text-tertiary hover:text-dp-accent-red">
                          <Trash2 size={13} />
                        </button>
                      </div>
                    </div>
                    {n.last_scanned_at && (
                      <p className="text-[9px] text-dp-text-tertiary mt-2">
                        Último scan: {new Date(n.last_scanned_at).toLocaleString('pt-BR')}
                      </p>
                    )}

                    {/* Scan results inline */}
                    {scanning === null && scanResults.length > 0 && n.id === niches.find(x => x.last_scanned_at === niches.reduce((a, b) => (a.last_scanned_at || '') > (b.last_scanned_at || '') ? a : b).last_scanned_at)?.id && (
                      <div className="mt-3 pt-3 border-t border-dp-border-primary space-y-1.5">
                        {scanResults.slice(0, 5).map((vm: any) => (
                          <div key={vm.video.id} className="flex items-center gap-3 px-2 py-1.5 rounded bg-dp-bg-tertiary/50">
                            <span className={cn('text-[10px] font-bold px-1.5 py-0.5 rounded-full',
                              vm.viralScore >= 70 ? 'bg-dp-accent-green/10 text-dp-accent-green' : vm.viralScore >= 40 ? 'bg-dp-accent-yellow/10 text-dp-accent-yellow' : 'bg-dp-accent-red/10 text-dp-accent-red')}>
                              {vm.viralScore}
                            </span>
                            <span className="text-xs text-dp-text-primary truncate flex-1">{vm.video.title}</span>
                            <span className="text-[10px] text-dp-text-tertiary flex items-center gap-0.5"><Eye size={9} /> {fmtN(vm.video.viewCount)}</span>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}

            {showNicheForm && (
              <NicheFormModal open onClose={() => setShowNicheForm(false)} onSave={handleCreateNiche} />
            )}
          </>
        )}

        {/* ===================== REMOVED TAB ===================== */}
        {tab === 'removed' && (
          <>
            <div className="flex items-center justify-between mb-4">
              <p className="text-xs text-dp-text-tertiary">Registre canais dark que foram removidos para aprender com os erros.</p>
              <button onClick={() => setShowRemovedForm(true)} className="dp-btn-primary text-xs flex items-center gap-1.5">
                <Plus size={14} /> Registrar Canal
              </button>
            </div>

            {loading ? (
              <div className="space-y-2">{[1,2,3].map(i => <div key={i} className="dp-card animate-pulse h-20" />)}</div>
            ) : removed.length === 0 ? (
              <EmptyState icon={Skull} title="Nenhum canal removido registrado"
                description="Documente canais que caíram para entender padrões e evitar os mesmos erros."
                action={{ label: '+ Registrar Canal', onClick: () => setShowRemovedForm(true) }} />
            ) : (
              <div className="space-y-2">
                {removed.map(ch => (
                  <div key={ch.id} className="dp-card flex items-center gap-4 group">
                    <div className="p-2 rounded-lg bg-dp-accent-red/10 flex-shrink-0">
                      <Skull size={16} className="text-dp-accent-red" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-medium text-dp-text-primary truncate">{ch.channel_name}</p>
                        {ch.channel_url && (
                          <a href={ch.channel_url} target="_blank" className="text-dp-text-tertiary hover:text-dp-accent-cyan"><ExternalLink size={10} /></a>
                        )}
                      </div>
                      <div className="flex items-center gap-3 mt-0.5 text-[10px] text-dp-text-tertiary">
                        <span className="px-1.5 py-0.5 rounded bg-dp-accent-red/10 text-dp-accent-red">{ch.reason}</span>
                        {ch.niche && <span>{ch.niche}</span>}
                        {ch.subscribers_at_removal && <span className="flex items-center gap-0.5"><Users size={9} /> {fmtN(ch.subscribers_at_removal)}</span>}
                        <span className="flex items-center gap-0.5"><Calendar size={9} /> {new Date(ch.detected_at).toLocaleDateString('pt-BR')}</span>
                      </div>
                      {ch.notes && <p className="text-[10px] text-dp-text-tertiary mt-1 italic line-clamp-1">{ch.notes}</p>}
                    </div>
                    <button onClick={() => handleDeleteRemoved(ch.id)}
                      className="p-1.5 rounded hover:bg-dp-bg-hover text-dp-text-tertiary hover:text-dp-accent-red opacity-0 group-hover:opacity-100 transition-opacity">
                      <Trash2 size={13} />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {showRemovedForm && (
              <RemovedFormModal open onClose={() => setShowRemovedForm(false)} onSave={handleCreateRemoved} />
            )}
          </>
        )}
      </div>
    </>
  );
}

// ============================================================
// Niche Form Modal
// ============================================================
function NicheFormModal({ open, onClose, onSave }: { open: boolean; onClose: () => void; onSave: (d: NicheInsert) => Promise<void> }) {
  const [name, setName] = useState('');
  const [keywords, setKeywords] = useState('');
  const [region, setRegion] = useState('BR');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);

  const handleSubmit = async () => {
    if (!name.trim()) return;
    setSaving(true);
    try {
      await onSave({
        name: name.trim(),
        keywords: keywords.split(',').map(k => k.trim()).filter(Boolean),
        region, notes: notes.trim() || undefined,
      });
    } finally { setSaving(false); }
  };

  return (
    <Modal open={open} onClose={onClose} title="Monitorar Novo Nicho" size="md"
      footer={<>
        <button onClick={onClose} className="dp-btn-secondary text-sm px-4 py-2">Cancelar</button>
        <button onClick={handleSubmit} disabled={!name.trim() || saving} className="dp-btn-primary text-sm px-4 py-2 disabled:opacity-50">
          {saving ? 'Salvando...' : 'Monitorar'}
        </button>
      </>}>
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Nome do Nicho *</label>
          <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="Ex: Curiosidades Dark" className="dp-input w-full" />
        </div>
        <div>
          <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Palavras-chave (separadas por vírgula)</label>
          <input type="text" value={keywords} onChange={e => setKeywords(e.target.value)} placeholder="curiosidades, fatos, universo, mistérios" className="dp-input w-full" />
        </div>
        <div>
          <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Região</label>
          <select value={region} onChange={e => setRegion(e.target.value)} className="dp-input w-full">
            <option value="BR">Brasil</option><option value="US">EUA</option>
            <option value="ES">Espanha</option><option value="MX">México</option>
            <option value="PT">Portugal</option><option value="GB">Reino Unido</option>
          </select>
        </div>
        <div>
          <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Notas</label>
          <textarea value={notes} onChange={e => setNotes(e.target.value)} rows={3} className="dp-input w-full resize-y" placeholder="Observações sobre este nicho..." />
        </div>
      </div>
    </Modal>
  );
}

// ============================================================
// Removed Channel Form Modal
// ============================================================
function RemovedFormModal({ open, onClose, onSave }: { open: boolean; onClose: () => void; onSave: (d: RemovedChannelInsert) => Promise<void> }) {
  const [name, setName] = useState('');
  const [url, setUrl] = useState('');
  const [niche, setNiche] = useState('');
  const [reason, setReason] = useState('Violação de diretrizes');
  const [subs, setSubs] = useState('');
  const [notes, setNotes] = useState('');
  const [saving, setSaving] = useState(false);

  const handleSubmit = async () => {
    if (!name.trim()) return;
    setSaving(true);
    try {
      await onSave({
        channel_name: name.trim(), channel_url: url.trim() || undefined,
        niche: niche.trim() || undefined, reason,
        subscribers_at_removal: subs ? parseInt(subs) : undefined,
        notes: notes.trim() || undefined,
      });
    } finally { setSaving(false); }
  };

  return (
    <Modal open={open} onClose={onClose} title="Registrar Canal Removido" size="md"
      footer={<>
        <button onClick={onClose} className="dp-btn-secondary text-sm px-4 py-2">Cancelar</button>
        <button onClick={handleSubmit} disabled={!name.trim() || saving} className="dp-btn-primary text-sm px-4 py-2 disabled:opacity-50">
          {saving ? 'Salvando...' : 'Registrar'}
        </button>
      </>}>
      <div className="space-y-4">
        <div>
          <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Nome do Canal *</label>
          <input type="text" value={name} onChange={e => setName(e.target.value)} placeholder="Ex: Dark Facts BR" className="dp-input w-full" />
        </div>
        <div>
          <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">URL do Canal</label>
          <input type="url" value={url} onChange={e => setUrl(e.target.value)} placeholder="https://youtube.com/@..." className="dp-input w-full" />
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Motivo</label>
            <select value={reason} onChange={e => setReason(e.target.value)} className="dp-input w-full">
              {REASONS.map(r => <option key={r} value={r}>{r}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Inscritos na remoção</label>
            <input type="number" value={subs} onChange={e => setSubs(e.target.value)} placeholder="Ex: 50000" className="dp-input w-full" />
          </div>
        </div>
        <div>
          <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Nicho</label>
          <input type="text" value={niche} onChange={e => setNiche(e.target.value)} placeholder="Ex: Curiosidades" className="dp-input w-full" />
        </div>
        <div>
          <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Notas</label>
          <textarea value={notes} onChange={e => setNotes(e.target.value)} rows={3} className="dp-input w-full resize-y" placeholder="O que aprender com este caso?" />
        </div>
      </div>
    </Modal>
  );
}
