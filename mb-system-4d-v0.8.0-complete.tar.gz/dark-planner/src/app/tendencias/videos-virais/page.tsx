import { Header } from '@/components/layout';
import { TrendingUp } from 'lucide-react';

export default function Page() {
  return (
    <>
      <Header title="Vídeos Virais" subtitle="Encontre vídeos explodindo" />
      <div className="p-6 animate-fade-in">
        <div className="dp-card flex flex-col items-center justify-center py-20 text-center">
          <div className="p-4 rounded-2xl bg-dp-accent-cyan/10 mb-4">
            <TrendingUp size={32} className="text-dp-accent-cyan" />
          </div>
          <h2 className="text-lg font-semibold text-dp-text-primary mb-2">Vídeos Virais</h2>
          <p className="text-sm text-dp-text-secondary max-w-md">Encontre vídeos explodindo. Este módulo será implementado na próxima fase.</p>
          <span className="dp-badge-cyan mt-4">Em breve</span>
        </div>
      </div>
    </>
  );
}
