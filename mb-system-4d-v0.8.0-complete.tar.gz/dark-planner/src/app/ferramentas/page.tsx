'use client';

import { useState, useMemo } from 'react';
import { Header } from '@/components/layout';
import { AlignLeft, Hash, Type, Eraser, Copy, Check, ArrowDown, ArrowUp, LetterText } from 'lucide-react';
import { cn } from '@/lib/utils';

type Tool = 'counter' | 'formatter' | 'hashtags' | 'cleaner';

const TOOLS: { id: Tool; label: string; icon: any; desc: string }[] = [
  { id: 'counter', label: 'Contador de Texto', icon: AlignLeft, desc: 'Caracteres, palavras, tempo de narração' },
  { id: 'formatter', label: 'Formatador', icon: Type, desc: 'Maiúsculas, minúsculas, capitalizar' },
  { id: 'hashtags', label: 'Gerador de Hashtags', icon: Hash, desc: 'Extraia hashtags do texto' },
  { id: 'cleaner', label: 'Limpador de Texto', icon: Eraser, desc: 'Remover quebras duplas, espaços extras' },
];

export default function FerramentasPage() {
  const [activeTool, setActiveTool] = useState<Tool>('counter');
  const [text, setText] = useState('');
  const [copied, setCopied] = useState(false);

  const handleCopy = async (content: string) => {
    await navigator.clipboard.writeText(content);
    setCopied(true); setTimeout(() => setCopied(false), 2000);
  };

  return (
    <>
      <Header title="Ferramentas de Texto" subtitle="Utilitários rápidos para produção de conteúdo" />
      <div className="p-6 animate-fade-in">
        {/* Tool tabs */}
        <div className="flex items-center gap-2 mb-6 overflow-x-auto pb-1">
          {TOOLS.map(t => (
            <button key={t.id} onClick={() => setActiveTool(t.id)}
              className={cn(
                'flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-medium whitespace-nowrap transition-colors border',
                activeTool === t.id
                  ? 'bg-dp-accent-cyan/10 text-dp-accent-cyan border-dp-accent-cyan/30'
                  : 'text-dp-text-tertiary border-transparent hover:bg-dp-bg-hover',
              )}>
              <t.icon size={14} /> {t.label}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Input */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-medium text-dp-text-secondary">Texto de Entrada</label>
              <button onClick={() => setText('')} className="text-[10px] text-dp-text-tertiary hover:text-dp-accent-red">Limpar</button>
            </div>
            <textarea value={text} onChange={e => setText(e.target.value)} rows={16}
              placeholder="Cole ou escreva seu texto aqui..."
              className="dp-input w-full resize-y font-mono text-sm leading-relaxed" />
          </div>

          {/* Output */}
          <div>
            {activeTool === 'counter' && <CounterTool text={text} />}
            {activeTool === 'formatter' && <FormatterTool text={text} onCopy={handleCopy} copied={copied} />}
            {activeTool === 'hashtags' && <HashtagTool text={text} onCopy={handleCopy} copied={copied} />}
            {activeTool === 'cleaner' && <CleanerTool text={text} onCopy={handleCopy} copied={copied} onApply={setText} />}
          </div>
        </div>
      </div>
    </>
  );
}

// ============================================================
// Counter
// ============================================================
function CounterTool({ text }: { text: string }) {
  const stats = useMemo(() => {
    const chars = text.length;
    const charsNoSpaces = text.replace(/\s/g, '').length;
    const words = text.split(/\s+/).filter(Boolean).length;
    const sentences = text.split(/[.!?]+/).filter(s => s.trim()).length;
    const paragraphs = text.split(/\n\s*\n/).filter(s => s.trim()).length || (text.trim() ? 1 : 0);
    const lines = text.split('\n').length;
    const narration100 = Math.ceil(words / 100);
    const narration150 = Math.ceil(words / 150);
    const narration200 = Math.ceil(words / 200);
    const youtubeTitle = chars <= 100;
    const youtubeDesc = chars <= 5000;
    return { chars, charsNoSpaces, words, sentences, paragraphs, lines, narration100, narration150, narration200, youtubeTitle, youtubeDesc };
  }, [text]);

  const Row = ({ label, value, sub }: { label: string; value: string | number; sub?: string }) => (
    <div className="flex items-center justify-between py-2.5 border-b border-dp-border-primary last:border-0">
      <span className="text-xs text-dp-text-secondary">{label}</span>
      <div className="text-right">
        <span className="text-sm font-medium text-dp-text-primary">{value}</span>
        {sub && <span className="text-[10px] text-dp-text-tertiary block">{sub}</span>}
      </div>
    </div>
  );

  return (
    <div>
      <h3 className="text-xs font-semibold text-dp-text-primary mb-3 flex items-center gap-2">
        <AlignLeft size={14} className="text-dp-accent-cyan" /> Estatísticas
      </h3>
      <div className="dp-card">
        <Row label="Caracteres" value={stats.chars.toLocaleString('pt-BR')} sub={`${stats.charsNoSpaces.toLocaleString('pt-BR')} sem espaços`} />
        <Row label="Palavras" value={stats.words.toLocaleString('pt-BR')} />
        <Row label="Frases" value={stats.sentences} />
        <Row label="Parágrafos" value={stats.paragraphs} />
        <Row label="Linhas" value={stats.lines} />
      </div>
      <h3 className="text-xs font-semibold text-dp-text-primary mt-4 mb-3 flex items-center gap-2">
        <LetterText size={14} className="text-dp-accent-yellow" /> Tempo de Narração
      </h3>
      <div className="dp-card">
        <Row label="Lento (100 wpm)" value={`~${stats.narration100} min`} />
        <Row label="Normal (150 wpm)" value={`~${stats.narration150} min`} />
        <Row label="Rápido (200 wpm)" value={`~${stats.narration200} min`} />
      </div>
      <h3 className="text-xs font-semibold text-dp-text-primary mt-4 mb-3">Limites YouTube</h3>
      <div className="dp-card">
        <div className="flex items-center justify-between py-2.5 border-b border-dp-border-primary">
          <span className="text-xs text-dp-text-secondary">Título (≤100 chars)</span>
          <span className={cn('text-xs font-medium', stats.youtubeTitle ? 'text-dp-accent-green' : 'text-dp-accent-red')}>{stats.youtubeTitle ? '✓ OK' : '✗ Excede'}</span>
        </div>
        <div className="flex items-center justify-between py-2.5">
          <span className="text-xs text-dp-text-secondary">Descrição (≤5000 chars)</span>
          <span className={cn('text-xs font-medium', stats.youtubeDesc ? 'text-dp-accent-green' : 'text-dp-accent-red')}>{stats.youtubeDesc ? '✓ OK' : '✗ Excede'}</span>
        </div>
      </div>
    </div>
  );
}

// ============================================================
// Formatter
// ============================================================
function FormatterTool({ text, onCopy, copied }: { text: string; onCopy: (t: string) => void; copied: boolean }) {
  const [mode, setMode] = useState<'upper' | 'lower' | 'capitalize' | 'sentence'>('upper');

  const result = useMemo(() => {
    switch (mode) {
      case 'upper': return text.toUpperCase();
      case 'lower': return text.toLowerCase();
      case 'capitalize': return text.replace(/\b\w/g, c => c.toUpperCase());
      case 'sentence': return text.replace(/(^\s*\w|[.!?]\s+\w)/g, c => c.toUpperCase()).replace(/^./, c => c.toUpperCase());
    }
  }, [text, mode]);

  return (
    <div>
      <h3 className="text-xs font-semibold text-dp-text-primary mb-3 flex items-center gap-2">
        <Type size={14} className="text-dp-accent-cyan" /> Formatação
      </h3>
      <div className="flex items-center gap-2 mb-3">
        {([['upper', 'MAIÚSCULAS', ArrowUp], ['lower', 'minúsculas', ArrowDown], ['capitalize', 'Capitalizar', Type], ['sentence', 'Frase', LetterText]] as const).map(([m, l, I]) => (
          <button key={m} onClick={() => setMode(m)}
            className={cn('flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-[10px] font-medium border transition-colors',
              mode === m ? 'bg-dp-accent-cyan/10 text-dp-accent-cyan border-dp-accent-cyan/30' : 'text-dp-text-tertiary border-dp-border-primary hover:bg-dp-bg-hover')}>
            <I size={11} /> {l}
          </button>
        ))}
      </div>
      <div className="relative">
        <pre className="dp-card text-sm text-dp-text-secondary whitespace-pre-wrap font-mono leading-relaxed max-h-80 overflow-y-auto">{result || <span className="italic text-dp-text-tertiary">Escreva algo na esquerda...</span>}</pre>
        {result && (
          <button onClick={() => onCopy(result)} className="absolute top-3 right-3 p-1.5 rounded hover:bg-dp-bg-hover text-dp-text-tertiary hover:text-dp-accent-cyan">
            {copied ? <Check size={14} className="text-dp-accent-green" /> : <Copy size={14} />}
          </button>
        )}
      </div>
    </div>
  );
}

// ============================================================
// Hashtag Generator
// ============================================================
function HashtagTool({ text, onCopy, copied }: { text: string; onCopy: (t: string) => void; copied: boolean }) {
  const hashtags = useMemo(() => {
    if (!text.trim()) return [];
    const words = text.toLowerCase().split(/\s+/).filter(w => w.length > 3);
    const freq = new Map<string, number>();
    words.forEach(w => {
      const clean = w.replace(/[^a-záàâãéèêíïóôõúüç]/gi, '');
      if (clean.length > 3) freq.set(clean, (freq.get(clean) || 0) + 1);
    });
    return Array.from(freq.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 30)
      .map(([w]) => `#${w}`);
  }, [text]);

  const hashString = hashtags.join(' ');

  return (
    <div>
      <h3 className="text-xs font-semibold text-dp-text-primary mb-3 flex items-center gap-2">
        <Hash size={14} className="text-dp-accent-cyan" /> Hashtags Sugeridas
      </h3>
      {hashtags.length > 0 ? (
        <>
          <div className="dp-card flex flex-wrap gap-2 mb-3">
            {hashtags.map(h => (
              <span key={h} className="text-xs px-2 py-1 rounded-lg bg-dp-accent-blue/10 text-dp-accent-blue">{h}</span>
            ))}
          </div>
          <div className="flex items-center gap-2">
            <button onClick={() => onCopy(hashString)} className="dp-btn-primary text-xs flex items-center gap-1.5">
              {copied ? <Check size={12} className="text-dp-bg-primary" /> : <Copy size={12} />} Copiar Todas
            </button>
            <span className="text-[10px] text-dp-text-tertiary">{hashtags.length} hashtags · {hashString.length} chars</span>
          </div>
        </>
      ) : (
        <p className="dp-card text-sm text-dp-text-tertiary italic text-center py-8">Escreva um texto para gerar hashtags</p>
      )}
    </div>
  );
}

// ============================================================
// Cleaner
// ============================================================
function CleanerTool({ text, onCopy, copied, onApply }: { text: string; onCopy: (t: string) => void; copied: boolean; onApply: (t: string) => void }) {
  const [opts, setOpts] = useState({ doubleBreaks: true, extraSpaces: true, trailingSpaces: true, emptyLines: true });

  const result = useMemo(() => {
    let r = text;
    if (opts.extraSpaces) r = r.replace(/[ \t]+/g, ' ');
    if (opts.trailingSpaces) r = r.split('\n').map(l => l.trim()).join('\n');
    if (opts.doubleBreaks) r = r.replace(/\n{3,}/g, '\n\n');
    if (opts.emptyLines) r = r.replace(/^\s*\n/gm, '\n').replace(/^\n+/, '').replace(/\n+$/, '');
    return r;
  }, [text, opts]);

  const diff = text.length - result.length;

  const Opt = ({ k, label }: { k: keyof typeof opts; label: string }) => (
    <label className="flex items-center gap-2 text-xs text-dp-text-secondary cursor-pointer">
      <input type="checkbox" checked={opts[k]} onChange={e => setOpts({ ...opts, [k]: e.target.checked })} className="accent-dp-accent-cyan" /> {label}
    </label>
  );

  return (
    <div>
      <h3 className="text-xs font-semibold text-dp-text-primary mb-3 flex items-center gap-2">
        <Eraser size={14} className="text-dp-accent-cyan" /> Opções de Limpeza
      </h3>
      <div className="dp-card space-y-2.5 mb-4">
        <Opt k="extraSpaces" label="Remover espaços extras" />
        <Opt k="trailingSpaces" label="Remover espaços no final das linhas" />
        <Opt k="doubleBreaks" label="Reduzir quebras de linha múltiplas (≤2)" />
        <Opt k="emptyLines" label="Remover linhas totalmente vazias" />
      </div>
      {diff > 0 && (
        <p className="text-xs text-dp-accent-green mb-3">{diff} caractere{diff > 1 ? 's' : ''} removido{diff > 1 ? 's' : ''}</p>
      )}
      <div className="relative">
        <pre className="dp-card text-sm text-dp-text-secondary whitespace-pre-wrap font-mono leading-relaxed max-h-60 overflow-y-auto">{result || <span className="italic text-dp-text-tertiary">Escreva algo na esquerda...</span>}</pre>
      </div>
      {result && (
        <div className="flex items-center gap-2 mt-3">
          <button onClick={() => onCopy(result)} className="dp-btn-secondary text-xs flex items-center gap-1.5">
            {copied ? <Check size={12} /> : <Copy size={12} />} Copiar Resultado
          </button>
          <button onClick={() => onApply(result)} className="dp-btn-primary text-xs">Aplicar na Entrada</button>
        </div>
      )}
    </div>
  );
}
