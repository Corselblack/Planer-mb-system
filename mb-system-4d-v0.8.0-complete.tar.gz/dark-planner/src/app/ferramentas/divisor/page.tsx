'use client';

import { useState, useMemo } from 'react';
import { Header } from '@/components/layout';
import { Scissors, Copy, Check } from 'lucide-react';

export default function TextSplitterPage() {
  const [text, setText] = useState('');
  const [mode, setMode] = useState<'chars' | 'words' | 'sentences' | 'paragraphs'>('chars');
  const [chunkSize, setChunkSize] = useState(5000);
  const [wordSize, setWordSize] = useState(500);
  const [copied, setCopied] = useState<number | null>(null);

  const chunks = useMemo(() => {
    if (!text.trim()) return [];
    switch (mode) {
      case 'chars': {
        const result: string[] = [];
        for (let i = 0; i < text.length; i += chunkSize) {
          let end = Math.min(i + chunkSize, text.length);
          if (end < text.length) { const sp = text.lastIndexOf(' ', end); if (sp > i) end = sp + 1; }
          result.push(text.slice(i, end).trim());
          if (end <= i) break;
          i = end - chunkSize;
        }
        return result;
      }
      case 'words': {
        const words = text.split(/\s+/).filter(Boolean);
        const result: string[] = [];
        for (let i = 0; i < words.length; i += wordSize) result.push(words.slice(i, i + wordSize).join(' '));
        return result;
      }
      case 'sentences': return text.split(/(?<=[.!?])\s+/).filter(Boolean);
      case 'paragraphs': return text.split(/\n\s*\n/).filter(Boolean);
    }
  }, [text, mode, chunkSize, wordSize]);

  const handleCopy = (i: number, t: string) => { navigator.clipboard.writeText(t); setCopied(i); setTimeout(() => setCopied(null), 2000); };

  return (
    <>
      <Header title="Divisor de Texto" subtitle="Divida textos grandes em partes menores" />
      <div className="p-6 space-y-4 animate-fade-in">
        <textarea value={text} onChange={e => setText(e.target.value)} rows={8} placeholder="Cole o texto grande aqui..." className="dp-input w-full text-sm font-mono resize-y" />
        <div className="flex items-center gap-4 flex-wrap">
          <select value={mode} onChange={e => setMode(e.target.value as any)} className="dp-input text-xs">
            <option value="chars">Por caracteres</option>
            <option value="words">Por palavras</option>
            <option value="sentences">Por frases</option>
            <option value="paragraphs">Por parágrafos</option>
          </select>
          {mode === 'chars' && (
            <div className="flex items-center gap-2">
              <label className="text-xs text-dp-text-secondary">Máx. chars: {chunkSize.toLocaleString()}</label>
              <input type="range" min="500" max="20000" step="500" value={chunkSize} onChange={e => setChunkSize(+e.target.value)} className="accent-dp-accent-cyan" />
            </div>
          )}
          {mode === 'words' && (
            <div className="flex items-center gap-2">
              <label className="text-xs text-dp-text-secondary">Máx. palavras: {wordSize}</label>
              <input type="range" min="50" max="2000" step="50" value={wordSize} onChange={e => setWordSize(+e.target.value)} className="accent-dp-accent-cyan" />
            </div>
          )}
          <span className="text-xs text-dp-text-tertiary">
            <Scissors size={12} className="inline mr-1" />{chunks.length} parte{chunks.length !== 1 ? 's' : ''}
          </span>
        </div>
        {chunks.length > 0 && (
          <div className="space-y-3">
            {chunks.map((chunk, i) => (
              <div key={i} className="dp-card">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-[10px] font-medium text-dp-accent-cyan">Parte {i + 1} de {chunks.length}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-dp-text-tertiary">{chunk.length} chars · {chunk.split(/\s+/).filter(Boolean).length} palavras</span>
                    <button onClick={() => handleCopy(i, chunk)} className="dp-btn-secondary text-[10px] flex items-center gap-1">
                      {copied === i ? <Check size={10} /> : <Copy size={10} />} {copied === i ? 'Copiado!' : 'Copiar'}
                    </button>
                  </div>
                </div>
                <pre className="text-[11px] text-dp-text-secondary font-mono whitespace-pre-wrap max-h-32 overflow-y-auto">{chunk}</pre>
              </div>
            ))}
          </div>
        )}
      </div>
    </>
  );
}
