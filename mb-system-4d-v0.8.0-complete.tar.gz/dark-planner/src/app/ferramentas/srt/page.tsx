'use client';

import { useState, useMemo } from 'react';
import { Header } from '@/components/layout';
import { Subtitles, Copy, Download, Check } from 'lucide-react';

export default function SRTToolPage() {
  const [text, setText] = useState('');
  const [wordsPerLine, setWordsPerLine] = useState(5);
  const [segmentDuration, setSegmentDuration] = useState(8);
  const [speed, setSpeed] = useState(150); // words per minute
  const [mode, setMode] = useState<'words' | 'time'>('words');
  const [copied, setCopied] = useState(false);

  const srt = useMemo(() => {
    const words = text.split(/\s+/).filter(Boolean);
    if (words.length === 0) return '';

    const msPerWord = (60 / speed) * 1000;
    const segments: string[] = [];
    let idx = 1;

    if (mode === 'words') {
      for (let i = 0; i < words.length; i += wordsPerLine) {
        const group = words.slice(i, i + wordsPerLine);
        const startMs = Math.round(i * msPerWord);
        const endMs = Math.round((i + group.length) * msPerWord);
        segments.push(`${idx}\n${msToSrt(startMs)} --> ${msToSrt(endMs)}\n${group.join(' ')}\n`);
        idx++;
      }
    } else {
      const segMs = segmentDuration * 1000;
      const totalMs = words.length * msPerWord;
      for (let startMs = 0; startMs < totalMs; startMs += segMs) {
        const endMs = Math.min(startMs + segMs, totalMs);
        const startWord = Math.floor(startMs / msPerWord);
        const endWord = Math.min(Math.ceil(endMs / msPerWord), words.length);
        const group = words.slice(startWord, endWord);
        if (group.length > 0) {
          segments.push(`${idx}\n${msToSrt(startMs)} --> ${msToSrt(endMs)}\n${group.join(' ')}\n`);
          idx++;
        }
      }
    }
    return segments.join('\n');
  }, [text, wordsPerLine, segmentDuration, speed, mode]);

  const stats = useMemo(() => {
    const words = text.split(/\s+/).filter(Boolean).length;
    const duration = Math.ceil(words / speed * 60);
    const segments = srt.split(/\n\n/).filter(Boolean).length;
    return { words, duration, segments };
  }, [text, speed, srt]);

  const handleCopy = () => { navigator.clipboard.writeText(srt); setCopied(true); setTimeout(() => setCopied(false), 2000); };
  const handleDownload = () => {
    const blob = new Blob([srt], { type: 'text/plain' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'legenda.srt'; a.click();
  };

  return (
    <>
      <Header title="Gerador de SRT" subtitle="Gere legendas SRT estimadas a partir de texto" />
      <div className="p-6 space-y-4 animate-fade-in">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="space-y-4">
            <textarea value={text} onChange={e => setText(e.target.value)} rows={14} placeholder="Cole o texto aqui..." className="dp-input w-full text-sm font-mono resize-y" />
            <div className="flex items-center gap-4 flex-wrap">
              <div className="flex items-center gap-2">
                <label className="text-xs text-dp-text-secondary">Modo:</label>
                <select value={mode} onChange={e => setMode(e.target.value as any)} className="dp-input text-xs">
                  <option value="words">Por palavras</option>
                  <option value="time">Por tempo (View SRT)</option>
                </select>
              </div>
              {mode === 'words' ? (
                <div className="flex items-center gap-2">
                  <label className="text-xs text-dp-text-secondary">Palavras/legenda: {wordsPerLine}</label>
                  <input type="range" min="2" max="10" value={wordsPerLine} onChange={e => setWordsPerLine(+e.target.value)} className="accent-dp-accent-cyan" />
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <label className="text-xs text-dp-text-secondary">Duração: {segmentDuration}s</label>
                  <input type="range" min="3" max="15" value={segmentDuration} onChange={e => setSegmentDuration(+e.target.value)} className="accent-dp-accent-cyan" />
                </div>
              )}
              <div className="flex items-center gap-2">
                <label className="text-xs text-dp-text-secondary">Velocidade: {speed} wpm</label>
                <input type="range" min="80" max="250" step="10" value={speed} onChange={e => setSpeed(+e.target.value)} className="accent-dp-accent-cyan" />
              </div>
            </div>
            <div className="flex items-center gap-4 text-[10px] text-dp-text-tertiary">
              <span>{stats.words} palavras</span>
              <span>~{stats.duration}s</span>
              <span>{stats.segments} segmentos</span>
            </div>
          </div>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-semibold text-dp-text-primary flex items-center gap-1.5"><Subtitles size={14} className="text-dp-accent-cyan" /> SRT Gerado</h3>
              <div className="flex gap-2">
                <button onClick={handleCopy} disabled={!srt} className="dp-btn-secondary text-[10px] flex items-center gap-1">
                  {copied ? <Check size={11} /> : <Copy size={11} />} {copied ? 'Copiado!' : 'Copiar'}
                </button>
                <button onClick={handleDownload} disabled={!srt} className="dp-btn-primary text-[10px] flex items-center gap-1">
                  <Download size={11} /> Download .srt
                </button>
              </div>
            </div>
            <pre className="dp-card text-[11px] font-mono text-dp-text-secondary whitespace-pre-wrap max-h-[60vh] overflow-y-auto">{srt || 'Cole texto à esquerda para gerar...'}</pre>
          </div>
        </div>
      </div>
    </>
  );
}

function msToSrt(ms: number): string {
  const h = Math.floor(ms / 3600000);
  const m = Math.floor((ms % 3600000) / 60000);
  const s = Math.floor((ms % 60000) / 1000);
  const ml = ms % 1000;
  return `${h.toString().padStart(2,'0')}:${m.toString().padStart(2,'0')}:${s.toString().padStart(2,'0')},${ml.toString().padStart(3,'0')}`;
}
