'use client';

import { useState, useEffect, useCallback } from 'react';
import { Header } from '@/components/layout';
import { Modal, EmptyState } from '@/components/ui';
import { Lightbulb, Plus, Pin, PinOff, Pencil, Trash2 } from 'lucide-react';
import { getIdeas, createIdea, updateIdea, deleteIdea, type Idea } from '@/lib/supabase/organization-queries';
import { cn } from '@/lib/utils';

const COLORS = [
  { value: 'cyan', label: 'Ciano', bg: 'bg-dp-accent-cyan/10', border: 'border-dp-accent-cyan/30', text: 'text-dp-accent-cyan' },
  { value: 'purple', label: 'Roxo', bg: 'bg-dp-accent-purple/10', border: 'border-dp-accent-purple/30', text: 'text-dp-accent-purple' },
  { value: 'yellow', label: 'Amarelo', bg: 'bg-dp-accent-yellow/10', border: 'border-dp-accent-yellow/30', text: 'text-dp-accent-yellow' },
  { value: 'green', label: 'Verde', bg: 'bg-dp-accent-green/10', border: 'border-dp-accent-green/30', text: 'text-dp-accent-green' },
  { value: 'orange', label: 'Laranja', bg: 'bg-dp-accent-orange/10', border: 'border-dp-accent-orange/30', text: 'text-dp-accent-orange' },
  { value: 'red', label: 'Vermelho', bg: 'bg-dp-accent-red/10', border: 'border-dp-accent-red/30', text: 'text-dp-accent-red' },
];

const colorMap = Object.fromEntries(COLORS.map(c => [c.value, c]));

export default function IdeasPage() {
  const [ideas, setIdeas] = useState<Idea[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<Idea | null>(null);

  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [color, setColor] = useState('cyan');
  const [saving, setSaving] = useState(false);

  const loadData = useCallback(async () => {
    try { setIdeas(await getIdeas()); } catch (e) { console.error(e); } finally { setLoading(false); }
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  const openNew = () => { setEditing(null); setTitle(''); setBody(''); setColor('cyan'); setModalOpen(true); };
  const openEdit = (idea: Idea) => { setEditing(idea); setTitle(idea.title); setBody(idea.body); setColor(idea.color); setModalOpen(true); };

  const handleSave = async () => {
    if (!title.trim()) return;
    setSaving(true);
    try {
      if (editing) await updateIdea(editing.id, { title, body, color });
      else await createIdea({ title, body, color });
      setModalOpen(false); loadData();
    } catch (e) { console.error(e); } finally { setSaving(false); }
  };

  const handlePin = async (idea: Idea) => { await updateIdea(idea.id, { pinned: !idea.pinned }); loadData(); };
  const handleDelete = async (id: string) => { if (confirm('Deletar esta ideia?')) { await deleteIdea(id); loadData(); } };

  return (
    <>
      <Header title="Quadro de Ideias" subtitle="Anote e organize suas ideias para vídeos" />

      <div className="p-6 animate-fade-in">
        <div className="flex items-center justify-between mb-6">
          <p className="text-xs text-dp-text-tertiary">{ideas.length} ideia{ideas.length !== 1 ? 's' : ''}</p>
          <button onClick={openNew} className="dp-btn-primary text-xs flex items-center gap-1.5"><Plus size={14} /> Nova Ideia</button>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="dp-card animate-pulse h-36" />)}</div>
        ) : ideas.length === 0 ? (
          <EmptyState icon={Lightbulb} title="Nenhuma ideia ainda" description="Comece anotando ideias para seus próximos vídeos!" action={{ label: 'Criar Ideia', onClick: openNew }} />
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {ideas.map(idea => {
              const c = colorMap[idea.color] || colorMap.cyan;
              return (
                <div key={idea.id} className={cn('rounded-xl border p-4 transition-all hover:scale-[1.02] group relative', c.bg, c.border)}>
                  {idea.pinned && (
                    <div className="absolute -top-1.5 -right-1.5"><Pin size={14} className={c.text} /></div>
                  )}
                  <h3 className={cn('text-sm font-semibold mb-2', c.text)}>{idea.title}</h3>
                  {idea.body && <p className="text-[11px] text-dp-text-secondary line-clamp-4 whitespace-pre-wrap">{idea.body}</p>}
                  <div className="flex items-center gap-1 mt-3 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button onClick={() => handlePin(idea)} className="p-1 rounded hover:bg-white/10" title={idea.pinned ? 'Desafixar' : 'Fixar'}>
                      {idea.pinned ? <PinOff size={12} className="text-dp-text-tertiary" /> : <Pin size={12} className="text-dp-text-tertiary" />}
                    </button>
                    <button onClick={() => openEdit(idea)} className="p-1 rounded hover:bg-white/10"><Pencil size={12} className="text-dp-text-tertiary" /></button>
                    <button onClick={() => handleDelete(idea.id)} className="p-1 rounded hover:bg-white/10"><Trash2 size={12} className="text-dp-accent-red" /></button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editing ? 'Editar Ideia' : 'Nova Ideia'} size="md"
        footer={<div className="flex justify-end gap-2"><button onClick={() => setModalOpen(false)} className="dp-btn-secondary text-xs">Cancelar</button><button onClick={handleSave} disabled={!title.trim() || saving} className="dp-btn-primary text-xs">{saving ? 'Salvando...' : 'Salvar'}</button></div>}
      >
        <div className="space-y-3">
          <div><label className="block text-xs font-medium text-dp-text-secondary mb-1">Título *</label><input value={title} onChange={e => setTitle(e.target.value)} placeholder="Ex: 5 fatos sobre o oceano" className="dp-input w-full text-xs" /></div>
          <div><label className="block text-xs font-medium text-dp-text-secondary mb-1">Descrição</label><textarea value={body} onChange={e => setBody(e.target.value)} rows={4} placeholder="Detalhes, links, anotações..." className="dp-input w-full text-xs resize-y" /></div>
          <div>
            <label className="block text-xs font-medium text-dp-text-secondary mb-1.5">Cor</label>
            <div className="flex gap-2">
              {COLORS.map(c => (
                <button key={c.value} onClick={() => setColor(c.value)} className={cn('w-7 h-7 rounded-lg border-2 transition-all', c.bg, color === c.value ? c.border + ' scale-110' : 'border-transparent')} title={c.label} />
              ))}
            </div>
          </div>
        </div>
      </Modal>
    </>
  );
}
