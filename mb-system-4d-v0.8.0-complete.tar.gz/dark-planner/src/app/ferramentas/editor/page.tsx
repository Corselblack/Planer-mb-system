'use client';

import { useState, useMemo } from 'react';
import { Header } from '@/components/layout';
import { Type, Copy, Download, Check, Trash2, RotateCcw } from 'lucide-react';

export default function TextEditorPage() {
  const [text, setText] = useState('');
  const [copied, setCopied] = useState(false);
  const [history, setHistory] = useState<string[]>([]);

  const stats = useMemo(() => {
    const chars = text.length;
    const charsNoSpaces = text.replace(/\s/g, '').length;
    const words = text.split(/\s+/).filter(Boolean).length;
    const sentences = text.split(/[.!?]+/).filter(s => s.trim()).length;
    const paragraphs = text.split(/\n\s*\n/).filter(s => s.trim()).length || (text.trim() ? 1 : 0);
    const readTime = Math.ceil(words / 200);
    const speakTime = Math.ceil(words / 150);
    return { chars, charsNoSpaces, words, sentences, paragraphs, readTime, speakTime };
  }, [text]);

  const pushHistory = () => setHistory(h => [text, ...h.slice(0, 19)]);

  const apply = (fn: (t: string) => string) => { pushHistory(); setText(fn(text)); };

  const handleCopy = () => { navigator.clipboard.writeText(text); setCopied(true); setTimeout(() => setCopied(false), 2000); };
  const handleDownload = () => {
    const blob = new Blob([text], { type: 'text/plain' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = 'texto.txt'; a.click();
  };
  const handleUndo = () => { if (history.length > 0) { setText(history[0]); setHistory(h => h.slice(1)); } };

  return (
    <>
      <Header title="Editor de Texto" subtitle="Edite, formate e analise seus textos" />
      <div className="p-6 space-y-4 animate-fade-in">
        {/* Toolbar */}
        <div className="flex items-center gap-2 flex-wrap">
          <button onClick={() => apply(t => t.toUpperCase())} className="dp-btn-secondary text-[10px]">MAIÚSCULAS</button>
          <button onClick={() => apply(t => t.toLowerCase())} className="dp-btn-secondary text-[10px]">minúsculas</button>
          <button onClick={() => apply(t => t.replace(/(^\w|\.\s+\w)/gm, c => c.toUpperCase()))} className="dp-btn-secondary text-[10px]">Capitalizar</button>
          <button onClick={() => apply(t => t.replace(/\s+/g, ' ').trim())} className="dp-btn-secondary text-[10px]">Remover Espaços</button>
          <button onClick={() => apply(t => t.replace(/\n{3,}/g, '\n\n').trim())} className="dp-btn-secondary text-[10px]">Remover Linhas Vazias</button>
          <button onClick={() => apply(t => [...new Set(t.split('\n'))].join('\n'))} className="dp-btn-secondary text-[10px]">Remover Duplicadas</button>
          <div className="flex-1" />
          <button onClick={handleUndo} disabled={history.length === 0} className="dp-btn-secondary text-[10px] flex items-center gap-1 disabled:opacity-30"><RotateCcw size={10} /> Desfazer</button>
          <button onClick={handleCopy} disabled={!text} className="dp-btn-secondary text-[10px] flex items-center gap-1">{copied ? <Check size={10} /> : <Copy size={10} />} {copied ? 'Copiado!' : 'Copiar'}</button>
          <button onClick={handleDownload} disabled={!text} className="dp-btn-primary text-[10px] flex items-center gap-1"><Download size={10} /> Baixar .txt</button>
          <button onClick={() => { pushHistory(); setText(''); }} disabled={!text} className="p-1.5 rounded hover:bg-dp-bg-hover text-dp-accent-red"><Trash2 size={14} /></button>
        </div>

        {/* Editor */}
        <textarea value={text} onChange={e => setText(e.target.value)} rows={18} placeholder="Cole ou escreva seu texto aqui..." className="dp-input w-full text-sm font-mono resize-y leading-relaxed" />

        {/* Stats bar */}
        <div className="flex items-center gap-6 flex-wrap px-1">
          {[
            ['Caracteres', stats.chars.toLocaleString('pt-BR')],
            ['Sem espaços', stats.charsNoSpaces.toLocaleString('pt-BR')],
            ['Palavras', stats.words.toLocaleString('pt-BR')],
            ['Frases', stats.sentences.toString()],
            ['Parágrafos', stats.paragraphs.toString()],
            ['Leitura', `~${stats.readTime} min`],
            ['Narração', `~${stats.speakTime} min`],
          ].map(([label, value]) => (
            <div key={label} className="text-center">
              <p className="text-sm font-semibold text-dp-text-primary">{value}</p>
              <p className="text-[9px] text-dp-text-tertiary">{label}</p>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
